#!/bin/bash
#
# SENTINEL IoT v2.0 - Script para desplegar interfaz web
#

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    log_error "Este script debe ejecutarse como root (sudo)"
    exit 1
fi

echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                                                           ║${NC}"
echo -e "${BLUE}║     SENTINEL IoT v2.0 - Despliegue de Interfaz Web       ║${NC}"
echo -e "${BLUE}║                                                           ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Obtener directorio del script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

log_info "Directorio del proyecto: $PROJECT_DIR"

# Verificar que existe el directorio frontend
if [ ! -d "$PROJECT_DIR/frontend/public" ]; then
    log_error "No se encontró el directorio frontend/public"
    exit 1
fi

# Crear directorio de destino
INSTALL_DIR="/opt/sentinel-iot"
FRONTEND_DIR="$INSTALL_DIR/frontend/public"

log_info "Creando directorio de frontend..."
mkdir -p "$FRONTEND_DIR"

# Copiar archivos
log_info "Copiando archivos de la interfaz web..."
cp -r "$PROJECT_DIR/frontend/public/"* "$FRONTEND_DIR/"

# Verificar que se copió index.html
if [ -f "$FRONTEND_DIR/index.html" ]; then
    log_success "Interfaz web copiada correctamente"
    log_info "Ubicación: $FRONTEND_DIR/index.html"
else
    log_error "Error al copiar interfaz web"
    exit 1
fi

# Dar permisos correctos
log_info "Configurando permisos..."
chmod -R 755 "$FRONTEND_DIR"

# Reiniciar servicio
log_info "Reiniciando servicio sentinel-iot..."
systemctl restart sentinel-iot

# Esperar un momento
sleep 2

# Verificar estado
if systemctl is-active --quiet sentinel-iot; then
    log_success "Servicio reiniciado correctamente"
else
    log_error "El servicio no está activo"
    log_info "Ver logs con: journalctl -u sentinel-iot -n 50"
    exit 1
fi

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}║          Interfaz web desplegada correctamente            ║${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

IP_ADDRESS=$(hostname -I | awk '{print $1}')

echo -e "${YELLOW}Accede a la interfaz web en:${NC}"
echo -e "  ${GREEN}http://$IP_ADDRESS:8000${NC}"
echo ""
echo -e "${YELLOW}Documentación de la API:${NC}"
echo -e "  ${GREEN}http://$IP_ADDRESS:8000/api/docs${NC}"
echo ""
echo -e "${YELLOW}Verificar salud del sistema:${NC}"
echo -e "  ${GREEN}curl http://localhost:8000/api/v1/health${NC}"
echo ""

log_info "Si no puedes acceder desde otro dispositivo, verifica el firewall:"
echo "  sudo nft list ruleset"
echo "  sudo nft add rule inet sentinel input tcp dport 8000 accept"
echo ""

exit 0
