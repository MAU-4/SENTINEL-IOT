#!/bin/bash
#
# SENTINEL IoT v2.0 - Script de Instalación Automática
# 
# Este script instala y configura SENTINEL IoT en Raspberry Pi
#

set -e  # Salir si hay error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables
INSTALL_DIR="/opt/sentinel-iot"
DATA_DIR="/var/lib/sentinel-iot"
LOG_DIR="/var/log/sentinel-iot"
BACKUP_DIR="$DATA_DIR/backups"
IOT_INTERFACE="wlan1"
MAIN_INTERFACE="eth0"
IOT_NETWORK="192.168.100.0/24"
IOT_GATEWAY="192.168.100.1"

# Funciones de utilidad
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    log_error "Este script debe ejecutarse como root (sudo)"
    exit 1
fi

# Banner
echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║            SENTINEL IoT v2.0 - Instalación               ║"
echo "║                                                           ║"
echo "║     Plataforma Integral de Seguridad IoT con ML          ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Paso 1: Verificar requisitos
log_info "Verificando requisitos del sistema..."

# Verificar Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/cpuinfo; then
    log_warning "No se detectó Raspberry Pi. Continuando de todos modos..."
fi

# Verificar interfaces de red
if ! ip link show $MAIN_INTERFACE > /dev/null 2>&1; then
    log_error "Interfaz principal $MAIN_INTERFACE no encontrada"
    exit 1
fi

if ! ip link show $IOT_INTERFACE > /dev/null 2>&1; then
    log_error "Interfaz IoT $IOT_INTERFACE no encontrada"
    log_error "Por favor conecta un adaptador Wi-Fi USB"
    exit 1
fi

log_success "Requisitos verificados"

# Paso 2: Actualizar sistema
log_info "Actualizando sistema..."
apt-get update -qq
apt-get upgrade -y -qq
log_success "Sistema actualizado"

# Paso 3: Instalar dependencias
log_info "Instalando dependencias..."

# Herramientas de red
apt-get install -y -qq \
    hostapd \
    dnsmasq \
    nftables \
    bridge-utils \
    net-tools \
    iptables \
    tcpdump \
    nmap \
    wireless-tools \
    iw

# Python y librerías
apt-get install -y -qq \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev

# Herramientas de desarrollo
apt-get install -y -qq \
    git \
    curl \
    wget \
    vim \
    htop

log_success "Dependencias instaladas"

# Paso 4: Crear estructura de directorios
log_info "Creando estructura de directorios..."

mkdir -p $INSTALL_DIR
mkdir -p $DATA_DIR/{logs,backups,models,reports}
mkdir -p $LOG_DIR
mkdir -p /etc/sentinel-iot

log_success "Directorios creados"

# Paso 5: Configurar interfaces de red
log_info "Configurando interfaces de red..."

# Configurar IP estática para wlan1
cat > /etc/network/interfaces.d/wlan1 << EOF
auto $IOT_INTERFACE
iface $IOT_INTERFACE inet static
    address $IOT_GATEWAY
    netmask 255.255.255.0
    post-up /usr/sbin/hostapd -B /etc/hostapd/hostapd.conf
EOF

# Configurar wlan1 inmediatamente
ip addr flush dev $IOT_INTERFACE
ip addr add $IOT_GATEWAY/24 dev $IOT_INTERFACE
ip link set $IOT_INTERFACE up

log_success "Interfaces configuradas"

# Paso 6: Configurar hostapd
log_info "Configurando punto de acceso Wi-Fi..."

# Generar contraseña segura
WIFI_PASSWORD=$(openssl rand -base64 16 | tr -d "=+/" | cut -c1-16)

cat > /etc/hostapd/hostapd.conf << EOF
# Interfaz
interface=$IOT_INTERFACE
driver=nl80211

# Red
ssid=SENTINEL_IoT
hw_mode=g
channel=6
country_code=US

# Seguridad
wpa=2
wpa_passphrase=$WIFI_PASSWORD
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP

# Configuración
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wmm_enabled=1
EOF

# Configurar systemd para hostapd
systemctl unmask hostapd
systemctl enable hostapd

log_success "Punto de acceso configurado"
log_warning "Contraseña Wi-Fi: $WIFI_PASSWORD"

# Paso 7: Configurar dnsmasq
log_info "Configurando DHCP y DNS..."

# Backup de configuración original
mv /etc/dnsmasq.conf /etc/dnsmasq.conf.backup

cat > /etc/dnsmasq.conf << EOF
# Interfaz
interface=$IOT_INTERFACE
bind-interfaces

# DHCP
dhcp-range=192.168.100.10,192.168.100.250,255.255.255.0,24h
dhcp-option=3,$IOT_GATEWAY  # Gateway
dhcp-option=6,$IOT_GATEWAY  # DNS

# DNS
domain=sentinel.local
local=/sentinel.local/

# Logs
log-queries
log-dhcp
log-facility=$LOG_DIR/dnsmasq.log
EOF

systemctl enable dnsmasq

log_success "DHCP y DNS configurados"

# Paso 8: Configurar nftables
log_info "Configurando firewall..."

cat > /etc/nftables.conf << 'EOF'
#!/usr/sbin/nft -f

flush ruleset

table inet sentinel {
    chain input {
        type filter hook input priority 0; policy drop;
        
        # Permitir loopback
        iif lo accept
        
        # Permitir conexiones establecidas
        ct state established,related accept
        
        # Permitir SSH
        tcp dport 22 accept
        
        # Permitir HTTPS
        tcp dport 443 accept
        
        # Permitir DNS desde red IoT
        iif wlan1 udp dport 53 accept
        
        # Permitir DHCP desde red IoT
        iif wlan1 udp dport 67 accept
    }
    
    chain forward {
        type filter hook forward priority 0; policy drop;
        
        # Permitir conexiones establecidas
        ct state established,related accept
        
        # Permitir tráfico de IoT a Internet (será gestionado por API)
        iif wlan1 oif eth0 accept
        
        # Denegar tráfico de IoT a red local por defecto
        iif wlan1 oif eth0 ip daddr 192.168.0.0/16 drop
    }
    
    chain output {
        type filter hook output priority 0; policy accept;
    }
}

# NAT para red IoT
table ip nat {
    chain postrouting {
        type nat hook postrouting priority 100;
        oif eth0 masquerade
    }
}
EOF

# Aplicar reglas
nft -f /etc/nftables.conf
systemctl enable nftables

log_success "Firewall configurado"

# Paso 9: Habilitar IP forwarding
log_info "Habilitando IP forwarding..."

echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
sysctl -p

log_success "IP forwarding habilitado"

# Paso 10: Instalar aplicación Python
log_info "Instalando aplicación SENTINEL..."

cd $INSTALL_DIR

# Crear entorno virtual
python3 -m venv venv
source venv/bin/activate

# Instalar dependencias Python
pip install --upgrade pip
pip install \
    fastapi \
    uvicorn[standard] \
    sqlalchemy \
    pydantic \
    pydantic-settings \
    python-multipart \
    python-jose[cryptography] \
    passlib[bcrypt] \
    redis \
    celery \
    scikit-learn \
    numpy \
    pandas

log_success "Aplicación instalada"

# Paso 11: Crear servicio systemd
log_info "Creando servicio systemd..."

cat > /etc/systemd/system/sentinel-iot.service << EOF
[Unit]
Description=SENTINEL IoT v2.0 API
After=network.target nftables.service hostapd.service dnsmasq.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin"
ExecStart=$INSTALL_DIR/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 443 --ssl-keyfile /etc/sentinel-iot/key.pem --ssl-certfile /etc/sentinel-iot/cert.pem
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Generar certificado SSL autofirmado
openssl req -x509 -newkey rsa:4096 -nodes \
    -keyout /etc/sentinel-iot/key.pem \
    -out /etc/sentinel-iot/cert.pem \
    -days 365 \
    -subj "/C=US/ST=State/L=City/O=SENTINEL/CN=sentinel.local"

systemctl daemon-reload
systemctl enable sentinel-iot

log_success "Servicio creado"

# Paso 12: Iniciar servicios
log_info "Iniciando servicios..."

systemctl restart hostapd
systemctl restart dnsmasq
systemctl restart nftables
systemctl start sentinel-iot

log_success "Servicios iniciados"

# Paso 13: Verificar instalación
log_info "Verificando instalación..."

sleep 5

if systemctl is-active --quiet hostapd; then
    log_success "hostapd: activo"
else
    log_error "hostapd: inactivo"
fi

if systemctl is-active --quiet dnsmasq; then
    log_success "dnsmasq: activo"
else
    log_error "dnsmasq: inactivo"
fi

if systemctl is-active --quiet sentinel-iot; then
    log_success "sentinel-iot: activo"
else
    log_error "sentinel-iot: inactivo"
fi

# Paso 14: Mostrar información de acceso
echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}║          ¡Instalación completada exitosamente!            ║${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Información de acceso:${NC}"
echo ""
echo -e "  ${YELLOW}Red Wi-Fi IoT:${NC}"
echo -e "    SSID: ${GREEN}SENTINEL_IoT${NC}"
echo -e "    Contraseña: ${GREEN}$WIFI_PASSWORD${NC}"
echo ""
echo -e "  ${YELLOW}Interfaz Web:${NC}"
echo -e "    URL: ${GREEN}https://$(hostname -I | awk '{print $1}')${NC}"
echo -e "    URL local: ${GREEN}https://sentinel.local${NC}"
echo ""
echo -e "  ${YELLOW}API:${NC}"
echo -e "    Documentación: ${GREEN}https://$(hostname -I | awk '{print $1}')/api/docs${NC}"
echo ""
echo -e "${YELLOW}Nota:${NC} Guarda la contraseña Wi-Fi en un lugar seguro"
echo ""

# Guardar información en archivo
cat > /root/sentinel-info.txt << EOF
SENTINEL IoT v2.0 - Información de Instalación
================================================

Fecha de instalación: $(date)

Red Wi-Fi IoT:
  SSID: SENTINEL_IoT
  Contraseña: $WIFI_PASSWORD
  Gateway: $IOT_GATEWAY

Interfaz Web:
  URL: https://$(hostname -I | awk '{print $1}')
  URL local: https://sentinel.local

API:
  Documentación: https://$(hostname -I | awk '{print $1}')/api/docs

Directorios:
  Instalación: $INSTALL_DIR
  Datos: $DATA_DIR
  Logs: $LOG_DIR

Servicios:
  - hostapd
  - dnsmasq
  - nftables
  - sentinel-iot

Comandos útiles:
  - Ver logs: journalctl -u sentinel-iot -f
  - Reiniciar: systemctl restart sentinel-iot
  - Estado: systemctl status sentinel-iot
EOF

log_success "Información guardada en /root/sentinel-info.txt"

exit 0
