#!/bin/bash
#
# SENTINEL IoT v2.0 - Script para corregir problema de DHCP en Wi-Fi
#
# Este script diagnostica y corrige problemas con la asignación de IPs
# en la red Wi-Fi SENTINEL_IoT
#

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    log_error "Este script debe ejecutarse como root (sudo)"
    exit 1
fi

echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                                                           ║${NC}"
echo -e "${BLUE}║     SENTINEL IoT - Corrección de DHCP en Wi-Fi           ║${NC}"
echo -e "${BLUE}║                                                           ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Variables
IOT_INTERFACE="wlan1"
IOT_GATEWAY="192.168.100.1"
IOT_NETWORK="192.168.100.0/24"

# Paso 1: Diagnóstico inicial
log_info "Realizando diagnóstico del sistema..."
echo ""

# Verificar interfaz wlan1
if ! ip link show $IOT_INTERFACE > /dev/null 2>&1; then
    log_error "Interfaz $IOT_INTERFACE no encontrada"
    log_info "Verifica que el adaptador Wi-Fi USB esté conectado"
    log_info "Ejecuta: lsusb | grep -i wireless"
    exit 1
fi
log_success "Interfaz $IOT_INTERFACE encontrada"

# Verificar estado de hostapd
if systemctl is-active --quiet hostapd; then
    log_success "hostapd está activo"
else
    log_warning "hostapd NO está activo"
fi

# Verificar estado de dnsmasq
if systemctl is-active --quiet dnsmasq; then
    log_success "dnsmasq está activo"
else
    log_warning "dnsmasq NO está activo"
fi

echo ""
log_info "Estado actual de la interfaz $IOT_INTERFACE:"
ip addr show $IOT_INTERFACE | grep -E "inet |state " | sed 's/^/  /'
echo ""

# Paso 2: Detener servicios
log_info "Deteniendo servicios..."
systemctl stop hostapd 2>/dev/null || true
systemctl stop dnsmasq 2>/dev/null || true
sleep 2

# Paso 3: Configurar interfaz wlan1
log_info "Configurando interfaz $IOT_INTERFACE..."

# Bajar la interfaz
ip link set $IOT_INTERFACE down 2>/dev/null || true
sleep 1

# Limpiar configuración anterior
ip addr flush dev $IOT_INTERFACE 2>/dev/null || true

# Levantar la interfaz
ip link set $IOT_INTERFACE up
sleep 1

# Asignar IP
ip addr add $IOT_GATEWAY/24 dev $IOT_INTERFACE
sleep 1

log_success "Interfaz configurada con IP $IOT_GATEWAY"

# Paso 4: Verificar y corregir configuración de hostapd
log_info "Verificando configuración de hostapd..."

if [ ! -f /etc/hostapd/hostapd.conf ]; then
    log_warning "Archivo de configuración de hostapd no encontrado, creando..."
    
    # Generar contraseña si no existe
    if [ -z "$WIFI_PASSWORD" ]; then
        WIFI_PASSWORD=$(openssl rand -base64 16 | tr -d "=+/" | cut -c1-16)
    fi
    
    cat > /etc/hostapd/hostapd.conf << EOF
interface=$IOT_INTERFACE
driver=nl80211
ssid=SENTINEL_IoT
hw_mode=g
channel=6
country_code=US
ieee80211n=1
wmm_enabled=1

# Seguridad WPA2
wpa=2
wpa_passphrase=$WIFI_PASSWORD
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP

# Control de acceso
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
EOF
    
    log_success "Configuración de hostapd creada"
    log_warning "Contraseña Wi-Fi: $WIFI_PASSWORD"
    echo "$WIFI_PASSWORD" > /root/sentinel-wifi-password.txt
else
    log_success "Configuración de hostapd encontrada"
fi

# Asegurar que hostapd use el archivo de configuración correcto
if ! grep -q "^DAEMON_CONF=" /etc/default/hostapd 2>/dev/null; then
    echo 'DAEMON_CONF="/etc/hostapd/hostapd.conf"' >> /etc/default/hostapd
fi

# Paso 5: Verificar y corregir configuración de dnsmasq
log_info "Verificando configuración de dnsmasq..."

# Detener dnsmasq si está corriendo
killall dnsmasq 2>/dev/null || true
sleep 1

# Backup de configuración anterior
if [ -f /etc/dnsmasq.conf ]; then
    cp /etc/dnsmasq.conf /etc/dnsmasq.conf.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
fi

# Crear nueva configuración
cat > /etc/dnsmasq.conf << EOF
# Interfaz a usar
interface=$IOT_INTERFACE

# No usar otras interfaces
bind-interfaces

# Rango DHCP
dhcp-range=192.168.100.10,192.168.100.250,255.255.255.0,24h

# Gateway (esta Raspberry Pi)
dhcp-option=3,$IOT_GATEWAY

# DNS (esta Raspberry Pi)
dhcp-option=6,$IOT_GATEWAY

# Dominio local
domain=sentinel.local
local=/sentinel.local/

# Logs
log-dhcp
log-queries

# Archivo de leases
dhcp-leasefile=/var/lib/misc/dnsmasq.leases

# No leer /etc/resolv.conf
no-resolv

# Usar estos servidores DNS upstream
server=8.8.8.8
server=8.8.4.4

# No reenviar consultas sin dominio
domain-needed

# No reenviar direcciones privadas
bogus-priv
EOF

log_success "Configuración de dnsmasq creada"

# Crear directorio para leases si no existe
mkdir -p /var/lib/misc
touch /var/lib/misc/dnsmasq.leases
chmod 644 /var/lib/misc/dnsmasq.leases

# Paso 6: Verificar IP forwarding
log_info "Verificando IP forwarding..."

if [ "$(cat /proc/sys/net/ipv4/ip_forward)" != "1" ]; then
    log_warning "IP forwarding deshabilitado, habilitando..."
    echo 1 > /proc/sys/net/ipv4/ip_forward
    
    # Hacer permanente
    if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
        echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
    fi
    log_success "IP forwarding habilitado"
else
    log_success "IP forwarding ya está habilitado"
fi

# Paso 7: Configurar NAT con nftables
log_info "Configurando NAT..."

# Obtener interfaz principal (normalmente eth0)
MAIN_INTERFACE=$(ip route | grep default | awk '{print $5}' | head -1)
if [ -z "$MAIN_INTERFACE" ]; then
    MAIN_INTERFACE="eth0"
fi

log_info "Interfaz principal detectada: $MAIN_INTERFACE"

# Configurar NAT
nft add table ip nat 2>/dev/null || true
nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; } 2>/dev/null || true
nft add rule ip nat postrouting oifname "$MAIN_INTERFACE" masquerade 2>/dev/null || true

log_success "NAT configurado"

# Paso 8: Iniciar servicios
log_info "Iniciando servicios..."

# Iniciar dnsmasq
log_info "Iniciando dnsmasq..."
systemctl start dnsmasq
sleep 2

if systemctl is-active --quiet dnsmasq; then
    log_success "dnsmasq iniciado correctamente"
else
    log_error "dnsmasq no pudo iniciarse"
    log_info "Ver logs: journalctl -u dnsmasq -n 50"
fi

# Iniciar hostapd
log_info "Iniciando hostapd..."
systemctl unmask hostapd 2>/dev/null || true
systemctl start hostapd
sleep 3

if systemctl is-active --quiet hostapd; then
    log_success "hostapd iniciado correctamente"
else
    log_error "hostapd no pudo iniciarse"
    log_info "Ver logs: journalctl -u hostapd -n 50"
fi

# Paso 9: Verificación final
echo ""
log_info "Verificación final del sistema..."
echo ""

# Estado de servicios
echo -e "${YELLOW}Estado de servicios:${NC}"
if systemctl is-active --quiet hostapd; then
    echo -e "  ${GREEN}✓${NC} hostapd: activo"
else
    echo -e "  ${RED}✗${NC} hostapd: inactivo"
fi

if systemctl is-active --quiet dnsmasq; then
    echo -e "  ${GREEN}✓${NC} dnsmasq: activo"
else
    echo -e "  ${RED}✗${NC} dnsmasq: inactivo"
fi

# Configuración de red
echo ""
echo -e "${YELLOW}Configuración de red:${NC}"
ip addr show $IOT_INTERFACE | grep "inet " | awk '{print "  IP: " $2}'

# Procesos escuchando
echo ""
echo -e "${YELLOW}Servicios DHCP:${NC}"
if ps aux | grep -v grep | grep dnsmasq > /dev/null; then
    echo -e "  ${GREEN}✓${NC} dnsmasq está corriendo"
    ps aux | grep -v grep | grep dnsmasq | awk '{print "    PID: " $2}'
else
    echo -e "  ${RED}✗${NC} dnsmasq NO está corriendo"
fi

# Leases activos
echo ""
echo -e "${YELLOW}Dispositivos conectados:${NC}"
if [ -f /var/lib/misc/dnsmasq.leases ]; then
    LEASE_COUNT=$(wc -l < /var/lib/misc/dnsmasq.leases)
    echo "  Total: $LEASE_COUNT dispositivos"
    if [ $LEASE_COUNT -gt 0 ]; then
        cat /var/lib/misc/dnsmasq.leases | awk '{print "  - IP: " $3 " | MAC: " $2 " | Nombre: " $4}' | head -5
    fi
else
    echo "  Ninguno (archivo de leases no encontrado)"
fi

# Resultado final
echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}║          Configuración completada                         ║${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

echo -e "${YELLOW}Información de la red Wi-Fi:${NC}"
echo -e "  SSID: ${GREEN}SENTINEL_IoT${NC}"

if [ -f /root/sentinel-wifi-password.txt ]; then
    WIFI_PASS=$(cat /root/sentinel-wifi-password.txt)
    echo -e "  Contraseña: ${GREEN}$WIFI_PASS${NC}"
elif grep -q "wpa_passphrase=" /etc/hostapd/hostapd.conf; then
    WIFI_PASS=$(grep "wpa_passphrase=" /etc/hostapd/hostapd.conf | cut -d= -f2)
    echo -e "  Contraseña: ${GREEN}$WIFI_PASS${NC}"
fi

echo -e "  Gateway: ${GREEN}$IOT_GATEWAY${NC}"
echo -e "  Rango DHCP: ${GREEN}192.168.100.10 - 192.168.100.250${NC}"
echo ""

echo -e "${YELLOW}Prueba de conexión:${NC}"
echo "  1. Busca la red Wi-Fi 'SENTINEL_IoT' en tu dispositivo"
echo "  2. Conéctate usando la contraseña mostrada arriba"
echo "  3. Deberías obtener una IP en el rango 192.168.100.x"
echo "  4. Accede al dashboard: http://192.168.100.1:8000"
echo ""

echo -e "${YELLOW}Comandos útiles:${NC}"
echo "  Ver logs de dnsmasq: ${GREEN}journalctl -u dnsmasq -f${NC}"
echo "  Ver logs de hostapd: ${GREEN}journalctl -u hostapd -f${NC}"
echo "  Ver dispositivos: ${GREEN}cat /var/lib/misc/dnsmasq.leases${NC}"
echo "  Reiniciar Wi-Fi: ${GREEN}sudo systemctl restart hostapd dnsmasq${NC}"
echo ""

if ! systemctl is-active --quiet hostapd || ! systemctl is-active --quiet dnsmasq; then
    log_warning "Algunos servicios no están activos. Ver logs para más detalles."
    exit 1
fi

log_success "Sistema listo para aceptar conexiones"
exit 0
