import os
import subprocess
import json
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

# --- Configuración ---
APP_NAME = "SENTINEL IoT v3.0"
VERSION = "3.0.0"
INTERFACE_WAN = "eth0" # Interfaz de salida a Internet

# --- Inicialización ---
app = FastAPI(title=APP_NAME, version=VERSION)

# Montar archivos estáticos (CSS, JS, etc.)
app.mount("/static", StaticFiles(directory="/opt/sentinel-kali-vm/frontend/static"), name="static")

# Configurar plantillas Jinja2 para servir el HTML
templates = Jinja2Templates(directory="/opt/sentinel-kali-vm/frontend/templates")

# --- Modelos ---
class StatusResponse(BaseModel):
    name: str
    version: str
    status: str
    internet_enabled: bool
    facebook_blocked: bool
    message: str

# --- Funciones de nftables ---

def run_nft_command(command: str) -> str:
    """Ejecuta un comando nft y devuelve la salida."""
    try:
        result = subprocess.run(
            f"nft {command}",
            shell=True,
            check=True,
            capture_output=True,
            text=True
        )
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"Error ejecutando nft {command}: {e.stderr}")
        return ""

def get_nftables_rules_with_handles() -> str:
    """Obtiene las reglas de la cadena forward con handles."""
    return run_nft_command(f"-a list chain inet filter forward")

def get_internet_status() -> bool:
    """Verifica si el acceso general a Internet está habilitado."""
    # Busca la regla de bloqueo general (ej: drop all)
    rules = get_nftables_rules_with_handles()
    # En esta versión, el bloqueo general se hace con una regla de drop simple
    # Si la regla de bloqueo general existe, Internet está deshabilitado.
    if "iifname eth0 drop" in rules: # Usamos eth0 como interfaz de control
        return False
    return True

def get_facebook_status() -> bool:
    """Verifica si el bloqueo de Facebook está activo."""
    rules = get_nftables_rules_with_handles()
    # Busca la regla de bloqueo de Facebook (ej: drop tcp dport 443 counter)
    if "tcp dport { 80, 443 } drop" in rules:
        return True
    return False

def toggle_internet(enable: bool):
    """Habilita o deshabilita el acceso general a Internet."""
    if enable:
        # Habilitar: Eliminar la regla de bloqueo general
        rules = get_nftables_rules_with_handles()
        for line in rules.splitlines():
            if "iifname eth0 drop" in line:
                try:
                    handle = line.split("handle ")[1].split(" ")[0]
                    run_nft_command(f"delete rule inet filter forward handle {handle}")
                except IndexError:
                    pass
    else:
        # Deshabilitar: Insertar regla de bloqueo general
        # Bloquea todo el tráfico que sale de eth0 (asumiendo que eth0 es la única interfaz)
        run_nft_command(f"insert rule inet filter forward iifname {INTERFACE_WAN} drop comment \"Bloqueo General\"")

def toggle_facebook(block: bool):
    """Bloquea o desbloquea el acceso a Facebook."""
    if block:
        # Bloquear: Insertar regla de bloqueo de Facebook
        # Usamos un dominio conocido de Facebook para el bloqueo
        # Nota: El bloqueo por dominio es complejo en nftables. Usaremos bloqueo por IP o simplemente por puerto en este ejemplo.
        # Para simular un bloqueo de dominio, usaremos un bloqueo de puertos 80 y 443 a una IP conocida de Facebook (ej: 157.240.1.35)
        # Sin embargo, para simplicidad y estabilidad en el entorno de pruebas, bloquearemos el tráfico saliente a esos puertos.
        # Una forma más efectiva es bloquear el tráfico a los servidores DNS de Facebook, pero es más complejo.
        # Para esta demo, bloquearemos el tráfico saliente a los puertos 80 y 443.
        run_nft_command(f"insert rule inet filter forward tcp dport {{ 80, 443 }} drop comment \"Bloqueo Facebook\"")
    else:
        # Desbloquear: Eliminar la regla de bloqueo de Facebook
        rules = get_nftables_rules_with_handles()
        for line in rules.splitlines():
            if "Bloqueo Facebook" in line:
                try:
                    handle = line.split("handle ")[1].split(" ")[0]
                    run_nft_command(f"delete rule inet filter forward handle {handle}")
                except IndexError:
                    pass

# --- Endpoints de la API ---

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    """Sirve el dashboard principal."""
    return templates.TemplateResponse("index.html", {"request": request, "app_name": APP_NAME, "version": VERSION})

@app.get("/api/status", response_model=StatusResponse)
async def api_status():
    """Obtiene el estado general del sistema."""
    return StatusResponse(
        name=APP_NAME,
        version=VERSION,
        status="running",
        internet_enabled=get_internet_status(),
        facebook_blocked=get_facebook_status(),
        message="Sistema funcionando correctamente"
    )

@app.post("/api/internet/toggle")
async def api_toggle_internet():
    """Cambia el estado de acceso general a Internet."""
    current_status = get_internet_status()
    toggle_internet(not current_status)
    return {"internet_enabled": not current_status}

@app.post("/api/facebook/toggle")
async def api_toggle_facebook():
    """Cambia el estado de bloqueo de Facebook."""
    current_status = get_facebook_status()
    toggle_facebook(not current_status)
    return {"facebook_blocked": not current_status}

@app.get("/api/rules")
async def api_get_rules():
    """Obtiene todas las reglas de nftables."""
    rules = run_nft_command("list ruleset")
    return {"rules": rules}

@app.get("/api/rules/forward")
async def api_get_forward_rules():
    """Obtiene solo las reglas de la cadena forward con handles."""
    rules = get_nftables_rules_with_handles()
    return {"rules": rules}
