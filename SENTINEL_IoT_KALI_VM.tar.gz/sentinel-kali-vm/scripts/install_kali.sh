#!/bin/bash

# Script de Instalación SENTINEL IoT para Kali Linux VM (eth0)
# Versión: 3.0 - Control de Firewall

PROJECT_DIR="/opt/sentinel-kali-vm"
APP_DIR="$PROJECT_DIR/backend/app"
VENV_DIR="$PROJECT_DIR/venv"
SERVICE_FILE="/etc/systemd/system/sentinel-kali.service"

echo "================================================="
echo " SENTINEL IoT v3.0 - Instalador para Kali Linux VM"
echo "================================================="

# 1. Instalar dependencias del sistema
echo "[1/5] Instalando dependencias del sistema..."
sudo apt update
sudo apt install -y python3 python3-pip python3-venv nftables net-tools iproute2 which

# 2. Configurar nftables (Reglas base)
echo "[2/5] Configurando nftables (Firewall base)..."
# Limpiar reglas existentes y establecer políticas por defecto
sudo nft flush ruleset
sudo nft add table inet filter
sudo nft add chain inet filter input { type filter hook input priority 0 \; }
sudo nft add chain inet filter forward { type filter hook forward priority 0 \; }
sudo nft add chain inet filter output { type filter hook output priority 0 \; }

# Reglas de NAT (para que la VM pueda compartir Internet si es necesario)
sudo nft add table ip nat
sudo nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; }
sudo nft add rule ip nat postrouting oifname eth0 masquerade

# Reglas por defecto:
sudo nft add rule inet filter input ct state established,related accept
sudo nft add rule inet filter input iifname lo accept
sudo nft add rule inet filter input tcp dport 22 accept comment "SSH"
sudo nft add rule inet filter input tcp dport 8000 accept comment "Dashboard API"
sudo nft add rule inet filter input drop

# Guardar reglas
sudo nft list ruleset > /etc/nftables.conf
sudo systemctl enable nftables
sudo systemctl start nftables

# 3. Crear estructura de directorios y copiar archivos
echo "[3/5] Creando estructura de directorios y copiando archivos..."
sudo mkdir -p $PROJECT_DIR
sudo cp -r /home/ubuntu/sentinel-kali-vm/* $PROJECT_DIR/
sudo chown -R root:root $PROJECT_DIR

# 4. Configurar entorno virtual e instalar dependencias Python
echo "[4/5] Configurando entorno virtual e instalando dependencias Python..."
python3 -m venv $VENV_DIR
$VENV_DIR/bin/pip install --upgrade pip
$VENV_DIR/bin/pip install fastapi uvicorn python-multipart jinja2 requests pydantic-settings

# 5. Crear servicio systemd
echo "[5/5] Creando servicio systemd..."
sudo bash -c "cat > $SERVICE_FILE" << EOF
[Unit]
Description=SENTINEL IoT Kali VM Backend Service
After=network.target nftables.service

[Service]
Type=simple
User=root
WorkingDirectory=$PROJECT_DIR/backend
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$VENV_DIR/bin"
ExecStart=$VENV_DIR/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Recargar y habilitar servicio
sudo systemctl daemon-reload
sudo systemctl enable sentinel-kali
sudo systemctl start sentinel-kali

echo "================================================="
echo " ¡Instalación Completa!"
echo " Dashboard accesible en: http://127.0.0.1:8000"
echo "================================================="
echo "Reinicia la VM para asegurar que nftables se cargue correctamente."
echo "================================================="
