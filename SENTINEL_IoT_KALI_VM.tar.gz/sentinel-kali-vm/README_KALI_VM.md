# SENTINEL IoT v3.0 - Guía de Instalación para Kali Linux VM

Esta versión de SENTINEL IoT está optimizada para ser ejecutada en una Máquina Virtual de Kali Linux (VirtualBox o VMware), utilizando la interfaz `eth0` para el control de tráfico.

## 🎯 Funcionalidades

- **Control de Internet ON/OFF**: Habilita/Deshabilita el acceso a Internet para la VM.
- **Bloqueo de Facebook**: Botón dedicado para bloquear el acceso a Facebook (puertos 80 y 443).
- **Visualización de Reglas**: Muestra las reglas de `nftables` en tiempo real.
- **Arquitectura Simple**: Sin `hostapd` ni `dnsmasq`.

## 📦 Contenido del Paquete

| Archivo | Descripción |
|:---|:---|
| `scripts/install_kali.sh` | Script de instalación automática. |
| `backend/app/main.py` | Backend FastAPI con lógica de `nftables`. |
| `frontend/templates/index.html` | Dashboard web (Frontend). |
| `frontend/static/css/style.css` | Estilos básicos del dashboard. |

## 🚀 Instalación en Kali Linux VM

### 1. Requisitos Previos

- **Sistema Operativo**: Kali Linux (o cualquier Debian/Ubuntu reciente).
- **Conexión a Internet**: La VM debe tener acceso a Internet para descargar dependencias.
- **Privilegios**: El usuario debe tener permisos `sudo`.

### 2. Transferir y Descomprimir

Transfiere el archivo `SENTINEL_IoT_KALI_VM.tar.gz` a tu VM y descomprímelo:

```bash
tar -xzf SENTINEL_IoT_KALI_VM.tar.gz
cd sentinel-kali-vm
```

### 3. Ejecutar el Instalador

El script `install_kali.sh` se encarga de todo:

```bash
sudo bash scripts/install_kali.sh
```

### 4. Verificación

Al finalizar, el script te indicará:

```
=================================================
 ¡Instalación Completa!
 Dashboard accesible en: http://127.0.0.1:8000
=================================================
```

## 🌐 Uso del Dashboard

1. **Abrir el Navegador** (Firefox o Chrome) en la VM.
2. **Navegar a**: `http://127.0.0.1:8000`

### Control de Internet

- **Botón "BLOQUEAR Internet"**: Inserta una regla `drop` en `nftables` para la interfaz `eth0`.
- **Botón "HABILITAR Internet"**: Elimina la regla `drop`.

### Control de Facebook

- **Botón "BLOQUEAR Facebook"**: Inserta una regla `drop` para los puertos 80 y 443.
- **Botón "DESBLOQUEAR Facebook"**: Elimina la regla.

## 🛠️ Notas Técnicas (Para Desarrolladores)

- **Interfaz de Control**: El backend asume que la interfaz de Internet es **`eth0`**. Si tu VM usa otra (ej. `enp0s3`), debes cambiar la variable `INTERFACE_WAN` en `backend/app/main.py`.
- **Lógica de Bloqueo**: El bloqueo de Facebook se realiza bloqueando el tráfico saliente en los puertos 80 y 443. Para un bloqueo de dominio más robusto, se requeriría un proxy DNS o inspección de paquetes.
- **nftables**: El script configura una tabla `inet filter` básica y una tabla `ip nat` para el enmascaramiento. Las reglas de control se insertan/eliminan en la cadena `inet filter forward`.
- **Servicio**: El backend se ejecuta como un servicio `systemd` llamado `sentinel-kali` con privilegios de `root` para manipular `nftables`.
