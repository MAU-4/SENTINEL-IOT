#!/usr/bin/env python3
"""
SENTINEL IoT - Backend Simplificado
Solo control de Internet ON/OFF y visualización de reglas
"""

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import subprocess
import os

app = FastAPI(title="SENTINEL IoT Simple", version="2.1")

# Ruta del frontend
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "frontend")

def run_command(command):
    """Ejecuta un comando del sistema y devuelve la salida"""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=10
        )
        return {
            "success": result.returncode == 0,
            "output": result.stdout,
            "error": result.stderr
        }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "error": str(e)
        }

def get_internet_status():
    """Verifica si Internet está habilitado o bloqueado"""
    result = run_command("/usr/sbin/nft list chain inet filter forward")
    
    if not result["success"]:
        return {"enabled": True, "error": "No se pudo verificar el estado"}
    
    # Si hay una regla 'drop', Internet está bloqueado
    if "drop" in result["output"].lower():
        return {"enabled": False, "error": None}
    else:
        return {"enabled": True, "error": None}

def enable_internet():
    """Habilita el acceso a Internet eliminando la regla de bloqueo"""
    # Primero, obtener el handle de la regla drop
    result = run_command("/usr/sbin/nft -a list chain inet filter forward")
    
    if not result["success"]:
        return {"success": False, "message": "Error al listar reglas"}
    
    # Buscar el handle de la regla drop
    for line in result["output"].split("\n"):
        if "drop" in line.lower() and "handle" in line:
            # Extraer el handle
            handle = line.split("handle")[-1].strip()
            # Eliminar la regla
            delete_result = run_command(f"/usr/sbin/nft delete rule inet filter forward handle {handle}")
            if delete_result["success"]:
                return {"success": True, "message": "Internet habilitado"}
            else:
                return {"success": False, "message": f"Error al eliminar regla: {delete_result['error']}"}
    
    return {"success": True, "message": "Internet ya estaba habilitado"}

def disable_internet():
    """Deshabilita el acceso a Internet agregando una regla de bloqueo"""
    # Verificar si ya existe una regla drop
    status = get_internet_status()
    if not status["enabled"]:
        return {"success": True, "message": "Internet ya estaba bloqueado"}
    
    # Agregar regla drop al inicio de la cadena forward
    result = run_command("/usr/sbin/nft insert rule inet filter forward drop")
    
    if result["success"]:
        return {"success": True, "message": "Internet bloqueado"}
    else:
        return {"success": False, "message": f"Error al bloquear: {result['error']}"}

def get_nftables_rules():
    """Obtiene todas las reglas de nftables"""
    result = run_command("/usr/sbin/nft list ruleset")
    
    if result["success"]:
        return {"success": True, "rules": result["output"]}
    else:
        return {"success": False, "rules": f"Error: {result['error']}"}

# ============================================================================
# RUTAS DE LA API
# ============================================================================

@app.get("/")
async def root():
    """Sirve el frontend"""
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    
    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            content = f.read()
        return HTMLResponse(content=content)
    else:
        return JSONResponse({
            "name": "SENTINEL IoT Simple",
            "version": "2.1",
            "status": "running",
            "message": "Frontend no encontrado. API funcionando correctamente."
        })

@app.get("/api/status")
async def api_status():
    """Estado general del sistema"""
    internet_status = get_internet_status()
    
    return {
        "system": "SENTINEL IoT Simple",
        "version": "2.1",
        "internet_enabled": internet_status["enabled"],
        "status": "running"
    }

@app.get("/api/internet/status")
async def internet_status():
    """Estado del acceso a Internet"""
    status = get_internet_status()
    return {
        "enabled": status["enabled"],
        "message": "Internet habilitado" if status["enabled"] else "Internet bloqueado"
    }

@app.post("/api/internet/enable")
async def api_enable_internet():
    """Habilita el acceso a Internet"""
    result = enable_internet()
    status = get_internet_status()
    
    return {
        "success": result["success"],
        "message": result["message"],
        "enabled": status["enabled"]
    }

@app.post("/api/internet/disable")
async def api_disable_internet():
    """Deshabilita el acceso a Internet"""
    result = disable_internet()
    status = get_internet_status()
    
    return {
        "success": result["success"],
        "message": result["message"],
        "enabled": status["enabled"]
    }

@app.post("/api/internet/toggle")
async def api_toggle_internet():
    """Cambia el estado de Internet (ON/OFF)"""
    current_status = get_internet_status()
    
    if current_status["enabled"]:
        result = disable_internet()
    else:
        result = enable_internet()
    
    new_status = get_internet_status()
    
    return {
        "success": result["success"],
        "message": result["message"],
        "enabled": new_status["enabled"]
    }

@app.get("/api/rules")
async def api_get_rules():
    """Obtiene las reglas de nftables"""
    result = get_nftables_rules()
    return result

# ============================================================================
# INICIO DE LA APLICACIÓN
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    print("Iniciando SENTINEL IoT Simple...")
    print("Accede a: http://0.0.0.0:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)
