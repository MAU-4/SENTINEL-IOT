#!/bin/bash

################################################################################
# SENTINEL IoT SIMPLE - Instalador
# Versión ultra-simplificada con solo control de Internet
################################################################################

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}SENTINEL IoT SIMPLE - Instalador${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

# Verificar root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}[ERROR]${NC} Este script debe ejecutarse como root (sudo)"
   exit 1
fi

INSTALL_DIR="/opt/sentinel-simple"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Paso 1: Instalar dependencias mínimas
echo -e "${YELLOW}[1/6]${NC} Instalando dependencias..."
apt-get update -qq
apt-get install -y python3 python3-pip python3-venv nftables > /dev/null 2>&1
echo -e "${GREEN}✓${NC} Dependencias instaladas"
echo ""

# Paso 2: Crear directorio de instalación
echo -e "${YELLOW}[2/6]${NC} Creando directorio de instalación..."
mkdir -p "$INSTALL_DIR/frontend"
echo -e "${GREEN}✓${NC} Directorio creado"
echo ""

# Paso 3: Copiar archivos
echo -e "${YELLOW}[3/6]${NC} Copiando archivos..."

# Copiar backend
if [ -f "$SCRIPT_DIR/simple_backend.py" ]; then
    cp "$SCRIPT_DIR/simple_backend.py" "$INSTALL_DIR/app.py"
    echo -e "${GREEN}✓${NC} Backend copiado"
else
    echo -e "${RED}✗${NC} No se encontró simple_backend.py"
    exit 1
fi

# Copiar frontend
if [ -f "$SCRIPT_DIR/simple_index.html" ]; then
    cp "$SCRIPT_DIR/simple_index.html" "$INSTALL_DIR/frontend/index.html"
    echo -e "${GREEN}✓${NC} Frontend copiado"
else
    echo -e "${RED}✗${NC} No se encontró simple_index.html"
    exit 1
fi

chmod -R 755 "$INSTALL_DIR"
echo ""

# Paso 4: Crear entorno virtual e instalar dependencias
echo -e "${YELLOW}[4/6]${NC} Configurando entorno Python..."
python3 -m venv "$INSTALL_DIR/venv" > /dev/null 2>&1
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip > /dev/null 2>&1
"$INSTALL_DIR/venv/bin/pip" install fastapi uvicorn > /dev/null 2>&1
echo -e "${GREEN}✓${NC} Entorno Python configurado"
echo ""

# Paso 5: Crear servicio systemd
echo -e "${YELLOW}[5/6]${NC} Creando servicio systemd..."
cat > /etc/systemd/system/sentinel-simple.service << EOF
[Unit]
Description=SENTINEL IoT Simple - Control de Internet
After=network.target nftables.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$INSTALL_DIR/venv/bin"
ExecStart=$INSTALL_DIR/venv/bin/python3 $INSTALL_DIR/app.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable sentinel-simple > /dev/null 2>&1
echo -e "${GREEN}✓${NC} Servicio creado"
echo ""

# Paso 6: Iniciar servicio
echo -e "${YELLOW}[6/6]${NC} Iniciando servicio..."
systemctl start sentinel-simple
sleep 3
echo -e "${GREEN}✓${NC} Servicio iniciado"
echo ""

# Verificación
echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}Verificación${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

if systemctl is-active --quiet sentinel-simple; then
    echo -e "${GREEN}✓${NC} Servicio activo"
else
    echo -e "${RED}✗${NC} Servicio no activo"
fi

if netstat -tlnp 2>/dev/null | grep -q ":8000"; then
    echo -e "${GREEN}✓${NC} Puerto 8000 escuchando"
else
    echo -e "${RED}✗${NC} Puerto 8000 no escuchando"
fi

echo ""
echo -e "${CYAN}========================================${NC}"
echo -e "${GREEN}¡Instalación Completada!${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""
echo -e "${YELLOW}Accede al dashboard:${NC}"
echo -e "  http://127.0.0.1:8000"
echo -e "  http://192.168.50.1:8000"
echo ""
echo -e "${YELLOW}Comandos útiles:${NC}"
echo -e "  Ver estado:  sudo systemctl status sentinel-simple"
echo -e "  Ver logs:    sudo journalctl -u sentinel-simple -f"
echo -e "  Reiniciar:   sudo systemctl restart sentinel-simple"
echo -e "  Detener:     sudo systemctl stop sentinel-simple"
echo ""
