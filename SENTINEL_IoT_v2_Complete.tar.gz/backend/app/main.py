"""
SENTINEL IoT v2.0 - API Principal
"""
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import List, Optional
import logging
from datetime import datetime

from .core.config import settings
from .services.firewall_manager import firewall_manager, FirewallRule, Action, Protocol, Direction
from .services.device_manager import device_manager, DeviceInfo

# Configurar logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Crear aplicación FastAPI
app = FastAPI(
    title=settings.PROJECT_NAME,
    description=settings.DESCRIPTION,
    version=settings.VERSION,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================================
# EVENTOS DE INICIO/CIERRE
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Inicialización al arrancar"""
    logger.info(f"Iniciando {settings.PROJECT_NAME} v{settings.VERSION}")
    
    # Inicializar firewall
    if firewall_manager.initialize():
        logger.info("Firewall inicializado correctamente")
    else:
        logger.error("Error al inicializar firewall")
    
    # Escanear dispositivos
    devices = device_manager.scan_network()
    logger.info(f"Detectados {len(devices)} dispositivos")


@app.on_event("shutdown")
async def shutdown_event():
    """Limpieza al cerrar"""
    logger.info("Cerrando aplicación")


# ============================================================================
# ENDPOINTS - SISTEMA
# ============================================================================

@app.get("/")
async def root():
    """Endpoint raíz"""
    return {
        "name": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "running",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/api/v1/health")
async def health_check():
    """Verificación de salud del sistema"""
    return {
        "status": "healthy",
        "firewall": firewall_manager.initialized,
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/api/v1/stats")
async def get_system_stats():
    """Obtiene estadísticas del sistema"""
    try:
        firewall_stats = firewall_manager.get_statistics()
        device_stats = device_manager.get_statistics()
        
        return {
            "firewall": firewall_stats,
            "devices": device_stats,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error al obtener estadísticas: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ENDPOINTS - DISPOSITIVOS
# ============================================================================

@app.get("/api/v1/devices")
async def list_devices(online_only: bool = False):
    """Lista todos los dispositivos"""
    try:
        if online_only:
            devices = device_manager.get_online_devices()
        else:
            devices = device_manager.get_all_devices()
        
        return {
            "devices": [
                {
                    "mac_address": d.mac_address,
                    "ip_address": d.ip_address,
                    "hostname": d.hostname,
                    "manufacturer": d.manufacturer,
                    "device_type": device_manager.classify_device(d),
                    "first_seen": d.first_seen.isoformat(),
                    "last_seen": d.last_seen.isoformat(),
                    "is_new": d.is_new
                }
                for d in devices
            ],
            "total": len(devices),
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error al listar dispositivos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/devices/{mac_address}")
async def get_device(mac_address: str):
    """Obtiene información de un dispositivo"""
    try:
        device = device_manager.get_device(mac_address)
        
        if not device:
            raise HTTPException(status_code=404, detail="Dispositivo no encontrado")
        
        return {
            "mac_address": device.mac_address,
            "ip_address": device.ip_address,
            "hostname": device.hostname,
            "manufacturer": device.manufacturer,
            "device_type": device_manager.classify_device(device),
            "first_seen": device.first_seen.isoformat(),
            "last_seen": device.last_seen.isoformat(),
            "is_new": device.is_new
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error al obtener dispositivo: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/devices/scan")
async def scan_devices():
    """Escanea la red en busca de dispositivos"""
    try:
        devices = device_manager.scan_network()
        new_devices = device_manager.get_new_devices()
        
        return {
            "total_devices": len(devices),
            "new_devices": len(new_devices),
            "devices": [
                {
                    "mac_address": d.mac_address,
                    "ip_address": d.ip_address,
                    "hostname": d.hostname,
                    "manufacturer": d.manufacturer,
                    "is_new": d.is_new
                }
                for d in new_devices
            ],
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error al escanear dispositivos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# ENDPOINTS - FIREWALL
# ============================================================================

@app.get("/api/v1/firewall/rules")
async def list_firewall_rules(chain: Optional[str] = None):
    """Lista las reglas del firewall"""
    try:
        rules = firewall_manager.list_rules(chain)
        
        return {
            "rules": [
                {
                    "id": r.id,
                    "name": r.name,
                    "direction": r.direction.value,
                    "source_ip": r.source_ip,
                    "dest_ip": r.dest_ip,
                    "source_port": r.source_port,
                    "dest_port": r.dest_port,
                    "protocol": r.protocol.value,
                    "action": r.action.value,
                    "enabled": r.enabled,
                    "priority": r.priority,
                    "comment": r.comment
                }
                for r in rules
            ],
            "total": len(rules),
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error al listar reglas: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/firewall/rules")
async def add_firewall_rule(
    name: str,
    direction: str,
    action: str,
    protocol: str = "all",
    source_ip: Optional[str] = None,
    dest_ip: Optional[str] = None,
    source_port: Optional[int] = None,
    dest_port: Optional[int] = None,
    priority: int = 100,
    comment: str = ""
):
    """Añade una regla al firewall"""
    try:
        rule = FirewallRule(
            name=name,
            direction=Direction(direction),
            action=Action(action),
            protocol=Protocol(protocol),
            source_ip=source_ip,
            dest_ip=dest_ip,
            source_port=source_port,
            dest_port=dest_port,
            priority=priority,
            comment=comment
        )
        
        success = firewall_manager.add_rule(rule)
        
        if success:
            return {
                "status": "success",
                "message": "Regla añadida correctamente",
                "rule": {
                    "name": rule.name,
                    "direction": rule.direction.value,
                    "action": rule.action.value
                }
            }
        else:
            raise HTTPException(status_code=400, detail="Error al añadir regla")
            
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Valor inválido: {e}")
    except Exception as e:
        logger.error(f"Error al añadir regla: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/v1/firewall/rules/{rule_id}")
async def delete_firewall_rule(rule_id: int):
    """Elimina una regla del firewall"""
    try:
        success = firewall_manager.delete_rule(rule_id)
        
        if success:
            return {
                "status": "success",
                "message": "Regla eliminada correctamente"
            }
        else:
            raise HTTPException(status_code=404, detail="Regla no encontrada")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error al eliminar regla: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/firewall/backup")
async def backup_firewall(filepath: str = "/home/ubuntu/sentinel-iot-v2/data/backups/firewall_backup.nft"):
    """Guarda backup de las reglas"""
    try:
        success = firewall_manager.backup_rules(filepath)
        
        if success:
            return {
                "status": "success",
                "message": "Backup guardado correctamente",
                "filepath": filepath
            }
        else:
            raise HTTPException(status_code=500, detail="Error al guardar backup")
            
    except Exception as e:
        logger.error(f"Error al guardar backup: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/firewall/restore")
async def restore_firewall(filepath: str):
    """Restaura reglas desde backup"""
    try:
        success = firewall_manager.restore_rules(filepath)
        
        if success:
            return {
                "status": "success",
                "message": "Reglas restauradas correctamente"
            }
        else:
            raise HTTPException(status_code=500, detail="Error al restaurar reglas")
            
    except Exception as e:
        logger.error(f"Error al restaurar reglas: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# MANEJO DE ERRORES
# ============================================================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Manejador de excepciones HTTP"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "timestamp": datetime.utcnow().isoformat()
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """Manejador de excepciones generales"""
    logger.error(f"Error no manejado: {exc}")
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "timestamp": datetime.utcnow().isoformat()
        }
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
