# Manual de Usuario - SENTINEL IoT v2.0

Este manual proporciona una guía completa para utilizar la interfaz web de SENTINEL IoT, gestionar dispositivos, configurar el firewall y analizar la seguridad de tu red.

## Tabla de Contenidos

1.  [Acceso a la Interfaz Web](#1-acceso-a-la-interfaz-web)
2.  [Dashboard Principal](#2-dashboard-principal)
    *   [2.1. Tarjetas de Estadísticas](#21-tarjetas-de-estadísticas)
    *   [2.2. Gráficos de Red](#22-gráficos-de-red)
    *   [2.3. Dispositivos Recientes](#23-dispositivos-recientes)
3.  [Gestión de Dispositivos](#3-gestión-de-dispositivos)
    *   [3.1. Lista de Dispositivos](#31-lista-de-dispositivos)
    *   [3.2. Clasificar un Nuevo Dispositivo](#32-clasificar-un-nuevo-dispositivo)
    *   [3.3. Detalles del Dispositivo](#33-detalles-del-dispositivo)
    *   [3.4. Perfiles de Seguridad](#34-perfiles-de-seguridad)
4.  [Gestión del Firewall](#4-gestión-del-firewall)
    *   [4.1. Lista de Reglas](#41-lista-de-reglas)
    *   [4.2. Crear una Nueva Regla](#42-crear-una-nueva-regla)
    *   [4.3. Prioridad de las Reglas](#43-prioridad-de-las-reglas)
5.  [Alertas y Eventos](#5-alertas-y-eventos)
6.  [Reportes y Análisis](#6-reportes-y-análisis)
7.  [Configuración del Sistema](#7-configuración-del-sistema)

---

## 1. Acceso a la Interfaz Web

Una vez completada la instalación, puedes acceder a la interfaz web de SENTINEL a través de la dirección IP de tu Raspberry Pi en el puerto `8000` (o `443` si usaste el script de instalación automática).

*   **URL:** `http://<DIRECCION_IP_RASPBERRY>:8000`
*   **URL (con SSL):** `https://<DIRECCION_IP_RASPBERRY>`

Se te presentará una pantalla de inicio de sesión. Utiliza el usuario y la contraseña creados durante la instalación.

## 2. Dashboard Principal

El dashboard es la pantalla principal y ofrece una vista general del estado de tu red IoT en tiempo real.

### 2.1. Tarjetas de Estadísticas

En la parte superior, encontrarás cuatro tarjetas con métricas clave:

*   **Dispositivos Totales:** Muestra el número total de dispositivos que se han conectado a la red y cuántos de ellos están actualmente en línea.
*   **Dispositivos Nuevos:** Indica cuántos dispositivos se han conectado por primera vez y requieren tu atención para ser clasificados.
*   **Reglas de Firewall:** Muestra el número total de reglas activas en el firewall.
*   **Estado del Sistema:** Confirma que todos los servicios de SENTINEL están operativos.

### 2.2. Gráficos de Red

*   **Tráfico de Red:** Un gráfico de área que muestra el volumen de datos enviados y recibidos por la red IoT a lo largo del tiempo. Es útil para identificar picos de actividad inusuales.
*   **Dispositivos por Tipo:** Un gráfico de pastel que desglosa los dispositivos conectados por su tipo (cámara, sensor, luz, etc.). Te ayuda a entender la composición de tu red de un vistazo.

### 2.3. Dispositivos Recientes

Una sección que muestra los últimos dispositivos que se han conectado a la red, destacando si son nuevos. Es un atajo para acceder rápidamente a los dispositivos que requieren configuración.

---

## 3. Gestión de Dispositivos

Esta sección, accesible desde el menú lateral, es donde administras todos tus dispositivos IoT.

### 3.1. Lista de Dispositivos

La página principal muestra una tabla con todos los dispositivos detectados. Las columnas incluyen:

*   **Nombre:** El nombre que le has asignado al dispositivo.
*   **Dirección IP y MAC:** Identificadores únicos del dispositivo en la red.
*   **Tipo:** La clasificación del dispositivo (ej. Cámara, Termostato).
*   **Fabricante:** El fabricante del hardware, detectado a partir de la dirección MAC.
*   **Estado:** Si el dispositivo está `En línea`, `Desconectado` o `Bloqueado`.
*   **Última vez visto:** La fecha y hora de la última conexión.

Puedes buscar, filtrar y ordenar la lista para encontrar dispositivos específicos rápidamente.

### 3.2. Clasificar un Nuevo Dispositivo

Cuando un dispositivo se conecta por primera vez, SENTINEL lo marca como "Nuevo" y lo clasifica como "Desconocido".

1.  Haz clic en el dispositivo nuevo desde el dashboard o la lista de dispositivos.
2.  En la página de detalles, se te pedirá que lo clasifiques.
3.  **Asigna un nombre descriptivo** (ej. "Cámara del Salón").
4.  **Selecciona el tipo de dispositivo** de la lista desplegable.
5.  **Asigna un perfil de seguridad** (ver sección 3.4).
6.  Guarda los cambios. El dispositivo ahora está gestionado.

### 3.3. Detalles del Dispositivo

Al hacer clic en cualquier dispositivo de la lista, accederás a su página de detalles, que incluye:

*   **Información General:** IP, MAC, fabricante, tipo, etc.
*   **Estadísticas de Tráfico:** Gráficos del uso de datos del dispositivo.
*   **Reglas de Firewall Aplicadas:** Una lista de las reglas de firewall que afectan a este dispositivo.
*   **Eventos de Seguridad:** Un historial de eventos relacionados con el dispositivo (ej. intentos de conexión bloqueados).
*   **Acciones:** Desde aquí puedes **bloquear** o **poner en cuarentena** un dispositivo sospechoso.
    *   **Bloquear:** Corta toda la comunicación del dispositivo.
    *   **Cuarentena:** Permite la comunicación solo con el sistema SENTINEL para análisis, pero bloquea el acceso a Internet y a otros dispositivos.

### 3.4. Perfiles de Seguridad

Los perfiles de seguridad son conjuntos de reglas predefinidas que simplifican la configuración del firewall.

| Perfil | Descripción | Caso de Uso |
| :--- | :--- | :--- |
| **Estricto** | Bloquea todo el acceso a Internet y a otros dispositivos en la red local. Solo permite la comunicación con el gateway de SENTINEL. | Dispositivos que no necesitan Internet para funcionar (ej. sensores de temperatura que solo reportan localmente). |
| **Moderado** | Permite el acceso a Internet para servicios en la nube necesarios (ej. servidores del fabricante), pero bloquea la comunicación con otros dispositivos locales. | La mayoría de los dispositivos IoT (cámaras, termostatos, asistentes de voz). |
| **Permisivo** | Permite el acceso a Internet y la comunicación con otros dispositivos en la red IoT. | Dispositivos que necesitan interactuar entre sí (ej. un hub de automatización). |
| **Personalizado** | No aplica ninguna regla predefinida. Debes crear manualmente todas las reglas para este dispositivo. | Para configuraciones avanzadas y específicas. |

---

## 4. Gestión del Firewall

Esta sección te da control granular sobre el tráfico de red.

### 4.1. Lista de Reglas

Aquí verás una tabla con todas las reglas de firewall activas, incluyendo las que se aplican automáticamente por los perfiles de seguridad y las que has creado manualmente.

### 4.2. Crear una Nueva Regla

El formulario para crear una nueva regla te permite definir:

*   **Nombre:** Un nombre descriptivo para la regla.
*   **Dirección:**
    *   `FORWARD`: Tráfico que pasa *a través* del firewall (ej. de un dispositivo IoT a Internet).
    *   `INPUT`: Tráfico destinado *al propio* sistema SENTINEL.
*   **Origen y Destino:** Puedes especificar direcciones IP, rangos de IP (CIDR) o seleccionar un dispositivo gestionado de una lista.
*   **Protocolo y Puerto:** Define si la regla se aplica a `TCP`, `UDP` o `ICMP`, y a qué puertos (ej. `443` para HTTPS).
*   **Acción:**
    *   `ACCEPT`: Permitir el tráfico.
    *   `DROP`: Bloquear el tráfico silenciosamente.
    *   `REJECT`: Bloquear el tráfico y notificar al origen.
*   **Prioridad:** Un número que determina el orden de ejecución de la regla (ver abajo).

**Ejemplo:** Para permitir que tu cámara de seguridad acceda a su servidor en la nube en la IP `34.22.11.88`:

*   **Nombre:** `Permitir-Cloud-Camara`
*   **Dirección:** `FORWARD`
*   **Origen:** `Cámara del Salón` (seleccionado de la lista)
*   **Destino:** `34.22.11.88`
*   **Protocolo:** `TCP`
*   **Puerto de Destino:** `443`
*   **Acción:** `ACCEPT`

### 4.3. Prioridad de las Reglas

Las reglas se procesan en orden de prioridad, de menor a mayor. Una regla con prioridad `10` se ejecutará antes que una con prioridad `100`. La primera regla que coincida con el tráfico determinará la acción. La política por defecto es `DROP`, por lo que si ningún tráfico coincide con una regla `ACCEPT`, será bloqueado.

---

## 5. Alertas y Eventos

SENTINEL registra todos los eventos de seguridad importantes. En esta sección puedes ver un historial cronológico de:

*   Nuevos dispositivos detectados.
*   Intentos de conexión bloqueados por el firewall.
*   Anomalías detectadas por el motor de Machine Learning.
*   Cambios en la configuración del sistema.

You can filter events by severity (`Información`, `Advertencia`, `Crítico`) and configure notifications to be sent via email or Telegram for critical alerts.

## 6. Reportes y Análisis

Genera reportes de seguridad y rendimiento bajo demanda o de forma programada (diaria, semanal, mensual).

Los reportes incluyen:

*   Resumen de estadísticas de la red.
*   Análisis de tráfico por dispositivo.
*   Lista de las principales amenazas bloqueadas.
*   Evaluación del cumplimiento de perfiles de seguridad.

Los reportes se pueden descargar en formato PDF para auditorías o análisis offline.

## 7. Configuración del Sistema

En esta sección puedes:

*   Cambiar la contraseña de administrador.
*   Configurar las notificaciones por email y Telegram.
*   Realizar copias de seguridad (`backup`) de la configuración del sistema.
*   Restaurar (`restore`) el sistema desde una copia de seguridad.
*   Reiniciar o apagar el dispositivo SENTINEL de forma segura.
