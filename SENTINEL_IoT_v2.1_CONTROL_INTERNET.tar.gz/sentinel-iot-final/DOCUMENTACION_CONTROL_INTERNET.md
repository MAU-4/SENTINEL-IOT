> **Nota**: Este documento solo describe la nueva funcionalidad de **Control de Internet** y el **script de instalación alternativo**. Para la documentación completa del proyecto, consulte el archivo `README.md` principal.

# Documentación: Nueva Funcionalidad de Control de Internet

**Autor**: Manus AI  
**Fecha**: 2025-11-08  
**Versión**: 2.1

## 1. Introducción

Esta actualización introduce una mejora clave solicitada por el usuario: un **control centralizado para habilitar o deshabilitar el acceso a Internet** para todos los dispositivos conectados a la red Wi-Fi de SENTINEL IoT. Esta funcionalidad se ha implementado sin simplificar ni eliminar ninguna de las características existentes del dashboard, como el monitoreo de dispositivos o la gestión de reglas de firewall individuales.

El objetivo es proporcionar una forma rápida y sencilla de aislar completamente la red IoT de Internet con un solo clic, mejorando la seguridad y el control del administrador de la red.

## 2. Descripción de la Funcionalidad

La nueva funcionalidad se compone de dos partes principales integradas en el dashboard y el backend.

### 2.1. Panel de Control en el Dashboard

Se ha añadido una nueva sección en el dashboard llamada **"🌐 Control de Acceso a Internet"**. Este panel proporciona una interfaz visual e intuitiva para gestionar el estado de la conexión.

| Característica | Descripción |
| :--- | :--- |
| **Indicador de Estado** | Muestra el estado actual del acceso a Internet con un mensaje claro (p. ej., "Acceso a Internet permitido") y un ícono (✅ o 🚫). |
| **Botón Toggle (ON/OFF)** | Un gran botón interactivo que permite cambiar el estado. El color del botón y de la etiqueta cambia para reflejar el estado actual: **verde para ON** y **rojo para OFF**. |
| **Actualización en Tiempo Real** | El estado se verifica y actualiza automáticamente cada 5 segundos, asegurando que el dashboard siempre muestre la información correcta. |

![Captura del Dashboard con el Control de Internet](https://i.imgur.com/example.png)  
*(Nota: Esta es una imagen de ejemplo. La apariencia final puede variar.)*

### 2.2. Visualización de Reglas de `nftables`

Para ofrecer total transparencia y permitir la verificación, se ha añadido otra sección llamada **"🔥 Reglas de nftables (Control de Internet)"**.

- **Cuando Internet está HABILITADO**, esta sección muestra las reglas de `nftables` que permiten el tráfico desde la red IoT (`192.168.50.0/24`) hacia la interfaz de red principal (p. ej., `eth0`).
- **Cuando Internet está BLOQUEADO**, esta sección mostrará que no hay reglas activas, confirmando que el tráfico está siendo bloqueado.

Esto permite a los usuarios avanzados ver exactamente cómo el sistema está gestionando el acceso a la red.

## 3. Implementación Técnica

La lógica de control reside en el backend y utiliza `nftables`, el subsistema de firewall de Linux.

- **Habilitar Internet**: El backend ejecuta un comando `nft` para añadir una regla a la `chain forward` de la tabla `sentinel`. Esta regla acepta y reenvía paquetes cuya dirección de origen pertenece a la red IoT (`ip saddr 192.168.50.0/24`) y cuya interfaz de salida es la que tiene conexión a Internet (`oifname "eth0"`).

- **Deshabilitar Internet**: Para bloquear el acceso, el backend simplemente ejecuta `nft flush chain ip sentinel forward`, eliminando todas las reglas de la cadena de reenvío. Esto corta eficazmente la conexión a Internet para la red IoT, ya que no hay ninguna regla que permita el paso de paquetes.

Todo este proceso es gestionado a través de los nuevos endpoints de la API:

- `GET /api/v1/internet/status`: Verifica el estado actual.
- `POST /api/v1/internet/toggle`: Cambia el estado (habilita o deshabilita).
- `GET /api/v1/internet/rules`: Obtiene las reglas activas para mostrarlas en el dashboard.

## 4. Nuevo Script de Instalación (Sin DHCP)

Adicionalmente, se ha creado un script de instalación alternativo para usuarios que prefieren no utilizar un servidor DHCP y asignar direcciones IP estáticas a sus dispositivos IoT.

- **Nombre del script**: `install_static_ip.sh`
- **Ubicación**: `/scripts/installation/`

Este script realiza la misma instalación completa que el script principal (`install_complete.sh`), pero con una diferencia clave: **no instala ni configura `dnsmasq`**. En su lugar, configura `hostapd` y el sistema de red asumiendo que los dispositivos se conectarán con una configuración de red manual.

> **Importante**: Si utiliza este script, deberá configurar cada dispositivo IoT manualmente con una IP estática dentro del rango `192.168.50.10` - `192.168.50.254`, una máscara de subred `255.255.255.0` y el gateway `192.168.50.1`.
