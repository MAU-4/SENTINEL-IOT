"""
Gestor de reglas de firewall con nftables
"""
import subprocess
import json
import logging
from typing import List, Dict, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class Action(str, Enum):
    """Acciones de firewall"""
    ACCEPT = "accept"
    DROP = "drop"
    REJECT = "reject"
    LOG = "log"


class Protocol(str, Enum):
    """Protocolos de red"""
    TCP = "tcp"
    UDP = "udp"
    ICMP = "icmp"
    ALL = "all"


class Direction(str, Enum):
    """Dirección del tráfico"""
    INPUT = "input"
    OUTPUT = "output"
    FORWARD = "forward"


@dataclass
class FirewallRule:
    """Regla de firewall"""
    id: Optional[int] = None
    name: str = ""
    direction: Direction = Direction.FORWARD
    source_ip: Optional[str] = None
    dest_ip: Optional[str] = None
    source_port: Optional[int] = None
    dest_port: Optional[int] = None
    protocol: Protocol = Protocol.ALL
    action: Action = Action.DROP
    enabled: bool = True
    priority: int = 100
    comment: str = ""
    created_at: Optional[datetime] = None
    
    def to_nftables_rule(self) -> str:
        """Convierte la regla a sintaxis nftables"""
        parts = []
        
        # Protocolo
        if self.protocol != Protocol.ALL:
            parts.append(f"{self.protocol.value}")
        
        # IP origen
        if self.source_ip:
            parts.append(f"ip saddr {self.source_ip}")
        
        # IP destino
        if self.dest_ip:
            parts.append(f"ip daddr {self.dest_ip}")
        
        # Puerto origen
        if self.source_port and self.protocol in [Protocol.TCP, Protocol.UDP]:
            parts.append(f"{self.protocol.value} sport {self.source_port}")
        
        # Puerto destino
        if self.dest_port and self.protocol in [Protocol.TCP, Protocol.UDP]:
            parts.append(f"{self.protocol.value} dport {self.dest_port}")
        
        # Acción
        parts.append(self.action.value)
        
        # Comentario
        if self.comment:
            parts.append(f'comment "{self.comment}"')
        
        return " ".join(parts)


class FirewallManager:
    """Gestor de firewall con nftables"""
    
    def __init__(self, table_name: str = "sentinel"):
        self.table_name = table_name
        self.rules_cache: Dict[str, List[FirewallRule]] = {}
        self.initialized = False
    
    def initialize(self) -> bool:
        """Inicializa el firewall"""
        try:
            # Verificar si nftables está disponible
            result = subprocess.run(
                ["nft", "--version"],
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode != 0:
                logger.error("nftables no está instalado")
                return False
            
            # Crear tabla si no existe
            self._create_table()
            
            # Crear chains básicas
            self._create_chains()
            
            # Aplicar reglas por defecto
            self._apply_default_rules()
            
            self.initialized = True
            logger.info("Firewall inicializado correctamente")
            return True
            
        except Exception as e:
            logger.error(f"Error al inicializar firewall: {e}")
            return False
    
    def _create_table(self):
        """Crea la tabla de nftables"""
        cmd = f"nft add table inet {self.table_name}"
        self._run_command(cmd, check_error=False)
    
    def _create_chains(self):
        """Crea las chains básicas"""
        chains = [
            (Direction.INPUT, "input"),
            (Direction.FORWARD, "forward"),
            (Direction.OUTPUT, "output")
        ]
        
        for direction, chain_name in chains:
            # Crear chain
            cmd = f"nft add chain inet {self.table_name} {chain_name} {{ type filter hook {chain_name} priority 0\\; }}"
            self._run_command(cmd, check_error=False)
    
    def _apply_default_rules(self):
        """Aplica reglas por defecto"""
        default_rules = [
            # Permitir loopback
            FirewallRule(
                name="allow_loopback",
                direction=Direction.INPUT,
                source_ip="127.0.0.1",
                action=Action.ACCEPT,
                priority=10,
                comment="Allow loopback traffic"
            ),
            
            # Permitir conexiones establecidas
            FirewallRule(
                name="allow_established",
                direction=Direction.INPUT,
                action=Action.ACCEPT,
                priority=20,
                comment="Allow established connections"
            ),
            
            # Permitir SSH (puerto 22)
            FirewallRule(
                name="allow_ssh",
                direction=Direction.INPUT,
                protocol=Protocol.TCP,
                dest_port=22,
                action=Action.ACCEPT,
                priority=30,
                comment="Allow SSH access"
            ),
            
            # Permitir HTTPS (puerto 443)
            FirewallRule(
                name="allow_https",
                direction=Direction.INPUT,
                protocol=Protocol.TCP,
                dest_port=443,
                action=Action.ACCEPT,
                priority=40,
                comment="Allow HTTPS access"
            ),
            
            # Permitir DNS desde red IoT
            FirewallRule(
                name="allow_dns_iot",
                direction=Direction.INPUT,
                source_ip="192.168.100.0/24",
                protocol=Protocol.UDP,
                dest_port=53,
                action=Action.ACCEPT,
                priority=50,
                comment="Allow DNS from IoT network"
            ),
            
            # Permitir DHCP desde red IoT
            FirewallRule(
                name="allow_dhcp_iot",
                direction=Direction.INPUT,
                source_ip="192.168.100.0/24",
                protocol=Protocol.UDP,
                dest_port=67,
                action=Action.ACCEPT,
                priority=60,
                comment="Allow DHCP from IoT network"
            ),
        ]
        
        for rule in default_rules:
            self.add_rule(rule)
    
    def add_rule(self, rule: FirewallRule) -> bool:
        """Añade una regla al firewall"""
        try:
            if not self.initialized:
                self.initialize()
            
            # Validar regla
            if not self._validate_rule(rule):
                logger.error(f"Regla inválida: {rule}")
                return False
            
            # Construir comando nftables
            nft_rule = rule.to_nftables_rule()
            chain = rule.direction.value
            
            cmd = f"nft add rule inet {self.table_name} {chain} {nft_rule}"
            
            # Ejecutar comando
            result = self._run_command(cmd)
            
            if result:
                # Actualizar caché
                if chain not in self.rules_cache:
                    self.rules_cache[chain] = []
                self.rules_cache[chain].append(rule)
                
                logger.info(f"Regla añadida: {rule.name}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error al añadir regla: {e}")
            return False
    
    def delete_rule(self, rule_id: int) -> bool:
        """Elimina una regla del firewall"""
        try:
            # Buscar regla en caché
            for chain, rules in self.rules_cache.items():
                for i, rule in enumerate(rules):
                    if rule.id == rule_id:
                        # Eliminar de nftables
                        cmd = f"nft delete rule inet {self.table_name} {chain} handle {rule_id}"
                        result = self._run_command(cmd)
                        
                        if result:
                            # Eliminar de caché
                            rules.pop(i)
                            logger.info(f"Regla eliminada: {rule.name}")
                            return True
            
            logger.warning(f"Regla no encontrada: {rule_id}")
            return False
            
        except Exception as e:
            logger.error(f"Error al eliminar regla: {e}")
            return False
    
    def list_rules(self, chain: Optional[str] = None) -> List[FirewallRule]:
        """Lista las reglas del firewall"""
        try:
            if chain:
                return self.rules_cache.get(chain, [])
            
            # Retornar todas las reglas
            all_rules = []
            for rules in self.rules_cache.values():
                all_rules.extend(rules)
            return all_rules
            
        except Exception as e:
            logger.error(f"Error al listar reglas: {e}")
            return []
    
    def flush_rules(self, chain: Optional[str] = None) -> bool:
        """Elimina todas las reglas"""
        try:
            if chain:
                cmd = f"nft flush chain inet {self.table_name} {chain}"
            else:
                cmd = f"nft flush table inet {self.table_name}"
            
            result = self._run_command(cmd)
            
            if result:
                # Limpiar caché
                if chain:
                    self.rules_cache[chain] = []
                else:
                    self.rules_cache = {}
                
                logger.info("Reglas eliminadas")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error al eliminar reglas: {e}")
            return False
    
    def get_statistics(self) -> Dict:
        """Obtiene estadísticas del firewall"""
        try:
            cmd = f"nft list table inet {self.table_name}"
            result = subprocess.run(
                cmd.split(),
                capture_output=True,
                text=True,
                check=True
            )
            
            # Parsear salida (simplificado)
            stats = {
                "total_rules": sum(len(rules) for rules in self.rules_cache.values()),
                "chains": list(self.rules_cache.keys()),
                "table": self.table_name,
                "raw_output": result.stdout
            }
            
            return stats
            
        except Exception as e:
            logger.error(f"Error al obtener estadísticas: {e}")
            return {}
    
    def backup_rules(self, filepath: str) -> bool:
        """Guarda las reglas en un archivo"""
        try:
            cmd = f"nft list table inet {self.table_name}"
            result = subprocess.run(
                cmd.split(),
                capture_output=True,
                text=True,
                check=True
            )
            
            with open(filepath, 'w') as f:
                f.write(result.stdout)
            
            logger.info(f"Backup guardado en: {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Error al guardar backup: {e}")
            return False
    
    def restore_rules(self, filepath: str) -> bool:
        """Restaura las reglas desde un archivo"""
        try:
            with open(filepath, 'r') as f:
                rules_content = f.read()
            
            # Limpiar reglas actuales
            self.flush_rules()
            
            # Aplicar reglas desde archivo
            cmd = f"nft -f {filepath}"
            result = self._run_command(cmd)
            
            if result:
                logger.info(f"Reglas restauradas desde: {filepath}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error al restaurar reglas: {e}")
            return False
    
    def _validate_rule(self, rule: FirewallRule) -> bool:
        """Valida una regla antes de aplicarla"""
        # Validar IPs
        if rule.source_ip and not self._is_valid_ip(rule.source_ip):
            return False
        
        if rule.dest_ip and not self._is_valid_ip(rule.dest_ip):
            return False
        
        # Validar puertos
        if rule.source_port and not (0 <= rule.source_port <= 65535):
            return False
        
        if rule.dest_port and not (0 <= rule.dest_port <= 65535):
            return False
        
        return True
    
    def _is_valid_ip(self, ip: str) -> bool:
        """Valida una dirección IP o CIDR"""
        import ipaddress
        try:
            ipaddress.ip_network(ip, strict=False)
            return True
        except ValueError:
            return False
    
    def _run_command(self, cmd: str, check_error: bool = True) -> bool:
        """Ejecuta un comando de sistema"""
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                check=check_error
            )
            
            if result.returncode != 0 and check_error:
                logger.error(f"Error al ejecutar comando: {result.stderr}")
                return False
            
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Error al ejecutar comando: {e}")
            return False
        except Exception as e:
            logger.error(f"Error inesperado: {e}")
            return False


# Instancia global
firewall_manager = FirewallManager()
