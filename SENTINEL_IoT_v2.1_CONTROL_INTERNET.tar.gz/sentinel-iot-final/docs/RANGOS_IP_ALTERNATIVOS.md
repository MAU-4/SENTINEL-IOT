# Rangos de IP Alternativos para SENTINEL IoT

## 🔴 Problema

El rango `192.168.100.x` ya está en uso en tu red.

## ✅ Soluciones - Rangos Alternativos

### Opción 1: 192.168.50.x (Recomendada)

```
Gateway: 192.168.50.1
Rango DHCP: 192.168.50.10 - 192.168.50.250
Máscara: 255.255.255.0
```

**Configuración dnsmasq:**
```conf
interface=wlan1
dhcp-range=192.168.50.10,192.168.50.250,255.255.255.0,24h
dhcp-option=3,192.168.50.1
dhcp-option=6,192.168.50.1
```

**Configurar wlan1:**
```bash
sudo ip addr add 192.168.50.1/24 dev wlan1
```

---

### Opción 2: 192.168.200.x

```
Gateway: 192.168.200.1
Rango DHCP: 192.168.200.10 - 192.168.200.250
Máscara: 255.255.255.0
```

**Configuración dnsmasq:**
```conf
interface=wlan1
dhcp-range=192.168.200.10,192.168.200.250,255.255.255.0,24h
dhcp-option=3,192.168.200.1
dhcp-option=6,192.168.200.1
```

**Configurar wlan1:**
```bash
sudo ip addr add 192.168.200.1/24 dev wlan1
```

---

### Opción 3: 10.10.10.x (Alternativa Clase A)

```
Gateway: 10.10.10.1
Rango DHCP: 10.10.10.10 - 10.10.10.250
Máscara: 255.255.255.0
```

**Configuración dnsmasq:**
```conf
interface=wlan1
dhcp-range=10.10.10.10,10.10.10.250,255.255.255.0,24h
dhcp-option=3,10.10.10.1
dhcp-option=6,10.10.10.1
```

**Configurar wlan1:**
```bash
sudo ip addr add 10.10.10.1/24 dev wlan1
```

---

### Opción 4: 172.16.0.x (Clase B Privada)

```
Gateway: 172.16.0.1
Rango DHCP: 172.16.0.10 - 172.16.0.250
Máscara: 255.255.255.0
```

**Configuración dnsmasq:**
```conf
interface=wlan1
dhcp-range=172.16.0.10,172.16.0.250,255.255.255.0,24h
dhcp-option=3,172.16.0.1
dhcp-option=6,172.16.0.1
```

**Configurar wlan1:**
```bash
sudo ip addr add 172.16.0.1/24 dev wlan1
```

---

## 🎯 Recomendación

**Usa 192.168.50.x** porque:
- ✅ Está en el rango privado estándar
- ✅ Fácil de recordar
- ✅ Poco común (menos probabilidad de conflicto)
- ✅ Compatible con todos los dispositivos

---

## 📋 Script de Configuración Completo

### Script con Rango 192.168.50.x

```bash
#!/bin/bash
# Configuración de SENTINEL IoT con rango 192.168.50.x

# Variables
IOT_INTERFACE="wlan1"
IOT_GATEWAY="192.168.50.1"
DHCP_START="192.168.50.10"
DHCP_END="192.168.50.250"

# Detener servicios
sudo systemctl stop hostapd dnsmasq

# Limpiar interfaz
sudo ip link set $IOT_INTERFACE down
sudo ip addr flush dev $IOT_INTERFACE
sudo ip link set $IOT_INTERFACE up

# Asignar IP
sudo ip addr add $IOT_GATEWAY/24 dev $IOT_INTERFACE

# Crear configuración de dnsmasq
sudo tee /etc/dnsmasq.conf > /dev/null << EOF
interface=$IOT_INTERFACE
dhcp-range=$DHCP_START,$DHCP_END,255.255.255.0,24h
dhcp-option=3,$IOT_GATEWAY
dhcp-option=6,$IOT_GATEWAY
EOF

# Crear archivo de leases
sudo mkdir -p /var/lib/misc
sudo touch /var/lib/misc/dnsmasq.leases
sudo chmod 644 /var/lib/misc/dnsmasq.leases

# Iniciar servicios
sudo systemctl start hostapd
sleep 3
sudo systemctl start dnsmasq

# Verificar
echo "Configuración completada:"
echo "Gateway: $IOT_GATEWAY"
echo "Rango DHCP: $DHCP_START - $DHCP_END"
echo ""
echo "Estado de servicios:"
sudo systemctl status hostapd --no-pager | grep Active
sudo systemctl status dnsmasq --no-pager | grep Active
```

---

## 🔧 Cambiar Rango en Configuración Existente

Si ya tienes SENTINEL IoT instalado:

### Paso 1: Detener servicios

```bash
sudo systemctl stop hostapd dnsmasq
```

### Paso 2: Cambiar IP de wlan1

```bash
# Limpiar IP anterior
sudo ip addr flush dev wlan1

# Asignar nueva IP
sudo ip addr add 192.168.50.1/24 dev wlan1

# Verificar
ip addr show wlan1
```

### Paso 3: Actualizar dnsmasq.conf

```bash
sudo nano /etc/dnsmasq.conf
```

Cambiar a:
```conf
interface=wlan1
dhcp-range=192.168.50.10,192.168.50.250,255.255.255.0,24h
dhcp-option=3,192.168.50.1
dhcp-option=6,192.168.50.1
```

### Paso 4: Actualizar backend de SENTINEL

Si tu backend tiene la IP hardcodeada:

```bash
sudo nano /opt/sentinel-iot/app/core/config.py
```

Cambiar:
```python
IOT_GATEWAY = "192.168.50.1"
IOT_NETWORK = "192.168.50.0/24"
```

### Paso 5: Reiniciar servicios

```bash
sudo systemctl start hostapd
sleep 3
sudo systemctl start dnsmasq
sudo systemctl restart sentinel-iot

# Verificar
sudo systemctl status hostapd
sudo systemctl status dnsmasq
```

---

## 🧪 Verificar Configuración

### Verificar IP de wlan1

```bash
ip addr show wlan1 | grep "inet "
# Debe mostrar: inet 192.168.50.1/24
```

### Verificar dnsmasq

```bash
# Ver configuración
cat /etc/dnsmasq.conf

# Ver logs
sudo journalctl -u dnsmasq -n 20
```

### Probar DHCP

```bash
# Conectar un dispositivo y ver logs en tiempo real
sudo journalctl -u dnsmasq -f
```

Deberías ver:
```
DHCPDISCOVER(wlan1) aa:bb:cc:dd:ee:ff
DHCPOFFER(wlan1) 192.168.50.10 aa:bb:cc:dd:ee:ff
DHCPREQUEST(wlan1) 192.168.50.10 aa:bb:cc:dd:ee:ff
DHCPACK(wlan1) 192.168.50.10 aa:bb:cc:dd:ee:ff
```

### Verificar dispositivos conectados

```bash
cat /var/lib/misc/dnsmasq.leases
```

---

## 🔍 Detectar Rangos en Uso

Para evitar conflictos, verifica qué rangos están en uso:

```bash
# Ver todas las interfaces de red
ip addr show

# Ver tabla de rutas
ip route

# Escanear red local
nmap -sn 192.168.1.0/24  # Tu red principal
```

---

## 📊 Tabla de Comparación de Rangos

| Rango | Gateway | DHCP Start | DHCP End | Ventajas | Desventajas |
|-------|---------|------------|----------|----------|-------------|
| **192.168.50.x** | 192.168.50.1 | 192.168.50.10 | 192.168.50.250 | Poco común, fácil de recordar | Ninguna |
| 192.168.200.x | 192.168.200.1 | 192.168.200.10 | 192.168.200.250 | Muy poco común | Ninguna |
| 10.10.10.x | 10.10.10.1 | 10.10.10.10 | 10.10.10.250 | Fácil de recordar | Puede confundirse con VPNs |
| 172.16.0.x | 172.16.0.1 | 172.16.0.10 | 172.16.0.250 | Rango grande disponible | Menos común en redes domésticas |

---

## 🎯 Mi Recomendación

**Usa 192.168.50.x** con esta configuración:

```bash
Gateway: 192.168.50.1
Rango DHCP: 192.168.50.10 - 192.168.50.250
Máscara: 255.255.255.0 (/24)
```

**Razones:**
- ✅ Fácil de recordar
- ✅ Poco probable que esté en uso
- ✅ Estándar de redes privadas
- ✅ Compatible con todo

---

## 🚀 Comando Rápido

Para cambiar rápidamente al rango 192.168.50.x:

```bash
# Detener servicios
sudo systemctl stop hostapd dnsmasq

# Configurar wlan1
sudo ip addr flush dev wlan1
sudo ip addr add 192.168.50.1/24 dev wlan1

# Actualizar dnsmasq
echo "interface=wlan1
dhcp-range=192.168.50.10,192.168.50.250,255.255.255.0,24h
dhcp-option=3,192.168.50.1
dhcp-option=6,192.168.50.1" | sudo tee /etc/dnsmasq.conf

# Iniciar servicios
sudo systemctl start hostapd
sleep 3
sudo systemctl start dnsmasq

# Verificar
ip addr show wlan1 | grep "inet "
sudo systemctl status dnsmasq
```

---

¿Quieres que use el rango **192.168.50.x** y actualice todos los scripts con esta configuración?
