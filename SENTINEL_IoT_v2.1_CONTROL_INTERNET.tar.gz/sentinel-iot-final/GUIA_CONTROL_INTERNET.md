# Guía Rápida: Control de Internet en SENTINEL IoT

**Versión**: 2.1  
**Fecha**: 2025-11-08

## ¿Qué es el Control de Internet?

Esta nueva funcionalidad te permite **habilitar o deshabilitar el acceso a Internet** para todos los dispositivos conectados a tu red Wi-Fi SENTINEL IoT con un simple clic. Es ideal para situaciones donde necesitas aislar completamente tu red IoT de Internet por seguridad o para realizar pruebas.

## Ubicación en el Dashboard

Después de acceder al dashboard en `http://192.168.50.1:8000`, verás una nueva sección llamada:

**🌐 Control de Acceso a Internet**

Esta sección se encuentra entre las estadísticas principales y la lista de dispositivos.

## Cómo Usar el Control

### 1. Ver el Estado Actual

El panel muestra claramente si Internet está:
- **✅ Habilitado**: Mensaje en verde "Acceso a Internet permitido"
- **🚫 Bloqueado**: Mensaje en rojo "Acceso a Internet bloqueado"

### 2. Cambiar el Estado

Simplemente haz clic en el **botón toggle** (el botón grande con forma de interruptor).

- Si Internet está **ON**, el botón será **verde** y mostrará "INTERNET ON"
- Si Internet está **OFF**, el botón será **rojo** y mostrará "INTERNET OFF"

Al hacer clic, el estado cambiará inmediatamente y verás un mensaje de confirmación.

### 3. Verificar los Cambios

Debajo del panel de control, encontrarás la sección:

**🔥 Reglas de nftables (Control de Internet)**

Esta sección muestra las reglas de firewall activas. Cuando Internet está habilitado, verás reglas que permiten el tráfico. Cuando está bloqueado, la lista estará vacía o mostrará un mensaje indicando que no hay reglas activas.

## Actualización Automática

El dashboard se actualiza automáticamente cada **5 segundos**, por lo que siempre verás el estado actual del sistema sin necesidad de recargar la página.

## Casos de Uso

### Escenario 1: Aislamiento Total
Tienes dispositivos IoT que no necesitan acceso a Internet (como cámaras locales o sensores). Simplemente desactiva Internet para evitar cualquier comunicación externa.

### Escenario 2: Mantenimiento Seguro
Necesitas configurar o actualizar dispositivos sin que se conecten a Internet. Bloquea el acceso temporalmente mientras trabajas.

### Escenario 3: Control Parental/Horarios
Quieres que los dispositivos IoT solo tengan acceso a Internet en ciertos momentos. Puedes activar/desactivar manualmente según tus necesidades.

### Escenario 4: Respuesta a Incidentes
Detectas actividad sospechosa en un dispositivo. Bloquea inmediatamente todo el acceso a Internet mientras investigas.

## Preguntas Frecuentes

**P: ¿Esto afecta la comunicación local entre dispositivos?**  
R: No. Los dispositivos en la red SENTINEL IoT (`192.168.50.0/24`) pueden seguir comunicándose entre sí. Solo se bloquea el acceso hacia Internet.

**P: ¿Puedo seguir accediendo al dashboard cuando Internet está bloqueado?**  
R: Sí. El dashboard es local y siempre estará accesible en `http://192.168.50.1:8000` mientras estés conectado a la red Wi-Fi de SENTINEL.

**P: ¿Los cambios son permanentes?**  
R: Sí. El estado se mantiene incluso después de reiniciar el sistema. Si apagas Internet, permanecerá apagado hasta que lo vuelvas a encender manualmente.

**P: ¿Puedo automatizar esto con la API?**  
R: Sí. Puedes usar los endpoints REST:
- `GET /api/v1/internet/status` - Ver estado
- `POST /api/v1/internet/toggle` - Cambiar estado
- `POST /api/v1/internet/enable` - Habilitar
- `POST /api/v1/internet/disable` - Deshabilitar

**P: ¿Esto reemplaza las reglas de firewall individuales?**  
R: No. El control de Internet es una funcionalidad adicional. Todas las demás características del firewall (reglas por dispositivo, puertos, etc.) siguen funcionando normalmente.

## Soporte Técnico

Para más información sobre SENTINEL IoT, consulta:
- `README.md` - Documentación completa del proyecto
- `DOCUMENTACION_CONTROL_INTERNET.md` - Detalles técnicos de esta funcionalidad
- `INICIO_RAPIDO.md` - Guía de instalación y configuración inicial

---

**Desarrollado por**: Manus AI  
**Proyecto**: SENTINEL IoT v2.1
