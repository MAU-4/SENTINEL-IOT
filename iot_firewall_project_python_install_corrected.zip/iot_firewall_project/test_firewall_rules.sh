#!/bin/bash

# Script para probar las reglas del firewall (nftables)

log_info() {
    echo "[INFO] $1"
}

log_error() {
    echo "[ERROR] $1" >&2
}

log_success() {
    echo "[SUCCESS] $1"
}

# --- 1. Verificar estado del servicio nftables ---
log_info "Verificando estado del servicio nftables..."
systemctl is-active --quiet nftables
if [ $? -eq 0 ]; then
    log_success "nftables está corriendo."
else
    log_error "nftables NO está corriendo. Por favor, revise la configuración y el servicio."
    exit 1
fi

# --- 2. Verificar si las reglas están cargadas ---
log_info "Verificando si las reglas de nftables están cargadas..."
nft list ruleset > /dev/null 2>&1
if [ $? -eq 0 ]; then
    log_success "Las reglas de nftables están cargadas."
else
    log_error "Las reglas de nftables NO están cargadas. Ejecute 'sudo python3 /opt/iot_firewall/main.py apply_rules'."
    exit 1
fi

# --- 3. Verificar política por defecto (drop) ---
log_info "Verificando política por defecto de las cadenas filter..."
# Comprobar si las políticas de input, forward y output son 'drop' en la tabla 'iot_firewall'
NFT_POLICY_INPUT=$(nft list chain ip iot_firewall input | grep 'policy' | awk '{print $NF}' | sed 's/;//')
NFT_POLICY_FORWARD=$(nft list chain ip iot_firewall forward | grep 'policy' | awk '{print $NF}' | sed 's/;//')
NFT_POLICY_OUTPUT=$(nft list chain ip iot_firewall output | grep 'policy' | awk '{print $NF}' | sed 's/;//')

if [ "$NFT_POLICY_INPUT" == "drop" ] && [ "$NFT_POLICY_FORWARD" == "drop" ] && [ "$NFT_POLICY_OUTPUT" == "drop" ]; then
    log_success "Las políticas por defecto de input, forward y output son 'drop'."
else
    log_error "Las políticas por defecto NO son 'drop'. Revise las reglas de nftables."
    log_error "Input policy: $NFT_POLICY_INPUT, Forward policy: $NFT_POLICY_FORWARD, Output policy: $NFT_POLICY_OUTPUT"
    exit 1
fi

# --- 4. Verificar regla NAT (masquerade) ---
log_info "Verificando regla NAT (masquerade) en la cadena postrouting..."
nft list chain ip nat postrouting | grep 'oifname "wlan0" masquerade' > /dev/null 2>&1
if [ $? -eq 0 ]; then
    log_success "La regla NAT (masquerade) para wlan0 está presente."
else
    log_error "La regla NAT (masquerade) NO está presente. Revise las reglas de nftables."
    exit 1
fi

# --- 5. Verificar reenvío de IP ---
log_info "Verificando que el reenvío de IP esté habilitado..."
IP_FORWARD_STATUS=$(sysctl net.ipv4.ip_forward | awk '{print $NF}')
if [ "$IP_FORWARD_STATUS" -eq 1 ]; then
    log_success "El reenvío de IP está habilitado."
else
    log_error "El reenvío de IP NO está habilitado. Revise /etc/sysctl.d/99-ip-forward.conf."
    exit 1
fi

log_success "Pruebas de funcionalidad del firewall completadas. nftables está activo y las reglas básicas están en su lugar."
log_info "Para pruebas más detalladas, configure dispositivos IoT en config.json y verifique el acceso a servicios específicos."


