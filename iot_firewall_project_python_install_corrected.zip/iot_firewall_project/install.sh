
#!/bin/bash

# Script de instalación para el Firewall IoT en Raspberry Pi

# --- Variables de Configuración --- #
PROJECT_DIR="/opt/iot_firewall"
PYTHON_VENV_DIR="${PROJECT_DIR}/venv"
SERVICE_FILE="/etc/systemd/system/iot-firewall.service"
NFTABLES_CONFIG_FILE="/etc/nftables.conf"

# --- Funciones de Ayuda --- #
log_info() {
    echo "[INFO] $1"
}

log_error() {
    echo "[ERROR] $1" >&2
}

# --- Comprobaciones Iniciales --- #
if [ "$(id -u)" -ne 0 ]; then
    log_error "Este script debe ejecutarse con privilegios de root (sudo)."
    exit 1
fi

# --- Instalación de Dependencias --- #
log_info "Actualizando la lista de paquetes e instalando dependencias..."
apt update && apt install -y hostapd dnsmasq nftables python3-venv
if [ $? -ne 0 ]; then
    log_error "Fallo al instalar dependencias. Abortando."
    exit 1
fi

# --- Configuración del Proyecto --- #
log_info "Creando directorio del proyecto en ${PROJECT_DIR}..."
mkdir -p "${PROJECT_DIR}"
cp -r src/* "${PROJECT_DIR}/"

log_info "Creando entorno virtual de Python..."
python3 -m venv "${PYTHON_VENV_DIR}"
if [ $? -ne 0 ]; then
    log_error "Fallo al crear el entorno virtual de Python. Abortando."
    exit 1
fi

log_info "Activando entorno virtual e instalando dependencias de Python..."
source "${PYTHON_VENV_DIR}/bin/activate"
pip install --no-cache-dir -r ${PROJECT_DIR}/requirements.txt
if [ $? -ne 0 ]; then
    log_error "Fallo al instalar dependencias de Python. Abortando."
    exit 1
fi
deactivate

# --- Configuración de nftables --- #
log_info "Configurando nftables para cargar las reglas al inicio..."
# Crear un archivo de configuración de nftables que cargue las reglas del script Python
cat <<EOF > "${NFTABLES_CONFIG_FILE}"
#!/usr/sbin/nft -f

# Este archivo es generado por el script de instalación del Firewall IoT.
# Las reglas son gestionadas por el script Python en ${PROJECT_DIR}/main.py

# Se recomienda no modificar este archivo directamente.
# Para aplicar las reglas, ejecute:
# sudo python3 ${PROJECT_DIR}/main.py apply_rules

# Cargar las reglas iniciales (o las últimas guardadas) al inicio del sistema
include "${PROJECT_DIR}/current_nftables_rules.nft"
EOF

# Asegurarse de que nftables se inicie al arrancar
systemctl enable nftables

# --- Creación del Servicio Systemd --- #
log_info "Creando servicio Systemd para el Firewall IoT..."
cat <<EOF > "${SERVICE_FILE}"
[Unit]
Description=IoT Firewall Service
After=network.target nftables.service

[Service]
Type=oneshot
ExecStart=/bin/bash -c "source ${PYTHON_VENV_DIR}/bin/activate && python3 ${PROJECT_DIR}/main.py apply_rules"
RemainAfterExit=yes
StandardOutput=journal
StandardError=journal
WorkingDirectory=${PROJECT_DIR}

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable iot-firewall.service
systemctl start iot-firewall.service

# --- Aplicar Reglas Iniciales --- #
log_info "Aplicando reglas iniciales del firewall..."
# Generar y guardar las reglas iniciales en un archivo que nftables pueda incluir
python3 "${PROJECT_DIR}/main.py" apply_rules

# --- Habilitar reenvío de IP (IP Forwarding) --- #
log_info "Habilitando el reenvío de IP..."
echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-ip-forward.conf
sysctl -p /etc/sysctl.d/99-ip-forward.conf

log_info "Instalación completada. El firewall IoT se iniciará automáticamente al arrancar."
log_info "Para gestionar el firewall, use: sudo python3 ${PROJECT_DIR}/main.py <comando>"
log_info "Por favor, reinicie el sistema para que todos los cambios surtan efecto: sudo reboot"





log_info "Copiando archivos de configuración de hostapd y dnsmasq..."
cp "${PROJECT_DIR}/hostapd.conf" "/etc/hostapd/hostapd.conf"
cp "${PROJECT_DIR}/dnsmasq.conf" "/etc/dnsmasq.conf"

log_info "Habilitando y iniciando hostapd y dnsmasq..."
systemctl unmask hostapd
systemctl enable hostapd
systemctl start hostapd
systemctl enable dnsmasq
systemctl start dnsmasq





log_info "Configurando interfaces de red..."
# Configurar wlan0 para conectividad a Internet (DHCP)
cat <<EOF > /etc/network/interfaces.d/wlan0
auto wlan0
iface wlan0 inet dhcp
EOF

# Configurar wlan1 como interfaz para el AP IoT (estática)
cat <<EOF > /etc/network/interfaces.d/wlan1
auto wlan1
iface wlan1 inet static
    address 10.0.0.1
    netmask 255.255.255.0
EOF

# Reiniciar servicio de red para aplicar cambios
systemctl restart networking


