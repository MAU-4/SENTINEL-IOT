#!/bin/bash

# Script para probar las herramientas de gestión Python (firewall_manager.py y main.py)

log_info() {
    echo "[INFO] $1"
}

log_error() {
    echo "[ERROR] $1" >&2
}

log_success() {
    echo "[SUCCESS] $1"
}

PROJECT_DIR="/opt/iot_firewall"
PYTHON_VENV_DIR="${PROJECT_DIR}/venv"
MAIN_SCRIPT="${PROJECT_DIR}/main.py"
CONFIG_FILE="${PROJECT_DIR}/config.json"

# --- 1. Verificar existencia de los scripts Python ---
log_info "Verificando existencia de los scripts Python..."
if [ -f "${MAIN_SCRIPT}" ]; then
    log_success "main.py encontrado."
else
    log_error "main.py NO encontrado en ${MAIN_SCRIPT}."
    exit 1
fi

# --- 2. Verificar que el entorno virtual Python funcione ---
log_info "Verificando el entorno virtual Python..."
if [ -d "${PYTHON_VENV_DIR}" ]; then
    log_success "Entorno virtual Python encontrado."
else
    log_error "Entorno virtual Python NO encontrado en ${PYTHON_VENV_DIR}."
    exit 1
fi

# --- 3. Probar el comando apply_rules ---
log_info "Probando el comando 'apply_rules'...
(Esto generará y aplicará las reglas de nftables basadas en config.json)"
sudo /bin/bash -c "source ${PYTHON_VENV_DIR}/bin/activate && python3 ${MAIN_SCRIPT} apply_rules"
if [ $? -eq 0 ]; then
    log_success "'apply_rules' ejecutado exitosamente."
else
    log_error "Fallo al ejecutar 'apply_rules'."
    exit 1
fi

# --- 4. Probar el comando list_rules ---
log_info "Probando el comando 'list_rules'...
(Esto mostrará las reglas de nftables activas)"
sudo /bin/bash -c "source ${PYTHON_VENV_DIR}/bin/activate && python3 ${MAIN_SCRIPT} list_rules"
if [ $? -eq 0 ]; then
    log_success "'list_rules' ejecutado exitosamente."
else
    log_error "Fallo al ejecutar 'list_rules'."
    exit 1
fi

# --- 5. Simular la adición de un dispositivo (requiere modificar config.json) ---
log_info "La prueba de adición/eliminación de dispositivos requeriría comandos específicos en main.py."
log_info "Verifique manualmente la funcionalidad de adición/eliminación de dispositivos si main.py los soporta."

log_success "Pruebas de herramientas Python completadas. Los comandos apply_rules y list_rules funcionan."


