#!/bin/bash

################################################################################
# SENTINEL IoT SIMPLE - Instalador Completo
# Configura red Wi-Fi + Backend + Control de Internet
################################################################################

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}SENTINEL IoT - Instalador Completo${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

# Verificar root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}[ERROR]${NC} Este script debe ejecutarse como root (sudo)"
   exit 1
fi

# Configuración
INSTALL_DIR="/opt/sentinel-simple"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WAN_INTERFACE="wlan0"
IOT_INTERFACE="wlan1"
IOT_IP="192.168.50.1"
WIFI_SSID="SENTINEL_IoT"
WIFI_PASSWORD="Raspberry"

# Paso 1: Instalar dependencias
echo -e "${YELLOW}[1/9]${NC} Instalando dependencias..."
apt-get update -qq
apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    hostapd \
    nftables \
    net-tools \
    iproute2 \
    wireless-tools \
    rfkill \
    > /dev/null 2>&1
echo -e "${GREEN}✓${NC} Dependencias instaladas"
echo ""

# Paso 2: Desbloquear Wi-Fi
echo -e "${YELLOW}[2/9]${NC} Configurando Wi-Fi..."
rfkill unblock wifi > /dev/null 2>&1 || true
rfkill unblock all > /dev/null 2>&1 || true
echo -e "${GREEN}✓${NC} Wi-Fi desbloqueado"
echo ""

# Paso 3: Detener servicios conflictivos
echo -e "${YELLOW}[3/9]${NC} Deteniendo servicios conflictivos..."
systemctl stop wpa_supplicant > /dev/null 2>&1 || true
systemctl disable wpa_supplicant > /dev/null 2>&1 || true
systemctl stop NetworkManager > /dev/null 2>&1 || true
systemctl disable NetworkManager > /dev/null 2>&1 || true
systemctl stop dhcpcd > /dev/null 2>&1 || true
systemctl disable dhcpcd > /dev/null 2>&1 || true
echo -e "${GREEN}✓${NC} Servicios detenidos"
echo ""

# Paso 4: Configurar interfaces de red
echo -e "${YELLOW}[4/9]${NC} Configurando interfaces de red..."
cat > /etc/network/interfaces << EOF
# Loopback
auto lo
iface lo inet loopback

# Interfaz WAN (Internet) - DHCP
allow-hotplug $WAN_INTERFACE
iface $WAN_INTERFACE inet dhcp
    wpa-conf /etc/wpa_supplicant/wpa_supplicant.conf

# Interfaz IoT - IP Estática
allow-hotplug $IOT_INTERFACE
iface $IOT_INTERFACE inet static
    address $IOT_IP
    netmask 255.255.255.0
EOF
echo -e "${GREEN}✓${NC} Interfaces configuradas"
echo ""

# Paso 5: Configurar hostapd
echo -e "${YELLOW}[5/9]${NC} Configurando punto de acceso..."
cat > /etc/hostapd/hostapd.conf << EOF
interface=$IOT_INTERFACE
driver=nl80211
ssid=$WIFI_SSID
hw_mode=g
channel=7
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=$WIFI_PASSWORD
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
EOF

echo 'DAEMON_CONF="/etc/hostapd/hostapd.conf"' > /etc/default/hostapd
systemctl unmask hostapd > /dev/null 2>&1 || true
systemctl enable hostapd > /dev/null 2>&1
echo -e "${GREEN}✓${NC} hostapd configurado"
echo ""

# Paso 6: Configurar nftables
echo -e "${YELLOW}[6/9]${NC} Configurando firewall..."
cat > /etc/nftables.conf << 'NFTEOF'
#!/usr/sbin/nft -f

flush ruleset

# Tabla para filtrado
table inet filter {
    chain input {
        type filter hook input priority 0; policy accept;
        ct state invalid drop
        ct state {established, related} accept
        iif lo accept
        ip protocol icmp accept
        tcp dport 22 accept
        tcp dport 8000 accept
    }

    chain forward {
        type filter hook forward priority 0; policy accept;
        ct state invalid drop
        ct state {established, related} accept
        iifname "wlan1" oifname "wlan0" accept
        iifname "wlan0" oifname "wlan1" ct state {established, related} accept
    }

    chain output {
        type filter hook output priority 0; policy accept;
    }
}

# Tabla para NAT
table ip nat {
    chain prerouting {
        type nat hook prerouting priority -100;
    }

    chain postrouting {
        type nat hook postrouting priority 100;
        oifname "wlan0" masquerade
    }
}
NFTEOF

# Habilitar IP forwarding
echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-sentinel.conf
sysctl -p /etc/sysctl.d/99-sentinel.conf > /dev/null 2>&1

systemctl enable nftables > /dev/null 2>&1
systemctl restart nftables > /dev/null 2>&1
echo -e "${GREEN}✓${NC} Firewall configurado"
echo ""

# Paso 7: Instalar backend
echo -e "${YELLOW}[7/9]${NC} Instalando backend..."
mkdir -p "$INSTALL_DIR/frontend"

# Copiar backend
if [ -f "$SCRIPT_DIR/sentinel_backend_fixed.py" ]; then
    cp "$SCRIPT_DIR/sentinel_backend_fixed.py" "$INSTALL_DIR/app.py"
elif [ -f "$SCRIPT_DIR/simple_backend.py" ]; then
    cp "$SCRIPT_DIR/simple_backend.py" "$INSTALL_DIR/app.py"
else
    echo -e "${RED}✗${NC} No se encontró el archivo del backend"
    exit 1
fi

# Copiar frontend
if [ -f "$SCRIPT_DIR/simple_index.html" ]; then
    cp "$SCRIPT_DIR/simple_index.html" "$INSTALL_DIR/frontend/index.html"
else
    echo -e "${RED}✗${NC} No se encontró el archivo del frontend"
    exit 1
fi

chmod -R 755 "$INSTALL_DIR"

# Crear entorno virtual
python3 -m venv "$INSTALL_DIR/venv" > /dev/null 2>&1
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip > /dev/null 2>&1
"$INSTALL_DIR/venv/bin/pip" install fastapi uvicorn > /dev/null 2>&1
echo -e "${GREEN}✓${NC} Backend instalado"
echo ""

# Paso 8: Crear servicio systemd
echo -e "${YELLOW}[8/9]${NC} Creando servicio..."
cat > /etc/systemd/system/sentinel-simple.service << EOF
[Unit]
Description=SENTINEL IoT Simple - Control de Internet
After=network.target nftables.service hostapd.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$INSTALL_DIR/venv/bin"
ExecStart=$INSTALL_DIR/venv/bin/python3 $INSTALL_DIR/app.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable sentinel-simple > /dev/null 2>&1
echo -e "${GREEN}✓${NC} Servicio creado"
echo ""

# Paso 9: Iniciar servicios
echo -e "${YELLOW}[9/9]${NC} Iniciando servicios..."
ip link set $IOT_INTERFACE up > /dev/null 2>&1 || true
ip addr add $IOT_IP/24 dev $IOT_INTERFACE > /dev/null 2>&1 || true
systemctl restart hostapd > /dev/null 2>&1
sleep 2
systemctl restart sentinel-simple > /dev/null 2>&1
sleep 3
echo -e "${GREEN}✓${NC} Servicios iniciados"
echo ""

# Verificación
echo -e "${CYAN}========================================${NC}"
echo -e "${CYAN}Verificación${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""

if systemctl is-active --quiet hostapd; then
    echo -e "${GREEN}✓${NC} hostapd activo"
else
    echo -e "${RED}✗${NC} hostapd no activo"
fi

if systemctl is-active --quiet sentinel-simple; then
    echo -e "${GREEN}✓${NC} Backend activo"
else
    echo -e "${RED}✗${NC} Backend no activo"
fi

if systemctl is-active --quiet nftables; then
    echo -e "${GREEN}✓${NC} nftables activo"
else
    echo -e "${RED}✗${NC} nftables no activo"
fi

echo ""
echo -e "${CYAN}========================================${NC}"
echo -e "${GREEN}¡Instalación Completada!${NC}"
echo -e "${CYAN}========================================${NC}"
echo ""
echo -e "${YELLOW}Red Wi-Fi creada:${NC}"
echo -e "  SSID: $WIFI_SSID"
echo -e "  Contraseña: $WIFI_PASSWORD"
echo -e "  IP Gateway: $IOT_IP"
echo ""
echo -e "${YELLOW}Accede al dashboard:${NC}"
echo -e "  http://$IOT_IP:8000"
echo ""
echo -e "${YELLOW}Comandos útiles:${NC}"
echo -e "  Ver logs: sudo journalctl -u sentinel-simple -f"
echo -e "  Estado:   sudo systemctl status sentinel-simple"
echo ""
echo -e "${YELLOW}IMPORTANTE:${NC}"
echo -e "  Reinicia la Raspberry Pi para aplicar todos los cambios:"
echo -e "  ${CYAN}sudo reboot${NC}"
echo ""
