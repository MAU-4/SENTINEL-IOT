#!/usr/bin/env python3
"""
SENTINEL IoT - Backend Simplificado CORREGIDO
Control de Internet ON/OFF que realmente funciona
"""

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
import subprocess
import os
import re

app = FastAPI(title="SENTINEL IoT Simple", version="2.1")

# Ruta del frontend
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "frontend")

# Interfaz de la red IoT
IOT_INTERFACE = "wlan1"

def run_command(command):
    """Ejecuta un comando del sistema y devuelve la salida"""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=10
        )
        return {
            "success": result.returncode == 0,
            "output": result.stdout,
            "error": result.stderr,
            "returncode": result.returncode
        }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "error": str(e),
            "returncode": -1
        }

def get_internet_status():
    """Verifica si Internet está habilitado o bloqueado"""
    # Listar reglas de la cadena forward con handles
    result = run_command("nft -a list chain inet filter forward")
    
    if not result["success"]:
        return {"enabled": True, "error": "No se pudo verificar el estado", "details": result["error"]}
    
    # Buscar reglas drop que bloqueen el tráfico desde wlan1
    lines = result["output"].split("\n")
    for line in lines:
        # Buscar líneas que contengan "drop" y que sean para wlan1
        if "drop" in line.lower() and IOT_INTERFACE in line.lower():
            return {"enabled": False, "error": None, "details": "Regla de bloqueo encontrada"}
        # También buscar drops generales en forward
        if "drop" in line.lower() and "iifname" not in line and "oifname" not in line:
            # Drop general, probablemente bloquea todo
            return {"enabled": False, "error": None, "details": "Bloqueo general encontrado"}
    
    return {"enabled": True, "error": None, "details": "Sin reglas de bloqueo"}

def enable_internet():
    """Habilita el acceso a Internet eliminando TODAS las reglas de bloqueo"""
    # Listar reglas con handles
    result = run_command("nft -a list chain inet filter forward")
    
    if not result["success"]:
        return {"success": False, "message": f"Error al listar reglas: {result['error']}"}
    
    # Buscar y eliminar TODAS las reglas drop
    lines = result["output"].split("\n")
    handles_to_delete = []
    
    for line in lines:
        if "drop" in line.lower() and "handle" in line:
            # Extraer el número de handle
            match = re.search(r'handle\s+(\d+)', line)
            if match:
                handles_to_delete.append(match.group(1))
    
    if not handles_to_delete:
        return {"success": True, "message": "Internet ya estaba habilitado (sin reglas de bloqueo)"}
    
    # Eliminar todas las reglas drop encontradas
    deleted = 0
    for handle in handles_to_delete:
        delete_result = run_command(f"nft delete rule inet filter forward handle {handle}")
        if delete_result["success"]:
            deleted += 1
    
    if deleted > 0:
        return {"success": True, "message": f"Internet habilitado ({deleted} reglas eliminadas)"}
    else:
        return {"success": False, "message": "No se pudieron eliminar las reglas de bloqueo"}

def disable_internet():
    """Deshabilita el acceso a Internet bloqueando tráfico desde wlan1"""
    # Verificar si ya existe una regla de bloqueo
    status = get_internet_status()
    if not status["enabled"]:
        return {"success": True, "message": "Internet ya estaba bloqueado"}
    
    # Agregar regla para bloquear tráfico desde wlan1 hacia Internet
    # Insertamos al INICIO de la cadena forward para que tenga prioridad
    command = f"nft insert rule inet filter forward iifname \"{IOT_INTERFACE}\" drop"
    result = run_command(command)
    
    if result["success"]:
        return {"success": True, "message": "Internet bloqueado para red IoT"}
    else:
        # Si falla, intentar con una regla más simple
        command_simple = "nft insert rule inet filter forward drop"
        result_simple = run_command(command_simple)
        
        if result_simple["success"]:
            return {"success": True, "message": "Internet bloqueado (regla general)"}
        else:
            return {"success": False, "message": f"Error al bloquear: {result['error']}"}

def get_nftables_rules():
    """Obtiene todas las reglas de nftables"""
    result = run_command("nft list ruleset")
    
    if result["success"]:
        return {"success": True, "rules": result["output"]}
    else:
        return {"success": False, "rules": f"Error: {result['error']}"}

# ============================================================================
# RUTAS DE LA API
# ============================================================================

@app.get("/")
async def root():
    """Sirve el frontend"""
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    
    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            content = f.read()
        return HTMLResponse(content=content)
    else:
        return JSONResponse({
            "name": "SENTINEL IoT Simple",
            "version": "2.1",
            "status": "running",
            "message": "Frontend no encontrado. API funcionando correctamente."
        })

@app.get("/api/status")
async def api_status():
    """Estado general del sistema"""
    internet_status = get_internet_status()
    
    return {
        "system": "SENTINEL IoT Simple",
        "version": "2.1",
        "internet_enabled": internet_status["enabled"],
        "status": "running",
        "details": internet_status.get("details", "")
    }

@app.get("/api/internet/status")
async def internet_status():
    """Estado del acceso a Internet"""
    status = get_internet_status()
    return {
        "enabled": status["enabled"],
        "message": "Internet habilitado" if status["enabled"] else "Internet bloqueado",
        "details": status.get("details", "")
    }

@app.post("/api/internet/enable")
async def api_enable_internet():
    """Habilita el acceso a Internet"""
    result = enable_internet()
    status = get_internet_status()
    
    return {
        "success": result["success"],
        "message": result["message"],
        "enabled": status["enabled"]
    }

@app.post("/api/internet/disable")
async def api_disable_internet():
    """Deshabilita el acceso a Internet"""
    result = disable_internet()
    status = get_internet_status()
    
    return {
        "success": result["success"],
        "message": result["message"],
        "enabled": status["enabled"]
    }

@app.post("/api/internet/toggle")
async def api_toggle_internet():
    """Cambia el estado de Internet (ON/OFF)"""
    current_status = get_internet_status()
    
    if current_status["enabled"]:
        result = disable_internet()
    else:
        result = enable_internet()
    
    new_status = get_internet_status()
    
    return {
        "success": result["success"],
        "message": result["message"],
        "enabled": new_status["enabled"]
    }

@app.get("/api/rules")
async def api_get_rules():
    """Obtiene las reglas de nftables"""
    result = get_nftables_rules()
    return result

# ============================================================================
# INICIO DE LA APLICACIÓN
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    print("Iniciando SENTINEL IoT Simple...")
    print("Accede a: http://0.0.0.0:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)
