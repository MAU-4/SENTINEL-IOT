# Cómo SENTINEL IoT Detecta y Gestiona Dispositivos IoT

## 🎯 Pregunta Clave

**¿Cómo detecta SENTINEL IoT los dispositivos conectados y cómo trabaja con ellos?**

---

## 📡 Mecanismos de Detección

SENTINEL IoT utiliza **múltiples métodos** para detectar dispositivos conectados:

### 1. **Detección por DHCP (Primaria)**

Cuando un dispositivo se conecta a la red Wi-Fi SENTINEL_IoT:

```
Dispositivo IoT
    ↓
1. Conecta a Wi-Fi "SENTINEL_IoT"
    ↓
2. Solicita IP (DHCP DISCOVER)
    ↓
3. dnsmasq asigna IP (DHCP OFFER)
    ↓
4. Dispositivo acepta IP (DHCP ACK)
    ↓
5. dnsmasq registra en /var/lib/misc/dnsmasq.leases
    ↓
6. SENTINEL lee el archivo de leases
    ↓
7. Nuevo dispositivo detectado
```

**Archivo de leases:**
```
1699564800 aa:bb:cc:dd:ee:ff 192.168.100.10 SmartBulb *
1699564801 11:22:33:44:55:66 192.168.100.11 ESP32-Sensor *
```

**Código en SENTINEL (device_manager.py):**
```python
def scan_network_devices(self):
    """Escanea dispositivos desde DHCP leases"""
    devices = []
    
    # Leer archivo de leases de dnsmasq
    with open('/var/lib/misc/dnsmasq.leases', 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 4:
                device = {
                    'mac': parts[1],
                    'ip': parts[2],
                    'hostname': parts[3],
                    'lease_time': parts[0],
                    'status': 'online'
                }
                devices.append(device)
    
    return devices
```

### 2. **Escaneo ARP (Secundaria)**

SENTINEL también escanea la tabla ARP para detectar dispositivos activos:

```python
def scan_arp_table(self):
    """Escanea tabla ARP para dispositivos activos"""
    result = subprocess.run(['arp', '-n'], capture_output=True, text=True)
    devices = []
    
    for line in result.stdout.split('\n')[1:]:  # Skip header
        if line.strip():
            parts = line.split()
            if len(parts) >= 3:
                ip = parts[0]
                mac = parts[2]
                
                # Solo dispositivos en red IoT (192.168.100.x)
                if ip.startswith('192.168.100.'):
                    devices.append({
                        'ip': ip,
                        'mac': mac,
                        'status': 'online'
                    })
    
    return devices
```

### 3. **Escaneo de Red Activo (nmap)**

Para descubrimiento más profundo:

```python
def active_network_scan(self):
    """Escaneo activo con nmap"""
    result = subprocess.run(
        ['nmap', '-sn', '192.168.100.0/24'],
        capture_output=True,
        text=True
    )
    
    # Parsear resultados de nmap
    devices = self._parse_nmap_output(result.stdout)
    return devices
```

### 4. **Monitoreo de Tráfico (Pasivo)**

SENTINEL puede capturar paquetes para detectar dispositivos:

```python
def monitor_network_traffic(self):
    """Monitorea tráfico de red para detectar dispositivos"""
    # Usar scapy o tcpdump
    from scapy.all import sniff
    
    def packet_handler(packet):
        if packet.haslayer('IP'):
            src_ip = packet['IP'].src
            src_mac = packet['Ether'].src
            
            # Registrar dispositivo
            self.register_device(src_ip, src_mac)
    
    # Capturar en interfaz wlan1
    sniff(iface='wlan1', prn=packet_handler, store=False)
```

---

## 🔍 Identificación de Dispositivos

Una vez detectado, SENTINEL identifica **qué tipo de dispositivo es**:

### Método 1: Análisis de MAC Address (OUI)

```python
def identify_device_by_mac(self, mac_address):
    """Identifica fabricante por MAC address"""
    # Primeros 6 caracteres = OUI (Organizationally Unique Identifier)
    oui = mac_address.upper().replace(':', '')[:6]
    
    # Base de datos de OUIs
    oui_database = {
        '30AEA4': 'Espressif (ESP32/ESP8266)',
        'B827EB': 'Raspberry Pi Foundation',
        'DC4F22': 'Espressif (ESP32)',
        '2CF432': 'Espressif (ESP8266)',
        '5CCF7F': 'Xiaomi (Smart Home)',
        '34EA34': 'TP-Link (Smart Plugs)',
        # ... más fabricantes
    }
    
    manufacturer = oui_database.get(oui, 'Unknown')
    
    return {
        'manufacturer': manufacturer,
        'device_type': self._guess_device_type(manufacturer)
    }
```

### Método 2: Análisis de Hostname

```python
def identify_by_hostname(self, hostname):
    """Identifica dispositivo por nombre"""
    hostname_lower = hostname.lower()
    
    patterns = {
        'esp32': 'ESP32 Microcontroller',
        'esp8266': 'ESP8266 Microcontroller',
        'arduino': 'Arduino Board',
        'tasmota': 'Tasmota Smart Device',
        'shelly': 'Shelly Smart Switch',
        'sonoff': 'Sonoff Smart Device',
        'bulb': 'Smart Light Bulb',
        'sensor': 'IoT Sensor',
        'camera': 'IP Camera',
        'thermostat': 'Smart Thermostat'
    }
    
    for pattern, device_type in patterns.items():
        if pattern in hostname_lower:
            return device_type
    
    return 'Unknown IoT Device'
```

### Método 3: Escaneo de Puertos

```python
def identify_by_ports(self, ip_address):
    """Identifica dispositivo por puertos abiertos"""
    import nmap
    
    nm = nmap.PortScanner()
    nm.scan(ip_address, '1-1000')
    
    open_ports = []
    for proto in nm[ip_address].all_protocols():
        ports = nm[ip_address][proto].keys()
        open_ports.extend(ports)
    
    # Identificar por puertos comunes
    device_signatures = {
        (80, 443): 'Web-enabled IoT Device',
        (1883,): 'MQTT Device',
        (8080,): 'Camera or Web Server',
        (502,): 'Modbus Device',
        (5683,): 'CoAP Device',
        (8883,): 'MQTT over TLS'
    }
    
    for ports, device_type in device_signatures.items():
        if all(p in open_ports for p in ports):
            return device_type
    
    return 'Unknown'
```

### Método 4: Análisis de Tráfico (Machine Learning)

```python
def identify_by_traffic_pattern(self, device_ip):
    """Identifica dispositivo por patrón de tráfico usando ML"""
    # Capturar tráfico del dispositivo
    traffic_data = self.capture_device_traffic(device_ip, duration=60)
    
    # Extraer características
    features = self.extract_traffic_features(traffic_data)
    # - Tamaño promedio de paquetes
    # - Frecuencia de transmisión
    # - Protocolos usados
    # - Puertos de destino
    # - Patrones temporales
    
    # Clasificar con modelo ML
    device_type = self.ml_classifier.predict(features)
    
    return device_type
```

---

## 🗄️ Almacenamiento de Dispositivos

Los dispositivos detectados se almacenan en una base de datos:

### Estructura de la Base de Datos

```python
# models/device.py

class Device(Base):
    __tablename__ = "devices"
    
    id = Column(Integer, primary_key=True)
    mac_address = Column(String, unique=True, index=True)
    ip_address = Column(String)
    hostname = Column(String)
    manufacturer = Column(String)
    device_type = Column(String)
    device_category = Column(String)  # sensor, actuator, camera, etc.
    
    # Estado
    status = Column(String)  # online, offline, new
    first_seen = Column(DateTime)
    last_seen = Column(DateTime)
    
    # Clasificación
    is_classified = Column(Boolean, default=False)
    classification_confidence = Column(Float)
    
    # Seguridad
    security_profile = Column(String)  # strict, moderate, permissive
    is_blocked = Column(Boolean, default=False)
    
    # Metadatos
    custom_name = Column(String)
    notes = Column(Text)
    tags = Column(JSON)
```

### Operaciones CRUD

```python
# Crear/Actualizar dispositivo
def register_device(self, device_info):
    """Registra o actualiza dispositivo en BD"""
    device = db.query(Device).filter_by(
        mac_address=device_info['mac']
    ).first()
    
    if device:
        # Actualizar existente
        device.ip_address = device_info['ip']
        device.last_seen = datetime.now()
        device.status = 'online'
    else:
        # Crear nuevo
        device = Device(
            mac_address=device_info['mac'],
            ip_address=device_info['ip'],
            hostname=device_info.get('hostname', 'Unknown'),
            status='new',
            first_seen=datetime.now(),
            last_seen=datetime.now()
        )
        db.add(device)
    
    db.commit()
    return device

# Leer dispositivos
def get_all_devices(self):
    """Obtiene todos los dispositivos"""
    return db.query(Device).all()

def get_device_by_mac(self, mac_address):
    """Obtiene dispositivo por MAC"""
    return db.query(Device).filter_by(
        mac_address=mac_address
    ).first()

# Actualizar dispositivo
def update_device(self, mac_address, updates):
    """Actualiza información de dispositivo"""
    device = self.get_device_by_mac(mac_address)
    for key, value in updates.items():
        setattr(device, key, value)
    db.commit()

# Eliminar dispositivo
def delete_device(self, mac_address):
    """Elimina dispositivo"""
    device = self.get_device_by_mac(mac_address)
    db.delete(device)
    db.commit()
```

---

## 🔄 Flujo Completo de Detección

### Diagrama de Flujo

```
1. DISPOSITIVO SE CONECTA
   ↓
2. DHCP asigna IP → Registro en leases
   ↓
3. SENTINEL lee leases (cada 10s)
   ↓
4. ¿Dispositivo nuevo?
   ├─ SÍ → Crear en BD (status: "new")
   └─ NO → Actualizar last_seen
   ↓
5. IDENTIFICACIÓN AUTOMÁTICA
   ├─ Análisis de MAC (OUI)
   ├─ Análisis de hostname
   ├─ Escaneo de puertos
   └─ Análisis de tráfico (ML)
   ↓
6. CLASIFICACIÓN
   ├─ Tipo: sensor, actuator, camera, etc.
   ├─ Fabricante: Espressif, Xiaomi, etc.
   └─ Confianza: 0-100%
   ↓
7. APLICAR PERFIL DE SEGURIDAD
   ├─ Nuevo → Cuarentena (sin acceso)
   ├─ Conocido → Perfil asignado
   └─ Bloqueado → Denegar todo
   ↓
8. ACTUALIZAR DASHBOARD
   └─ Mostrar en interfaz web
```

### Código del Flujo Principal

```python
class DeviceManager:
    def __init__(self):
        self.db = Database()
        self.scanner = NetworkScanner()
        self.classifier = DeviceClassifier()
        self.firewall = FirewallManager()
    
    def monitor_loop(self):
        """Loop principal de monitoreo"""
        while True:
            # 1. Escanear red
            detected_devices = self.scanner.scan_network()
            
            # 2. Procesar cada dispositivo
            for device_info in detected_devices:
                self.process_device(device_info)
            
            # 3. Marcar dispositivos offline
            self.mark_offline_devices()
            
            # 4. Esperar 10 segundos
            time.sleep(10)
    
    def process_device(self, device_info):
        """Procesa un dispositivo detectado"""
        mac = device_info['mac']
        
        # Buscar en BD
        device = self.db.get_device_by_mac(mac)
        
        if device is None:
            # Dispositivo nuevo
            print(f"[NEW] Dispositivo detectado: {mac}")
            
            # Crear en BD
            device = self.db.register_device(device_info)
            
            # Identificar automáticamente
            identification = self.classifier.identify(device_info)
            
            # Actualizar información
            self.db.update_device(mac, {
                'manufacturer': identification['manufacturer'],
                'device_type': identification['type'],
                'classification_confidence': identification['confidence']
            })
            
            # Aplicar cuarentena por defecto
            self.firewall.apply_quarantine(device_info['ip'])
            
            # Notificar al usuario
            self.notify_new_device(device)
        
        else:
            # Dispositivo conocido
            # Actualizar last_seen
            self.db.update_device(mac, {
                'ip_address': device_info['ip'],
                'last_seen': datetime.now(),
                'status': 'online'
            })
            
            # Aplicar reglas de firewall
            if not device.is_blocked:
                self.firewall.apply_profile(
                    device_info['ip'],
                    device.security_profile
                )
    
    def mark_offline_devices(self):
        """Marca dispositivos como offline si no se ven hace 5 min"""
        threshold = datetime.now() - timedelta(minutes=5)
        
        offline_devices = self.db.query(Device).filter(
            Device.last_seen < threshold,
            Device.status == 'online'
        ).all()
        
        for device in offline_devices:
            device.status = 'offline'
            self.db.commit()
            
            # Remover reglas de firewall
            self.firewall.remove_device_rules(device.ip_address)
```

---

## 🎨 Visualización en el Dashboard

### API Endpoints

```python
@app.get("/api/v1/devices")
async def get_devices():
    """Obtiene lista de dispositivos"""
    devices = device_manager.get_all_devices()
    return {
        "total": len(devices),
        "online": len([d for d in devices if d.status == 'online']),
        "new": len([d for d in devices if d.status == 'new']),
        "devices": [device.to_dict() for device in devices]
    }

@app.get("/api/v1/devices/{mac_address}")
async def get_device_details(mac_address: str):
    """Obtiene detalles de un dispositivo"""
    device = device_manager.get_device_by_mac(mac_address)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    # Información adicional
    traffic_stats = device_manager.get_traffic_stats(mac_address)
    firewall_rules = firewall_manager.get_device_rules(device.ip_address)
    
    return {
        "device": device.to_dict(),
        "traffic": traffic_stats,
        "firewall": firewall_rules
    }

@app.post("/api/v1/devices/{mac_address}/classify")
async def classify_device(mac_address: str, classification: dict):
    """Clasifica manualmente un dispositivo"""
    device_manager.update_device(mac_address, {
        'device_type': classification['type'],
        'device_category': classification['category'],
        'custom_name': classification.get('name'),
        'is_classified': True,
        'security_profile': classification['security_profile']
    })
    
    # Aplicar nuevo perfil de seguridad
    device = device_manager.get_device_by_mac(mac_address)
    firewall_manager.apply_profile(
        device.ip_address,
        classification['security_profile']
    )
    
    return {"status": "success"}
```

### Frontend (Dashboard)

```javascript
// Actualización automática cada 10 segundos
setInterval(async () => {
    const response = await fetch('/api/v1/devices');
    const data = await response.json();
    
    // Actualizar lista de dispositivos
    updateDeviceList(data.devices);
    
    // Actualizar estadísticas
    document.getElementById('total-devices').textContent = data.total;
    document.getElementById('online-devices').textContent = data.online;
    document.getElementById('new-devices').textContent = data.new;
}, 10000);

function updateDeviceList(devices) {
    const container = document.getElementById('device-list');
    container.innerHTML = '';
    
    devices.forEach(device => {
        const card = createDeviceCard(device);
        container.appendChild(card);
    });
}

function createDeviceCard(device) {
    const card = document.createElement('div');
    card.className = `device-card status-${device.status}`;
    card.innerHTML = `
        <div class="device-header">
            <span class="device-icon">${getDeviceIcon(device.device_type)}</span>
            <span class="device-name">${device.custom_name || device.hostname}</span>
            <span class="device-status ${device.status}">${device.status}</span>
        </div>
        <div class="device-info">
            <p><strong>IP:</strong> ${device.ip_address}</p>
            <p><strong>MAC:</strong> ${device.mac_address}</p>
            <p><strong>Tipo:</strong> ${device.device_type}</p>
            <p><strong>Fabricante:</strong> ${device.manufacturer}</p>
        </div>
        <div class="device-actions">
            <button onclick="viewDetails('${device.mac_address}')">Detalles</button>
            <button onclick="classifyDevice('${device.mac_address}')">Clasificar</button>
            <button onclick="blockDevice('${device.mac_address}')">Bloquear</button>
        </div>
    `;
    return card;
}
```

---

## 🔐 Gestión de Seguridad

### Perfiles de Seguridad

```python
SECURITY_PROFILES = {
    'strict': {
        'description': 'Solo comunicación local, sin Internet',
        'rules': [
            # Permitir DNS local
            {'protocol': 'udp', 'dport': 53, 'action': 'accept'},
            # Permitir NTP local
            {'protocol': 'udp', 'dport': 123, 'action': 'accept'},
            # Denegar todo lo demás
            {'action': 'drop'}
        ]
    },
    'moderate': {
        'description': 'Internet limitado, puertos específicos',
        'rules': [
            # Permitir HTTP/HTTPS
            {'protocol': 'tcp', 'dport': [80, 443], 'action': 'accept'},
            # Permitir MQTT
            {'protocol': 'tcp', 'dport': 1883, 'action': 'accept'},
            # Denegar resto
            {'action': 'drop'}
        ]
    },
    'permissive': {
        'description': 'Acceso completo a Internet',
        'rules': [
            {'action': 'accept'}
        ]
    },
    'quarantine': {
        'description': 'Sin acceso (dispositivos nuevos)',
        'rules': [
            {'action': 'drop'}
        ]
    }
}
```

### Aplicar Perfil

```python
def apply_security_profile(self, device_ip, profile_name):
    """Aplica perfil de seguridad a dispositivo"""
    profile = SECURITY_PROFILES.get(profile_name, 'quarantine')
    
    # Limpiar reglas anteriores
    self.remove_device_rules(device_ip)
    
    # Aplicar nuevas reglas
    for rule in profile['rules']:
        self.add_firewall_rule(
            source_ip=device_ip,
            **rule
        )
```

---

## 📊 Ejemplo Práctico Completo

### Escenario: Conectar una Bombilla Inteligente

**1. Usuario conecta bombilla a SENTINEL_IoT**

```
Bombilla → Wi-Fi "SENTINEL_IoT" (password: Sentinel2024)
```

**2. DHCP asigna IP**

```
dnsmasq: DHCPDISCOVER(wlan1) 5c:cf:7f:12:34:56
dnsmasq: DHCPOFFER(wlan1) 192.168.100.15 5c:cf:7f:12:34:56
dnsmasq: DHCPACK(wlan1) 192.168.100.15 5c:cf:7f:12:34:56 SmartBulb-Living
```

**3. SENTINEL detecta dispositivo nuevo**

```python
[INFO] Nuevo dispositivo detectado
  MAC: 5c:cf:7f:12:34:56
  IP: 192.168.100.15
  Hostname: SmartBulb-Living
```

**4. Identificación automática**

```python
# Análisis de MAC
OUI: 5CCF7F → Xiaomi Corporation

# Análisis de hostname
"SmartBulb" → Tipo: Smart Light Bulb

# Escaneo de puertos
Puerto 80 abierto → Web interface

# Resultado
{
    'manufacturer': 'Xiaomi',
    'device_type': 'Smart Light Bulb',
    'category': 'actuator',
    'confidence': 0.95
}
```

**5. Aplicar cuarentena**

```python
# Dispositivo nuevo → Cuarentena
firewall.apply_quarantine('192.168.100.15')

# Regla nftables
nft add rule inet sentinel forward ip saddr 192.168.100.15 drop
```

**6. Notificación en dashboard**

```
[NUEVO DISPOSITIVO]
Nombre: SmartBulb-Living
Tipo: Bombilla Inteligente (Xiaomi)
IP: 192.168.100.15
Estado: En cuarentena

[ACCIONES]
[Clasificar] [Permitir] [Bloquear]
```

**7. Usuario clasifica dispositivo**

```javascript
// Usuario hace clic en "Clasificar"
classifyDevice({
    mac: '5c:cf:7f:12:34:56',
    type: 'Smart Bulb',
    category: 'actuator',
    custom_name: 'Bombilla Sala',
    security_profile: 'moderate'
});
```

**8. SENTINEL aplica perfil**

```python
# Actualizar BD
device.custom_name = 'Bombilla Sala'
device.security_profile = 'moderate'
device.is_classified = True
device.status = 'online'

# Aplicar reglas de firewall
firewall.apply_profile('192.168.100.15', 'moderate')

# Reglas nftables
nft add rule inet sentinel forward ip saddr 192.168.100.15 tcp dport {80,443,1883} accept
nft add rule inet sentinel forward ip saddr 192.168.100.15 drop
```

**9. Bombilla funcional**

```
✅ Bombilla puede:
  - Comunicarse con app móvil (puerto 80/443)
  - Conectar a servidor MQTT (puerto 1883)
  - Acceder a DNS local

❌ Bombilla NO puede:
  - Acceder a puertos no autorizados
  - Comunicarse con otros dispositivos sin permiso
```

---

## 🎯 Resumen

### SENTINEL IoT detecta dispositivos mediante:

1. **DHCP leases** (primario)
2. **Tabla ARP** (secundario)
3. **Escaneo nmap** (activo)
4. **Captura de tráfico** (pasivo)

### Identifica dispositivos usando:

1. **MAC address** (OUI database)
2. **Hostname** (patrones)
3. **Puertos abiertos** (fingerprinting)
4. **Tráfico de red** (Machine Learning)

### Gestiona dispositivos con:

1. **Base de datos** (SQLite/PostgreSQL)
2. **API REST** (FastAPI)
3. **Dashboard web** (HTML/JS)
4. **Firewall dinámico** (nftables)

### Flujo completo:

```
Conexión → Detección → Identificación → Clasificación → Seguridad → Dashboard
```

---

¿Queda claro cómo funciona? ¿Quieres que profundice en algún aspecto específico?
