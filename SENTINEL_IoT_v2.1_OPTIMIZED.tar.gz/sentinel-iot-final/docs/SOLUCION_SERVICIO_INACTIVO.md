# Solución: Servicio sentinel-iot Inactivo

Si después de ejecutar el script de instalación el servicio `sentinel-iot` aparece como **inactivo**, sigue esta guía de solución rápida.

## Solución Rápida (Recomendada)

### Opción 1: Usar el script de instalación corregido

```bash
cd /ruta/donde/descargaste/sentinel-iot-v2/scripts
sudo bash install_fixed.sh
```

Este script incluye todas las correcciones necesarias y diagnostica automáticamente problemas.

### Opción 2: Usar el script de diagnóstico

```bash
cd /ruta/donde/descargaste/sentinel-iot-v2/scripts
sudo bash diagnose.sh
```

Este script te mostrará exactamente qué está fallando y cómo solucionarlo.

## Solución Manual

Si prefieres corregir manualmente, sigue estos pasos:

### Paso 1: Copiar archivos del proyecto

```bash
# Ir al directorio donde descargaste el proyecto
cd /ruta/donde/descargaste/sentinel-iot-v2

# Copiar todos los archivos al directorio de instalación
sudo cp -r backend/* /opt/sentinel-iot/

# Crear archivos __init__.py necesarios
sudo touch /opt/sentinel-iot/app/__init__.py
sudo touch /opt/sentinel-iot/app/core/__init__.py
sudo touch /opt/sentinel-iot/app/models/__init__.py
sudo touch /opt/sentinel-iot/app/services/__init__.py
sudo touch /opt/sentinel-iot/app/ml/__init__.py
sudo touch /opt/sentinel-iot/app/api/__init__.py
```

### Paso 2: Instalar dependencias Python

```bash
cd /opt/sentinel-iot
source venv/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn[standard] sqlalchemy pydantic pydantic-settings
deactivate
```

### Paso 3: Verificar configuración del servicio

```bash
# Editar el servicio si es necesario
sudo nano /etc/systemd/system/sentinel-iot.service
```

Asegúrate de que contenga:

```ini
[Unit]
Description=SENTINEL IoT v2.0 API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/sentinel-iot
Environment="PATH=/opt/sentinel-iot/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
ExecStart=/opt/sentinel-iot/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### Paso 4: Recargar y reiniciar

```bash
sudo systemctl daemon-reload
sudo systemctl restart sentinel-iot
```

### Paso 5: Verificar estado

```bash
sudo systemctl status sentinel-iot
```

Si aún está inactivo, ver los logs:

```bash
sudo journalctl -u sentinel-iot -n 50
```

## Causas Comunes y Soluciones

### 1. Falta el archivo main.py

**Error en logs:** `ModuleNotFoundError: No module named 'app.main'`

**Solución:** Ejecutar Paso 1 arriba (copiar archivos).

### 2. Faltan dependencias Python

**Error en logs:** `ModuleNotFoundError: No module named 'fastapi'`

**Solución:** Ejecutar Paso 2 arriba (instalar dependencias).

### 3. Puerto 8000 en uso

**Error en logs:** `Address already in use`

**Solución:**

```bash
# Ver qué está usando el puerto
sudo lsof -i :8000

# Matar el proceso o cambiar el puerto en el servicio
sudo systemctl edit sentinel-iot
```

### 4. Permisos incorrectos

**Error en logs:** `PermissionError`

**Solución:**

```bash
sudo chown -R root:root /opt/sentinel-iot
sudo chmod -R 755 /opt/sentinel-iot
sudo chmod -R 755 /var/lib/sentinel-iot
```

## Verificación Final

Una vez que el servicio esté activo, prueba la API:

```bash
# Localmente
curl http://localhost:8000/api/v1/health

# Debería responder:
# {"status":"healthy","firewall":true,"timestamp":"..."}
```

Accede desde tu navegador:

```
http://<IP_DE_TU_RASPBERRY>:8000/api/docs
```

## Archivos Importantes

| Archivo | Propósito |
|---------|-----------|
| `/opt/sentinel-iot/app/main.py` | Aplicación principal |
| `/etc/systemd/system/sentinel-iot.service` | Configuración del servicio |
| `/opt/sentinel-iot/venv/` | Entorno virtual de Python |
| `/var/lib/sentinel-iot/` | Datos y base de datos |
| `/var/log/sentinel-iot/` | Logs de la aplicación |

## Comandos Útiles

```bash
# Ver estado
sudo systemctl status sentinel-iot

# Ver logs en tiempo real
sudo journalctl -u sentinel-iot -f

# Reiniciar servicio
sudo systemctl restart sentinel-iot

# Detener servicio
sudo systemctl stop sentinel-iot

# Iniciar servicio
sudo systemctl start sentinel-iot

# Deshabilitar inicio automático
sudo systemctl disable sentinel-iot

# Habilitar inicio automático
sudo systemctl enable sentinel-iot
```

## Obtener Más Ayuda

Si después de seguir esta guía el problema persiste:

1. **Ejecuta el script de diagnóstico:**
   ```bash
   sudo bash /ruta/sentinel-iot-v2/scripts/diagnose.sh
   ```

2. **Consulta la guía completa de troubleshooting:**
   - `docs/TROUBLESHOOTING.md`

3. **Recopila información para reportar:**
   ```bash
   sudo journalctl -u sentinel-iot -n 100 > sentinel-logs.txt
   sudo systemctl status sentinel-iot > sentinel-status.txt
   ```

4. **Reinstalación limpia:**
   ```bash
   # Eliminar instalación anterior
   sudo systemctl stop sentinel-iot
   sudo rm -rf /opt/sentinel-iot
   sudo rm /etc/systemd/system/sentinel-iot.service
   sudo systemctl daemon-reload
   
   # Ejecutar script corregido
   cd /ruta/sentinel-iot-v2/scripts
   sudo bash install_fixed.sh
   ```

---

**Nota:** El script `install_fixed.sh` incluye todas estas correcciones automáticamente y es la forma más rápida de resolver el problema.
