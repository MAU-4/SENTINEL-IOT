# Guía Rápida: Solución de Wi-Fi SENTINEL IoT

## 🚀 Solución en 1 Comando

Si tu red Wi-Fi SENTINEL_IoT no asigna IPs, ejecuta:

```bash
cd /ruta/donde/descargaste/sentinel-iot-v2/scripts
sudo bash fix_wifi_complete.sh
```

**Este script hace TODO automáticamente:**
- ✅ Limpia configuraciones incorrectas
- ✅ Detiene servicios conflictivos
- ✅ Crea archivos de configuración limpios
- ✅ Configura wlan1 correctamente
- ✅ Inicia servicios en el orden correcto
- ✅ Verifica que todo funcione

**Tiempo:** ~30 segundos

---

## 📋 Qué hace el script

### FASE 1: Limpieza
- Detiene hostapd, dnsmasq, wpa_supplicant
- Mata procesos residuales
- Limpia configuración de wlan1
- Hace backup de archivos antiguos

### FASE 2: Configuración
- Configura wlan1 con IP 192.168.100.1
- Crea `/etc/dnsmasq.conf` limpio y correcto
- Crea `/etc/hostapd/hostapd.conf` limpio y correcto
- Crea archivo de leases
- Habilita IP forwarding
- Configura NAT
- Desactiva wpa_supplicant
- Configura NetworkManager

### FASE 3: Inicio
- Inicia hostapd
- Verifica que wlan1 esté en modo Master
- Inicia dnsmasq
- Verifica que ambos servicios estén activos

### FASE 4: Verificación
- Muestra estado de servicios
- Muestra configuración de red
- Muestra información de conexión

---

## ✅ Resultado Esperado

Al finalizar verás:

```
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║          ¡Configuración completada con éxito!             ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

Información de la red Wi-Fi:
  SSID: SENTINEL_IoT
  Contraseña: Sentinel2024
  Gateway: 192.168.100.1
  Rango DHCP: 192.168.100.10 - 192.168.100.250

Acceso al dashboard:
  Desde dispositivos conectados: http://192.168.100.1:8000
```

---

## 🔍 Ver Conexiones en Tiempo Real

Después de ejecutar el script, puedes ver cuando los dispositivos se conectan:

```bash
sudo journalctl -u dnsmasq -f
```

Verás mensajes como:

```
dnsmasq-dhcp[xxxx]: DHCPDISCOVER(wlan1) aa:bb:cc:dd:ee:ff
dnsmasq-dhcp[xxxx]: DHCPOFFER(wlan1) 192.168.100.10 aa:bb:cc:dd:ee:ff
dnsmasq-dhcp[xxxx]: DHCPREQUEST(wlan1) 192.168.100.10 aa:bb:cc:dd:ee:ff
dnsmasq-dhcp[xxxx]: DHCPACK(wlan1) 192.168.100.10 aa:bb:cc:dd:ee:ff
```

Esto significa que un dispositivo obtuvo la IP 192.168.100.10 correctamente.

---

## 📱 Conectar Dispositivos

1. **Busca la red Wi-Fi** en tu dispositivo móvil/laptop
   - SSID: `SENTINEL_IoT`

2. **Introduce la contraseña**
   - Contraseña: `Sentinel2024`

3. **Espera a conectar**
   - Deberías obtener una IP en el rango 192.168.100.x
   - El proceso debería tomar 5-10 segundos

4. **Accede al dashboard**
   - Abre el navegador: `http://192.168.100.1:8000`

---

## 🔧 Comandos Útiles

```bash
# Ver dispositivos conectados
cat /var/lib/misc/dnsmasq.leases

# Ver estado de servicios
sudo systemctl status hostapd
sudo systemctl status dnsmasq

# Ver configuración de wlan1
ip addr show wlan1
iwconfig wlan1

# Reiniciar servicios si es necesario
sudo systemctl restart hostapd dnsmasq

# Ver logs
sudo journalctl -u hostapd -f
sudo journalctl -u dnsmasq -f
```

---

## 🆘 Si Algo Sale Mal

### El script muestra errores

**Lee el mensaje de error.** El script te dirá exactamente qué falló.

Errores comunes:

1. **"hostapd no pudo iniciarse"**
   - Ver logs: `sudo journalctl -u hostapd -n 50`
   - Posible causa: wlan1 no existe o está en uso

2. **"dnsmasq no pudo iniciarse"**
   - Ver logs: `sudo journalctl -u dnsmasq -n 50`
   - Posible causa: puerto 53 en uso por otro servicio

### Volver a ejecutar el script

Puedes ejecutar el script **múltiples veces** sin problema. Siempre limpia antes de configurar.

```bash
sudo bash fix_wifi_complete.sh
```

### Verificar que wlan1 existe

```bash
ip link show wlan1
iwconfig wlan1
```

Si wlan1 no existe, verifica:

```bash
# Ver todas las interfaces
ip link show

# Ver adaptadores Wi-Fi
iwconfig

# Ver adaptadores USB
lsusb | grep -i wireless
```

---

## 📊 Diferencias con otros scripts

| Script | Uso |
|--------|-----|
| `fix_wifi_complete.sh` | **Solución completa** - Limpia y configura todo |
| `fix_wifi_dhcp.sh` | Solo corrige DHCP (asume que hostapd funciona) |
| `install_fixed.sh` | Instalación completa del sistema |
| `diagnose.sh` | Solo diagnóstico, no hace cambios |

**Recomendación:** Usa `fix_wifi_complete.sh` cuando tengas problemas con el Wi-Fi.

---

## 🎯 Solución de Problemas Específicos

### Problema: "interfase desconocida wlan1"

**Causa:** wlan1 no está configurada cuando dnsmasq intenta iniciar.

**Solución:** El script `fix_wifi_complete.sh` resuelve esto configurando wlan1 ANTES de iniciar dnsmasq.

### Problema: "Could not configure driver mode"

**Causa:** wpa_supplicant o NetworkManager están controlando wlan1.

**Solución:** El script desactiva wpa_supplicant y configura NetworkManager para ignorar wlan1.

### Problema: "Address already in use"

**Causa:** Otro servicio está usando el puerto 53 o 67.

**Solución:** El script mata todos los procesos conflictivos antes de iniciar.

### Problema: "cannot open or create lease file"

**Causa:** Falta el archivo `/var/lib/misc/dnsmasq.leases`.

**Solución:** El script crea el archivo con permisos correctos.

---

## 📝 Archivos Creados/Modificados

El script crea o modifica estos archivos:

```
/etc/dnsmasq.conf                    # Configuración de DHCP
/etc/hostapd/hostapd.conf            # Configuración de Wi-Fi
/etc/default/hostapd                 # Daemon de hostapd
/var/lib/misc/dnsmasq.leases         # Archivo de leases
/etc/sysctl.conf                     # IP forwarding
/etc/NetworkManager/NetworkManager.conf  # Configuración de NM
```

**Backups:** El script hace backup automático de archivos existentes con timestamp.

---

## 🔄 Hacer Permanente

El script ya configura todo para que sea permanente:

- ✅ Servicios habilitados con `systemctl enable`
- ✅ IP forwarding en `/etc/sysctl.conf`
- ✅ wpa_supplicant desactivado permanentemente
- ✅ NetworkManager configurado para ignorar wlan1

Después de un reinicio, todo debería funcionar automáticamente.

---

## 💡 Información Adicional

**Red Wi-Fi:**
- SSID: SENTINEL_IoT
- Contraseña: Sentinel2024 (puedes cambiarla editando el script)
- Seguridad: WPA2-PSK
- Canal: 6
- Modo: 802.11g/n

**Red:**
- Gateway: 192.168.100.1
- Rango DHCP: 192.168.100.10-250
- Máscara: 255.255.255.0 (/24)
- DNS: 192.168.100.1 (reenvía a 8.8.8.8)
- Lease time: 24 horas

**Acceso:**
- Dashboard: http://192.168.100.1:8000
- API: http://192.168.100.1:8000/api/docs

---

## ✨ Resumen

1. **Ejecuta:** `sudo bash fix_wifi_complete.sh`
2. **Espera:** ~30 segundos
3. **Conecta:** Busca "SENTINEL_IoT" en tu dispositivo
4. **Accede:** http://192.168.100.1:8000

¡Listo! Tu red Wi-Fi SENTINEL IoT estará funcionando correctamente.
