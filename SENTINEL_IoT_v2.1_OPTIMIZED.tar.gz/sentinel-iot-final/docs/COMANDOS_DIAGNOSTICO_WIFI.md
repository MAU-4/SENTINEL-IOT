# Comandos Rápidos de Diagnóstico Wi-Fi

Guía rápida de comandos para diagnosticar problemas con la red Wi-Fi SENTINEL_IoT.

## 🔍 Diagnóstico Rápido (Copiar y Pegar)

```bash
echo "=== DIAGNÓSTICO SENTINEL IOT WI-FI ==="
echo ""
echo "1. Estado de servicios:"
sudo systemctl status hostapd --no-pager | grep Active
sudo systemctl status dnsmasq --no-pager | grep Active
echo ""
echo "2. Configuración de wlan1:"
ip addr show wlan1 | grep "inet "
echo ""
echo "3. Procesos DHCP:"
ps aux | grep -v grep | grep dnsmasq
echo ""
echo "4. Dispositivos conectados:"
cat /var/lib/misc/dnsmasq.leases 2>/dev/null || echo "Ninguno"
echo ""
echo "5. Últimos logs de dnsmasq:"
sudo journalctl -u dnsmasq -n 10 --no-pager
```

Copia todo el bloque y pégalo en la terminal.

---

## 🚨 Solución Rápida

Si algo está mal, ejecuta:

```bash
sudo bash /ruta/sentinel-iot-v2/scripts/fix_wifi_dhcp.sh
```

---

## 📋 Comandos Individuales

### Ver estado de servicios

```bash
# hostapd (Wi-Fi)
sudo systemctl status hostapd

# dnsmasq (DHCP)
sudo systemctl status dnsmasq
```

### Ver configuración de red

```bash
# Ver IP de wlan1
ip addr show wlan1

# Ver todas las interfaces
ip addr

# Ver tabla de rutas
ip route
```

### Ver logs

```bash
# Logs de dnsmasq (últimos 50)
sudo journalctl -u dnsmasq -n 50

# Logs de hostapd (últimos 50)
sudo journalctl -u hostapd -n 50

# Logs en tiempo real
sudo journalctl -u dnsmasq -f
sudo journalctl -u hostapd -f
```

### Ver dispositivos conectados

```bash
# Archivo de leases
cat /var/lib/misc/dnsmasq.leases

# Ver en tiempo real
watch -n 2 cat /var/lib/misc/dnsmasq.leases
```

### Verificar configuración

```bash
# Configuración de dnsmasq
cat /etc/dnsmasq.conf

# Configuración de hostapd
cat /etc/hostapd/hostapd.conf

# Contraseña Wi-Fi
cat /root/sentinel-wifi-password.txt
```

---

## 🔧 Comandos de Corrección

### Reiniciar servicios

```bash
# Reiniciar ambos servicios
sudo systemctl restart hostapd dnsmasq

# Reiniciar solo dnsmasq
sudo systemctl restart dnsmasq

# Reiniciar solo hostapd
sudo systemctl restart hostapd
```

### Reconfigurar wlan1

```bash
# Bajar interfaz
sudo ip link set wlan1 down

# Limpiar configuración
sudo ip addr flush dev wlan1

# Levantar interfaz
sudo ip link set wlan1 up

# Asignar IP
sudo ip addr add 192.168.100.1/24 dev wlan1
```

### Verificar IP forwarding

```bash
# Ver estado
cat /proc/sys/net/ipv4/ip_forward

# Habilitar temporalmente
sudo sysctl -w net.ipv4.ip_forward=1

# Hacer permanente
echo "net.ipv4.ip_forward=1" | sudo tee -a /etc/sysctl.conf
```

### Verificar NAT

```bash
# Ver reglas de NAT
sudo nft list ruleset | grep -A 5 nat

# Añadir NAT si falta
MAIN_IF=$(ip route | grep default | awk '{print $5}' | head -1)
sudo nft add table ip nat
sudo nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; }
sudo nft add rule ip nat postrouting oifname "$MAIN_IF" masquerade
```

---

## 🧪 Pruebas de Conectividad

### Desde la Raspberry Pi

```bash
# Ping a wlan1
ping -c 4 192.168.100.1

# Ver si dnsmasq responde
sudo nmap -sU -p 67 192.168.100.1
```

### Desde un dispositivo conectado

```bash
# Ping al gateway
ping 192.168.100.1

# Ping a Internet
ping 8.8.8.8

# Resolución DNS
nslookup google.com
```

---

## 📊 Monitoreo en Tiempo Real

### Ver todo en una ventana

```bash
# Terminal 1: Logs de dnsmasq
sudo journalctl -u dnsmasq -f

# Terminal 2: Logs de hostapd
sudo journalctl -u hostapd -f

# Terminal 3: Dispositivos conectados
watch -n 2 cat /var/lib/misc/dnsmasq.leases
```

---

## 🔍 Identificar Problemas Específicos

### Problema: dnsmasq no inicia

```bash
# Ver por qué falló
sudo journalctl -u dnsmasq -n 50

# Ver qué está usando el puerto 53
sudo lsof -i :53

# Si es systemd-resolved
sudo systemctl stop systemd-resolved
sudo systemctl disable systemd-resolved
sudo systemctl restart dnsmasq
```

### Problema: hostapd no inicia

```bash
# Ver por qué falló
sudo journalctl -u hostapd -n 50

# Verificar que wlan1 existe
ip link show wlan1

# Verificar driver
iw list | grep -A 5 "Supported interface modes"

# Desactivar wpa_supplicant
sudo systemctl stop wpa_supplicant
sudo systemctl disable wpa_supplicant
```

### Problema: No se asignan IPs

```bash
# Ver si dnsmasq está escuchando
sudo netstat -ulnp | grep :67

# Ver configuración de DHCP
grep dhcp-range /etc/dnsmasq.conf

# Verificar archivo de leases
ls -la /var/lib/misc/dnsmasq.leases

# Crear si no existe
sudo mkdir -p /var/lib/misc
sudo touch /var/lib/misc/dnsmasq.leases
sudo chmod 644 /var/lib/misc/dnsmasq.leases
```

---

## 🎯 Script de Diagnóstico Completo

Guarda esto en un archivo y ejecútalo:

```bash
#!/bin/bash
echo "=== DIAGNÓSTICO COMPLETO SENTINEL IOT ==="
echo ""
echo "--- Servicios ---"
systemctl is-active hostapd && echo "hostapd: OK" || echo "hostapd: FALLO"
systemctl is-active dnsmasq && echo "dnsmasq: OK" || echo "dnsmasq: FALLO"
echo ""
echo "--- Interfaz wlan1 ---"
ip link show wlan1 > /dev/null 2>&1 && echo "wlan1: Existe" || echo "wlan1: NO EXISTE"
ip addr show wlan1 | grep -q "192.168.100.1" && echo "IP: OK (192.168.100.1)" || echo "IP: FALLO"
echo ""
echo "--- DHCP ---"
ps aux | grep -v grep | grep -q dnsmasq && echo "Proceso dnsmasq: OK" || echo "Proceso dnsmasq: FALLO"
[ -f /var/lib/misc/dnsmasq.leases ] && echo "Archivo leases: OK" || echo "Archivo leases: FALLO"
echo ""
echo "--- IP Forwarding ---"
[ "$(cat /proc/sys/net/ipv4/ip_forward)" = "1" ] && echo "IP forward: OK" || echo "IP forward: FALLO"
echo ""
echo "--- NAT ---"
sudo nft list ruleset | grep -q masquerade && echo "NAT: OK" || echo "NAT: FALLO"
echo ""
echo "--- Dispositivos conectados ---"
DEVICES=$(wc -l < /var/lib/misc/dnsmasq.leases 2>/dev/null || echo 0)
echo "Total: $DEVICES dispositivos"
echo ""
echo "--- Últimos logs de dnsmasq ---"
sudo journalctl -u dnsmasq -n 5 --no-pager
```

---

## 💾 Guardar Diagnóstico en Archivo

```bash
# Guardar todo el diagnóstico
{
  echo "=== DIAGNÓSTICO $(date) ==="
  echo ""
  echo "--- Servicios ---"
  sudo systemctl status hostapd --no-pager
  echo ""
  sudo systemctl status dnsmasq --no-pager
  echo ""
  echo "--- Configuración ---"
  ip addr show wlan1
  echo ""
  cat /etc/dnsmasq.conf
  echo ""
  echo "--- Logs ---"
  sudo journalctl -u dnsmasq -n 100 --no-pager
  echo ""
  sudo journalctl -u hostapd -n 100 --no-pager
} > ~/sentinel-diagnostico-$(date +%Y%m%d_%H%M%S).txt

echo "Diagnóstico guardado en: ~/sentinel-diagnostico-*.txt"
```

---

## 🆘 Ayuda Rápida

**Problema más común:** dnsmasq no asigna IPs

**Solución en 3 comandos:**

```bash
sudo systemctl stop dnsmasq hostapd
sudo ip addr add 192.168.100.1/24 dev wlan1
sudo systemctl start dnsmasq hostapd
```

**Si no funciona, usa el script automático:**

```bash
sudo bash /ruta/sentinel-iot-v2/scripts/fix_wifi_dhcp.sh
```

---

**Tip:** Guarda esta página como referencia rápida. La mayoría de problemas se resuelven reiniciando los servicios o reconfigurando wlan1.
