# Guía de Implementación: RaspAP + SENTINEL IoT

## 🎯 Objetivo

Implementar RaspAP como base de red para SENTINEL IoT, eliminando los problemas de configuración manual de hostapd y dnsmasq.

---

## 📋 Requisitos Previos

- Raspberry Pi 3, 4, o 5
- Raspberry Pi OS Lite (Debian 11, 12 o 13)
- Adaptador Wi-Fi USB (para wlan1)
- Conexión a Internet (ethernet o wlan0)
- Acceso SSH o monitor/teclado

---

## 🚀 Instalación Paso a Paso

### Paso 1: Preparar el Sistema

```bash
# Actualizar sistema
sudo apt update
sudo apt upgrade -y

# Verificar adaptadores Wi-Fi
iwconfig

# Deberías ver wlan0 y wlan1
```

### Paso 2: Instalar RaspAP

```bash
# Instalación con un comando
curl -sL https://install.raspap.com | bash
```

**Durante la instalación, responde:**

```
Install ad blocking (Adblock)? [Y/n]: n
Install OpenVPN? [Y/n]: n
Install WireGuard? [Y/n]: n
Install OpenVPN GUI? [Y/n]: n
Enable WiFi client AP mode? [Y/n]: y
Install RaspAP? [Y/n]: y
Reboot now? [Y/n]: y
```

**Tiempo estimado:** 5-10 minutos

### Paso 3: Configuración Inicial de RaspAP

Después del reinicio:

1. **Conectar a la red Wi-Fi de RaspAP:**
   - SSID: `raspi-webgui`
   - Contraseña: `ChangeMe`

2. **Acceder a la interfaz web:**
   - URL: `http://10.3.141.1`
   - Usuario: `admin`
   - Contraseña: `secret`

3. **Cambiar contraseña de administración:**
   - Ir a: `System` → `Admin`
   - Cambiar contraseña
   - Guardar

### Paso 4: Configurar Red SENTINEL IoT

#### 4.1 Configurar Hotspot

1. Ir a: `Hotspot` → `Basic`
2. Configurar:
   ```
   Interface: wlan1
   SSID: SENTINEL_IoT
   Wireless Mode: 802.11n - 2.4 GHz
   Channel: 6
   Country Code: US (o tu país)
   ```
3. Guardar y aplicar

#### 4.2 Configurar Seguridad

1. Ir a: `Hotspot` → `Security`
2. Configurar:
   ```
   Security Type: WPA2
   Encryption Type: CCMP
   PSK: Sentinel2024 (o tu contraseña)
   ```
3. Guardar y aplicar

#### 4.3 Configurar DHCP

1. Ir a: `DHCP Server` → `Server settings`
2. Configurar:
   ```
   Interface: wlan1
   Starting IP Address: 192.168.100.10
   Ending IP Address: 192.168.100.250
   Static Leases: (vacío por ahora)
   Lease Time: 24h
   DNS Server 1: 192.168.100.1
   DNS Server 2: 8.8.8.8
   ```
3. Guardar y aplicar

#### 4.4 Configurar Interfaz de Red

1. Ir a: `Networking` → `Summary`
2. Para wlan1, configurar:
   ```
   IP Address: 192.168.100.1
   Subnet Mask: 255.255.255.0
   Gateway: (dejar vacío)
   ```
3. Guardar y aplicar

### Paso 5: Reiniciar Servicios

```bash
# Desde SSH
sudo systemctl restart hostapd
sudo systemctl restart dnsmasq
```

O desde la interfaz web:
- `System` → `Restart hotspot`

### Paso 6: Verificar Funcionamiento

1. **Buscar red Wi-Fi:** `SENTINEL_IoT`
2. **Conectar** con contraseña configurada
3. **Verificar IP:** Deberías obtener 192.168.100.x
4. **Acceder a RaspAP:** `http://192.168.100.1`

---

## 🔧 Instalar SENTINEL IoT Backend

### Paso 7: Instalar Dependencias

```bash
# Conectar por SSH a la Raspberry Pi
ssh pi@192.168.100.1

# Instalar Python y dependencias
sudo apt install -y python3-pip python3-venv git

# Crear directorio para SENTINEL
sudo mkdir -p /opt/sentinel-iot
sudo chown $USER:$USER /opt/sentinel-iot
cd /opt/sentinel-iot
```

### Paso 8: Instalar Backend de SENTINEL

```bash
# Copiar archivos del proyecto
# (Asumiendo que tienes los archivos en ~/sentinel-iot-v2)
cp -r ~/sentinel-iot-v2/backend/* /opt/sentinel-iot/

# Crear entorno virtual
python3 -m venv venv
source venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt
```

### Paso 9: Configurar Servicio de SENTINEL

```bash
# Crear servicio systemd
sudo nano /etc/systemd/system/sentinel-iot.service
```

Contenido:

```ini
[Unit]
Description=SENTINEL IoT Backend
After=network.target raspap.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/sentinel-iot
Environment="PATH=/opt/sentinel-iot/venv/bin"
ExecStart=/opt/sentinel-iot/venv/bin/python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Guardar y habilitar:

```bash
sudo systemctl daemon-reload
sudo systemctl enable sentinel-iot
sudo systemctl start sentinel-iot
```

### Paso 10: Verificar Instalación

```bash
# Ver estado
sudo systemctl status sentinel-iot

# Ver logs
sudo journalctl -u sentinel-iot -f
```

Acceder desde navegador:
- Dashboard SENTINEL: `http://192.168.100.1:8000`
- API SENTINEL: `http://192.168.100.1:8000/api/docs`

---

## 🔗 Integración RaspAP + SENTINEL

### Opción A: Interfaces Separadas (Recomendada)

**Acceso:**
- RaspAP (gestión de red): `http://192.168.100.1`
- SENTINEL (seguridad): `http://192.168.100.1:8000`

**Ventajas:**
- Separación de responsabilidades
- Fácil mantenimiento
- Sin modificaciones complejas

### Opción B: Dashboard Unificado

Modificar el dashboard de SENTINEL para incluir enlaces a RaspAP:

```html
<!-- En frontend/public/index.html -->
<div class="quick-links">
    <a href="http://192.168.100.1" target="_blank">
        <button>Gestión de Red (RaspAP)</button>
    </a>
    <a href="/api/docs" target="_blank">
        <button>API Documentation</button>
    </a>
</div>
```

### Opción C: Integración API (Avanzada)

Usar la API de RaspAP desde SENTINEL:

```python
# En backend/app/services/raspap_integration.py
import requests

class RaspAPClient:
    def __init__(self, base_url="http://localhost"):
        self.base_url = base_url
        self.session = requests.Session()
    
    def get_connected_devices(self):
        """Obtener dispositivos conectados desde RaspAP"""
        # RaspAP no tiene API REST oficial aún
        # Alternativa: parsear archivo de leases
        with open('/var/lib/misc/dnsmasq.leases', 'r') as f:
            leases = f.readlines()
        
        devices = []
        for lease in leases:
            parts = lease.strip().split()
            if len(parts) >= 4:
                devices.append({
                    'mac': parts[1],
                    'ip': parts[2],
                    'hostname': parts[3],
                    'lease_time': parts[0]
                })
        return devices
```

---

## 🎨 Personalización

### Cambiar Logo de RaspAP

```bash
# Subir tu logo
sudo cp /path/to/sentinel-logo.png /var/www/html/app/img/logo.png

# Reiniciar servidor web
sudo systemctl restart lighttpd
```

### Cambiar Tema de Colores

1. Ir a: `System` → `Themes`
2. Seleccionar tema o crear custom CSS

### Añadir Página Personalizada

```bash
# Crear página custom
sudo nano /var/www/html/sentinel.php
```

Contenido:

```php
<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Redirigir a dashboard de SENTINEL
header('Location: http://192.168.100.1:8000');
exit;
?>
```

Añadir enlace en menú de RaspAP.

---

## 🔒 Seguridad

### Cambiar Contraseñas por Defecto

```bash
# Contraseña de admin de RaspAP
# Ya hecho en Paso 3

# Contraseña de Wi-Fi
# Ya hecho en Paso 4.2

# Contraseña de SSH (recomendado)
passwd
```

### Configurar Firewall

RaspAP incluye gestión de firewall:

1. Ir a: `Firewall` → `Rules`
2. Añadir reglas:
   ```
   # Permitir acceso a SENTINEL desde red IoT
   -A INPUT -i wlan1 -p tcp --dport 8000 -j ACCEPT
   
   # Bloquear acceso a RaspAP desde Internet
   -A INPUT -i eth0 -p tcp --dport 80 -j DROP
   ```

### Limitar Acceso a Interfaz Web

```bash
# Editar configuración de lighttpd
sudo nano /etc/lighttpd/lighttpd.conf
```

Añadir:

```
$HTTP["remoteip"] !~ "192.168.100.*" {
    url.access-deny = ( "" )
}
```

Esto permite acceso solo desde la red IoT.

---

## 📊 Monitoreo y Mantenimiento

### Ver Dispositivos Conectados

**Desde RaspAP:**
- Dashboard → Ver lista de clientes

**Desde CLI:**
```bash
cat /var/lib/misc/dnsmasq.leases
```

**Desde SENTINEL:**
```bash
curl http://localhost:8000/api/v1/devices
```

### Ver Logs

```bash
# Logs de hostapd
sudo journalctl -u hostapd -f

# Logs de dnsmasq
sudo journalctl -u dnsmasq -f

# Logs de SENTINEL
sudo journalctl -u sentinel-iot -f

# Logs de RaspAP
sudo tail -f /var/log/lighttpd/error.log
```

### Backup de Configuración

```bash
# Backup de RaspAP
sudo tar -czf raspap-backup-$(date +%Y%m%d).tar.gz \
    /etc/hostapd \
    /etc/dnsmasq.conf \
    /etc/dhcpcd.conf

# Backup de SENTINEL
sudo tar -czf sentinel-backup-$(date +%Y%m%d).tar.gz \
    /opt/sentinel-iot
```

---

## 🔄 Actualización

### Actualizar RaspAP

```bash
cd /var/www/html
sudo git pull
```

### Actualizar SENTINEL IoT

```bash
cd /opt/sentinel-iot
source venv/bin/activate
git pull  # Si usas git
pip install -r requirements.txt --upgrade
sudo systemctl restart sentinel-iot
```

---

## 🆘 Solución de Problemas

### RaspAP no inicia

```bash
# Ver estado
sudo systemctl status hostapd
sudo systemctl status dnsmasq

# Reiniciar servicios
sudo systemctl restart hostapd dnsmasq lighttpd
```

### No se puede acceder a la interfaz web

```bash
# Verificar que lighttpd está corriendo
sudo systemctl status lighttpd

# Verificar puerto 80
sudo netstat -tlnp | grep :80

# Reiniciar
sudo systemctl restart lighttpd
```

### SENTINEL IoT no inicia

```bash
# Ver logs
sudo journalctl -u sentinel-iot -n 50

# Verificar puerto 8000
sudo lsof -i :8000

# Reiniciar
sudo systemctl restart sentinel-iot
```

### Conflicto de puertos

Si RaspAP y SENTINEL compiten por el puerto 80:

**Opción 1:** Cambiar puerto de RaspAP

```bash
sudo nano /etc/lighttpd/lighttpd.conf
# Cambiar: server.port = 8080
sudo systemctl restart lighttpd
```

**Opción 2:** Usar proxy reverso (nginx)

```bash
sudo apt install nginx
sudo nano /etc/nginx/sites-available/sentinel
```

Configuración:

```nginx
server {
    listen 80;
    server_name _;
    
    location / {
        proxy_pass http://localhost:8080;  # RaspAP
    }
    
    location /sentinel {
        proxy_pass http://localhost:8000;  # SENTINEL
    }
}
```

---

## 📈 Mejoras Futuras

### 1. Captive Portal

Activar portal cautivo de RaspAP:
- `System` → `Advanced` → `Captive Portal`
- Configurar página de bienvenida personalizada

### 2. VPN para Acceso Remoto

Instalar WireGuard desde RaspAP:
```bash
cd /var/www/html
sudo bash installers/wireguard.sh
```

### 3. Análisis de Tráfico

Integrar con Wireshark:
```bash
sudo apt install wireshark tshark
```

Capturar tráfico desde SENTINEL para análisis de ML.

---

## 📚 Recursos

- **RaspAP Docs:** https://docs.raspap.com/
- **GitHub:** https://github.com/RaspAP/raspap-webgui
- **Foro:** https://github.com/RaspAP/raspap-webgui/discussions
- **FAQ:** https://docs.raspap.com/faq/

---

## ✅ Checklist de Implementación

- [ ] Sistema actualizado
- [ ] RaspAP instalado
- [ ] Contraseña de admin cambiada
- [ ] Red SENTINEL_IoT configurada
- [ ] DHCP configurado (192.168.100.10-250)
- [ ] Dispositivo de prueba conectado exitosamente
- [ ] Backend de SENTINEL instalado
- [ ] Servicio sentinel-iot activo
- [ ] Dashboard accesible en puerto 8000
- [ ] Firewall configurado
- [ ] Backup de configuración realizado

---

## 🎉 Resultado Final

Después de seguir esta guía tendrás:

✅ Red Wi-Fi **SENTINEL_IoT** funcionando perfectamente
✅ Interfaz web de administración de red (RaspAP)
✅ Backend de SENTINEL IoT con ML y seguridad
✅ Dashboard de monitoreo en tiempo real
✅ Sistema robusto y fácil de mantener

**Accesos:**
- Gestión de red: `http://192.168.100.1`
- Dashboard SENTINEL: `http://192.168.100.1:8000`
- API SENTINEL: `http://192.168.100.1:8000/api/docs`
