# Guía de Instalación Optimizada - SENTINEL IoT para Raspberry Pi

**Versión**: 2.1-OPTIMIZED  
**Fecha**: 2025-11-13  
**Autor**: Manus AI

## 🎯 Características de esta Instalación

Esta versión optimizada incluye:
- ✅ **IPs estáticas** (sin DHCP/dnsmasq)
- ✅ **Backend completo** con FastAPI
- ✅ **Dashboard web** con control de Internet ON/OFF
- ✅ **nftables** configurado para firewall y NAT
- ✅ **Punto de acceso Wi-Fi** con hostapd
- ✅ **Servicio systemd** para arranque automático

---

## 📋 Requisitos Previos

### Hardware
- **Raspberry Pi 3 Modelo B+** (o superior)
- **Adaptador Wi-Fi USB** (para wlan1)
- **Tarjeta microSD** de 16 GB o más
- **Fuente de alimentación** 5V/2.5A mínimo

### Software
- **Raspberry Pi OS** (Debian Bookworm o superior)
- **Acceso a Internet** durante la instalación
- **Acceso SSH** o monitor/teclado conectado

---

## 🚀 Instalación Paso a Paso

### Paso 1: Preparar la Raspberry Pi

```bash
# Actualizar sistema (opcional pero recomendado)
sudo apt-get update
sudo apt-get upgrade -y
```

### Paso 2: Transferir el Proyecto

```bash
# Opción A: Descargar el tarball
cd ~
# (transferir SENTINEL_IoT_v2.1_OPTIMIZED.tar.gz a la RPi)
tar -xzf SENTINEL_IoT_v2.1_OPTIMIZED.tar.gz
cd sentinel-iot-final

# Opción B: Clonar desde repositorio
# git clone <url-del-repo>
# cd sentinel-iot-final
```

### Paso 3: Ejecutar el Instalador

```bash
cd scripts/installation
sudo bash install_raspberry_optimized.sh
```

El script realizará automáticamente:
1. ✅ Actualización del sistema
2. ✅ Instalación de dependencias
3. ✅ Configuración de Wi-Fi
4. ✅ Configuración de interfaces de red
5. ✅ Configuración de hostapd
6. ✅ Configuración de nftables
7. ✅ Instalación del backend
8. ✅ Creación de servicios systemd
9. ✅ Inicio de servicios
10. ✅ Verificación de instalación

**Tiempo estimado**: 5-10 minutos

### Paso 4: Reiniciar la Raspberry Pi

```bash
sudo reboot
```

---

## 🌐 Configuración de Red

### Red IoT Creada

| Parámetro | Valor |
|:----------|:------|
| **SSID** | `SENTINEL_IoT` |
| **Contraseña** | `Raspberry` (CAMBIAR en producción) |
| **IP Gateway** | `192.168.50.1` |
| **Red** | `192.168.50.0/24` |
| **Tipo** | IPs estáticas (sin DHCP) |

### Configurar Dispositivos IoT

Cada dispositivo debe configurarse manualmente con:

| Parámetro | Valor |
|:----------|:------|
| **IP Address** | `192.168.50.X` (ej: 192.168.50.100, .101, .102...) |
| **Subnet Mask** | `255.255.255.0` |
| **Gateway** | `192.168.50.1` |
| **DNS** | `8.8.8.8` o `192.168.50.1` |

**Importante**: No uses las IPs `.0` (red) ni `.1` (gateway) ni `.255` (broadcast)

---

## 📱 Acceso al Dashboard

### Desde un Dispositivo Conectado a SENTINEL_IoT

1. **Conectar a la red Wi-Fi**:
   - SSID: `SENTINEL_IoT`
   - Contraseña: `Raspberry`

2. **Configurar IP estática** en el dispositivo:
   - IP: `192.168.50.100` (o cualquier IP libre)
   - Gateway: `192.168.50.1`
   - DNS: `8.8.8.8`

3. **Abrir navegador**:
   ```
   http://192.168.50.1:8000
   ```

### Funcionalidades del Dashboard

- 📊 **Estado del Sistema**: Información general
- 🔌 **Control de Internet**: Botón ON/OFF para habilitar/deshabilitar acceso a Internet
- 📡 **Dispositivos Conectados**: Lista de dispositivos en la red
- 🛡️ **Reglas de nftables**: Visualización en tiempo real de las reglas del firewall

---

## 🧪 Pruebas de Funcionalidad

### 1. Verificar Servicios

```bash
# Ver estado de todos los servicios
sudo systemctl status hostapd
sudo systemctl status sentinel-backend
sudo systemctl status nftables

# Ver logs del backend
sudo journalctl -u sentinel-backend -f

# Ver logs de hostapd
sudo journalctl -u hostapd -f
```

### 2. Verificar Interfaces de Red

```bash
# Ver configuración de interfaces
ip addr show

# Debería mostrar:
# - wlan0: con IP de tu red doméstica (DHCP)
# - wlan1: con IP 192.168.50.1
```

### 3. Verificar Reglas de Firewall

```bash
sudo nft list ruleset
```

Deberías ver:
- Tabla `inet filter` con chains: input, forward, output
- Tabla `ip nat` con chain postrouting (masquerade)

### 4. Probar Control de Internet

1. Conectar un dispositivo a `SENTINEL_IoT`
2. Configurar IP estática en el dispositivo
3. Abrir dashboard: `http://192.168.50.1:8000`
4. Hacer clic en el botón **"Internet: ON"**
5. Verificar que cambia a **"Internet: OFF"**
6. Probar conectividad desde el dispositivo (debería estar bloqueado)
7. Hacer clic nuevamente para volver a **"Internet: ON"**

---

## 🔧 Comandos Útiles

### Ver Logs

```bash
# Backend
sudo journalctl -u sentinel-backend -f

# hostapd
sudo journalctl -u hostapd -f

# nftables
sudo journalctl -u nftables -f

# Todos los logs del sistema
sudo journalctl -f
```

### Reiniciar Servicios

```bash
sudo systemctl restart sentinel-backend
sudo systemctl restart hostapd
sudo systemctl restart nftables
```

### Ver Estado de Internet

```bash
# Ver reglas de nftables
sudo nft list ruleset | grep drop

# Si hay una regla "drop" en forward, Internet está bloqueado
```

### Habilitar/Deshabilitar Internet Manualmente

```bash
# Deshabilitar Internet
sudo nft add rule inet filter forward drop

# Habilitar Internet (eliminar la regla)
# Primero ver el handle de la regla:
sudo nft -a list chain inet filter forward

# Luego eliminarla:
sudo nft delete rule inet filter forward handle <número>
```

---

## 🐛 Solución de Problemas

### Problema 1: No se puede acceder al dashboard

**Síntomas**: El navegador no carga `http://192.168.50.1:8000`

**Solución**:
```bash
# Verificar que el backend está corriendo
sudo systemctl status sentinel-backend

# Si no está activo, ver los logs
sudo journalctl -u sentinel-backend -n 50

# Reiniciar el servicio
sudo systemctl restart sentinel-backend

# Verificar que el puerto 8000 está escuchando
sudo netstat -tlnp | grep 8000
```

### Problema 2: No aparece la red Wi-Fi

**Síntomas**: No se ve `SENTINEL_IoT` en la lista de redes

**Solución**:
```bash
# Verificar hostapd
sudo systemctl status hostapd

# Ver logs
sudo journalctl -u hostapd -n 50

# Verificar que wlan1 existe
ip addr show wlan1

# Reiniciar hostapd
sudo systemctl restart hostapd

# Si sigue sin funcionar, verificar el adaptador USB
lsusb
iwconfig
```

### Problema 3: Sin acceso a Internet desde dispositivos IoT

**Síntomas**: Los dispositivos no pueden navegar por Internet

**Solución**:
```bash
# Verificar IP forwarding
sysctl net.ipv4.ip_forward
# Debe devolver: net.ipv4.ip_forward = 1

# Si no está habilitado:
sudo sysctl -w net.ipv4.ip_forward=1

# Verificar reglas de NAT
sudo nft list table ip nat

# Verificar que no hay regla de drop en forward
sudo nft list chain inet filter forward

# Si hay una regla drop, eliminarla (es el control de Internet)
```

### Problema 4: El botón ON/OFF no funciona

**Síntomas**: Al hacer clic en el botón, no cambia de estado

**Solución**:
```bash
# Verificar que el backend está corriendo
sudo systemctl status sentinel-backend

# Ver logs en tiempo real
sudo journalctl -u sentinel-backend -f

# Probar la API manualmente
curl http://192.168.50.1:8000/api/v1/internet/status
curl -X POST http://192.168.50.1:8000/api/v1/internet/toggle

# Verificar permisos de nftables
# El backend debe poder ejecutar comandos nft (corre como root)
```

---

## 🔒 Seguridad

### Cambiar Contraseña Wi-Fi

```bash
# Editar configuración de hostapd
sudo nano /etc/hostapd/hostapd.conf

# Cambiar la línea:
# wpa_passphrase=TU_NUEVA_CONTRASEÑA

# Guardar y reiniciar hostapd
sudo systemctl restart hostapd
```

### Cambiar SSID

```bash
# Editar configuración de hostapd
sudo nano /etc/hostapd/hostapd.conf

# Cambiar la línea:
# ssid=TU_NUEVO_NOMBRE

# Guardar y reiniciar hostapd
sudo systemctl restart hostapd
```

---

## 📊 Arquitectura del Sistema

```
Internet
   ↓
[wlan0] ← Raspberry Pi → [wlan1]
                ↓
         (192.168.50.1)
                ↓
          [nftables]
          Firewall + NAT
                ↓
         Red IoT Wi-Fi
       (SENTINEL_IoT)
                ↓
      Dispositivos IoT
    (IPs estáticas)
```

---

## ✅ Verificación Final

Si todo está correcto, deberías tener:

1. ✅ Red Wi-Fi `SENTINEL_IoT` visible
2. ✅ Dashboard accesible en `http://192.168.50.1:8000`
3. ✅ Botón de control de Internet funcionando
4. ✅ Dispositivos IoT con acceso a Internet (cuando está habilitado)
5. ✅ Reglas de nftables visibles en el dashboard
6. ✅ Servicios iniciándose automáticamente al arrancar

---

**¡SENTINEL IoT está listo para proteger tu red IoT!** 🚀
