"""
API endpoints para control de acceso a Internet
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict
import logging

from app.services.internet_controller import internet_controller

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/internet", tags=["Internet Control"])


class InternetStatusResponse(BaseModel):
    """Respuesta del estado de Internet"""
    enabled: bool
    message: str
    last_modified: str = None


class InternetToggleResponse(BaseModel):
    """Respuesta al cambiar estado de Internet"""
    success: bool
    message: str
    enabled: bool


class InternetRulesResponse(BaseModel):
    """Respuesta con las reglas de nftables"""
    rules: list
    count: int


@router.get("/status", response_model=InternetStatusResponse)
async def get_internet_status():
    """
    Obtiene el estado actual del acceso a Internet
    
    Returns:
        InternetStatusResponse: Estado actual (enabled, message, last_modified)
    """
    try:
        status = internet_controller.get_status()
        return InternetStatusResponse(**status)
    except Exception as e:
        logger.error(f"Error al obtener estado: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/enable", response_model=InternetToggleResponse)
async def enable_internet():
    """
    Habilita el acceso a Internet para todos los dispositivos
    
    Returns:
        InternetToggleResponse: Resultado de la operación
    """
    try:
        result = internet_controller.enable()
        
        if not result["success"]:
            raise HTTPException(status_code=500, detail=result["message"])
        
        return InternetToggleResponse(**result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error al habilitar Internet: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/disable", response_model=InternetToggleResponse)
async def disable_internet():
    """
    Deshabilita el acceso a Internet para todos los dispositivos
    
    Returns:
        InternetToggleResponse: Resultado de la operación
    """
    try:
        result = internet_controller.disable()
        
        if not result["success"]:
            raise HTTPException(status_code=500, detail=result["message"])
        
        return InternetToggleResponse(**result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error al deshabilitar Internet: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/toggle", response_model=InternetToggleResponse)
async def toggle_internet():
    """
    Cambia el estado del acceso a Internet (ON/OFF)
    
    Si está habilitado, lo deshabilita.
    Si está deshabilitado, lo habilita.
    
    Returns:
        InternetToggleResponse: Resultado de la operación con nuevo estado
    """
    try:
        result = internet_controller.toggle()
        
        if not result["success"]:
            raise HTTPException(status_code=500, detail=result["message"])
        
        return InternetToggleResponse(**result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error al cambiar estado: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/rules", response_model=InternetRulesResponse)
async def get_internet_rules():
    """
    Obtiene las reglas de nftables relacionadas con Internet
    
    Returns:
        InternetRulesResponse: Lista de reglas activas
    """
    try:
        rules = internet_controller.get_rules()
        return InternetRulesResponse(
            rules=rules,
            count=len(rules)
        )
    except Exception as e:
        logger.error(f"Error al obtener reglas: {e}")
        raise HTTPException(status_code=500, detail=str(e))
