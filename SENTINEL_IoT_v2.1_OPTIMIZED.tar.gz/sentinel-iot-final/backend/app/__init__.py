"""
SENTINEL IoT v2.0 - Backend Application
"""
__version__ = "2.0.0"
