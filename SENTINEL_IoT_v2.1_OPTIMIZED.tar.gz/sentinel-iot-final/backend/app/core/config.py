"""
Configuración central de SENTINEL IoT v2.0
"""
from typing import Optional, List
from pydantic_settings import BaseSettings
from pydantic import Field, validator
import secrets


class Settings(BaseSettings):
    """Configuración de la aplicación"""
    
    # Información del proyecto
    PROJECT_NAME: str = "SENTINEL IoT v2.0"
    VERSION: str = "2.0.0"
    DESCRIPTION: str = "Plataforma Integral de Seguridad IoT con Machine Learning"
    
    # API
    API_V1_PREFIX: str = "/api/v1"
    SECRET_KEY: str = Field(default_factory=lambda: secrets.token_urlsafe(32))
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    ALGORITHM: str = "HS256"
    
    # CORS
    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "https://sentinel.local"
    ]
    
    # Base de datos
    DATABASE_URL: str = "sqlite:///./sentinel.db"
    DATABASE_ECHO: bool = False
    
    # Redis
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: Optional[str] = None
    
    # Red
    IOT_INTERFACE: str = "wlan1"
    IOT_NETWORK: str = "192.168.100.0/24"
    IOT_GATEWAY: str = "192.168.100.1"
    IOT_DHCP_RANGE_START: str = "192.168.100.10"
    IOT_DHCP_RANGE_END: str = "192.168.100.250"
    
    MAIN_INTERFACE: str = "eth0"
    
    # Wi-Fi
    WIFI_SSID: str = "SENTINEL_IoT"
    WIFI_PASSWORD: str = Field(default_factory=lambda: secrets.token_urlsafe(16))
    WIFI_CHANNEL: int = 6
    WIFI_COUNTRY_CODE: str = "US"
    
    # Firewall
    NFTABLES_TABLE: str = "sentinel"
    NFTABLES_CHAIN_INPUT: str = "input"
    NFTABLES_CHAIN_FORWARD: str = "forward"
    NFTABLES_CHAIN_OUTPUT: str = "output"
    DEFAULT_POLICY: str = "drop"
    
    # Monitoreo
    MONITOR_INTERVAL: int = 5  # segundos
    METRICS_RETENTION_DAYS: int = 30
    LOG_RETENTION_DAYS: int = 90
    
    # Machine Learning
    ML_MODEL_PATH: str = "./data/models"
    ML_ANOMALY_THRESHOLD: float = 0.85
    ML_RETRAIN_INTERVAL_HOURS: int = 24
    ML_MIN_SAMPLES_TRAIN: int = 1000
    
    # Alertas
    ALERT_EMAIL_ENABLED: bool = False
    ALERT_EMAIL_FROM: Optional[str] = None
    ALERT_EMAIL_TO: Optional[str] = None
    ALERT_EMAIL_SMTP_HOST: Optional[str] = None
    ALERT_EMAIL_SMTP_PORT: int = 587
    ALERT_EMAIL_SMTP_USER: Optional[str] = None
    ALERT_EMAIL_SMTP_PASSWORD: Optional[str] = None
    
    ALERT_TELEGRAM_ENABLED: bool = False
    ALERT_TELEGRAM_BOT_TOKEN: Optional[str] = None
    ALERT_TELEGRAM_CHAT_ID: Optional[str] = None
    
    ALERT_WEBHOOK_ENABLED: bool = False
    ALERT_WEBHOOK_URL: Optional[str] = None
    
    # Reportes
    REPORT_OUTPUT_PATH: str = "./data/reports"
    REPORT_SCHEDULE_DAILY: bool = True
    REPORT_SCHEDULE_WEEKLY: bool = True
    REPORT_SCHEDULE_MONTHLY: bool = True
    
    # Integraciones
    HOMEASSISTANT_ENABLED: bool = False
    HOMEASSISTANT_URL: Optional[str] = None
    HOMEASSISTANT_TOKEN: Optional[str] = None
    
    MQTT_ENABLED: bool = False
    MQTT_BROKER: str = "localhost"
    MQTT_PORT: int = 1883
    MQTT_USERNAME: Optional[str] = None
    MQTT_PASSWORD: Optional[str] = None
    MQTT_TOPIC_PREFIX: str = "sentinel"
    
    PROMETHEUS_ENABLED: bool = False
    PROMETHEUS_PORT: int = 9090
    
    # Seguridad
    ENABLE_MFA: bool = False
    SESSION_TIMEOUT_MINUTES: int = 30
    MAX_LOGIN_ATTEMPTS: int = 5
    LOCKOUT_DURATION_MINUTES: int = 15
    
    # Logs
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "./data/logs/sentinel.log"
    LOG_MAX_BYTES: int = 10485760  # 10MB
    LOG_BACKUP_COUNT: int = 5
    
    # Desarrollo
    DEBUG: bool = False
    TESTING: bool = False
    
    @validator("BACKEND_CORS_ORIGINS", pre=True)
    def assemble_cors_origins(cls, v):
        if isinstance(v, str):
            return [i.strip() for i in v.split(",")]
        return v
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Instancia global de configuración
settings = Settings()
