#!/bin/bash
################################################################################
# SENTINEL IoT - Instalación Correcta de hostapd y dnsmasq
# 
# Basado en mejores prácticas de:
# - SparkFun Tutorial
# - Raspberry Pi Official Documentation
# 
# Este script instala y configura correctamente hostapd y dnsmasq
# siguiendo el orden y métodos recomendados
################################################################################

set -e  # Salir si hay errores

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║     SENTINEL IoT - Instalación Profesional de Wi-Fi AP        ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Error: Este script debe ejecutarse como root"
    echo "   Usa: sudo bash $0"
    exit 1
fi

# Variables de configuración
SSID="SENTINEL_IoT"
PASSWORD="Sentinel2024!"
CHANNEL="6"
IOT_IP="192.168.50.1"
IOT_NETWORK="192.168.50.0"
IOT_NETMASK="255.255.255.0"
IOT_BROADCAST="192.168.50.255"
DHCP_START="192.168.50.10"
DHCP_END="192.168.50.250"
WIFI_INTERFACE="wlan1"

echo "Configuración del Punto de Acceso:"
echo "  • SSID: $SSID"
echo "  • Contraseña: $PASSWORD"
echo "  • Canal: $CHANNEL"
echo "  • IP Gateway: $IOT_IP"
echo "  • Rango DHCP: $DHCP_START - $DHCP_END"
echo "  • Interfaz: $WIFI_INTERFACE"
echo ""

read -p "¿Deseas continuar con esta configuración? (s/n): " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[SsYy]$ ]]; then
    echo "Instalación cancelada."
    exit 0
fi

# ============================================================================
# FASE 1: ACTUALIZAR SISTEMA E INSTALAR PAQUETES
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  FASE 1: Actualizar Sistema e Instalar Paquetes"
echo "════════════════════════════════════════════════════════════════"
echo ""

echo "[1/12] Actualizando lista de paquetes..."
apt-get update -qq
echo "   ✓ Lista actualizada"

echo ""
echo "[2/12] Instalando hostapd y dnsmasq..."
apt-get install -y hostapd dnsmasq > /dev/null 2>&1
echo "   ✓ Paquetes instalados"

echo ""
echo "[3/12] Deteniendo servicios temporalmente..."
systemctl stop hostapd 2>/dev/null || true
systemctl stop dnsmasq 2>/dev/null || true
echo "   ✓ Servicios detenidos"

# ============================================================================
# FASE 2: CONFIGURAR IP ESTÁTICA EN WLAN1
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  FASE 2: Configurar IP Estática"
echo "════════════════════════════════════════════════════════════════"
echo ""

echo "[4/12] Configurando dhcpcd para ignorar $WIFI_INTERFACE..."

# Hacer backup de dhcpcd.conf
cp /etc/dhcpcd.conf /etc/dhcpcd.conf.backup.$(date +%Y%m%d_%H%M%S)

# Eliminar configuraciones anteriores de wlan1
sed -i "/^denyinterfaces $WIFI_INTERFACE/d" /etc/dhcpcd.conf

# Añadir configuración al final
echo "" >> /etc/dhcpcd.conf
echo "# SENTINEL IoT - Ignorar $WIFI_INTERFACE (gestionado por hostapd)" >> /etc/dhcpcd.conf
echo "denyinterfaces $WIFI_INTERFACE" >> /etc/dhcpcd.conf

echo "   ✓ dhcpcd configurado"

echo ""
echo "[5/12] Configurando IP estática en /etc/network/interfaces..."

# Hacer backup de interfaces
cp /etc/network/interfaces /etc/network/interfaces.backup.$(date +%Y%m%d_%H%M%S)

# Eliminar configuraciones anteriores de wlan1
sed -i "/allow-hotplug $WIFI_INTERFACE/,/broadcast/d" /etc/network/interfaces

# Añadir configuración al final
cat >> /etc/network/interfaces << EOF

# SENTINEL IoT - Configuración de $WIFI_INTERFACE
allow-hotplug $WIFI_INTERFACE
iface $WIFI_INTERFACE inet static
    address $IOT_IP
    netmask $IOT_NETMASK
    network $IOT_NETWORK
    broadcast $IOT_BROADCAST
EOF

echo "   ✓ IP estática configurada"

# ============================================================================
# FASE 3: CONFIGURAR HOSTAPD
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  FASE 3: Configurar hostapd"
echo "════════════════════════════════════════════════════════════════"
echo ""

echo "[6/12] Creando configuración de hostapd..."

# Hacer backup si existe
if [ -f /etc/hostapd/hostapd.conf ]; then
    cp /etc/hostapd/hostapd.conf /etc/hostapd/hostapd.conf.backup.$(date +%Y%m%d_%H%M%S)
fi

# Crear configuración limpia
cat > /etc/hostapd/hostapd.conf << EOF
# SENTINEL IoT - Configuración de hostapd
interface=$WIFI_INTERFACE
driver=nl80211

# Configuración de red
ssid=$SSID
hw_mode=g
channel=$CHANNEL
ieee80211n=1
wmm_enabled=1
ht_capab=[HT40][SHORT-GI-20][DSSS_CCK-40]

# Configuración de seguridad
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_key_mgmt=WPA-PSK
wpa_passphrase=$PASSWORD
rsn_pairwise=CCMP
EOF

echo "   ✓ hostapd.conf creado"

echo ""
echo "[7/12] Configurando ruta del archivo de configuración..."

# Hacer backup de /etc/default/hostapd
cp /etc/default/hostapd /etc/default/hostapd.backup.$(date +%Y%m%d_%H%M%S)

# Actualizar DAEMON_CONF
sed -i 's|^#DAEMON_CONF=.*|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd
sed -i 's|^DAEMON_CONF=.*|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd

# Si no existe la línea, añadirla
if ! grep -q "^DAEMON_CONF=" /etc/default/hostapd; then
    echo 'DAEMON_CONF="/etc/hostapd/hostapd.conf"' >> /etc/default/hostapd
fi

echo "   ✓ Ruta configurada"

# ============================================================================
# FASE 4: CONFIGURAR DNSMASQ
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  FASE 4: Configurar dnsmasq"
echo "════════════════════════════════════════════════════════════════"
echo ""

echo "[8/12] Respaldando configuración original de dnsmasq..."
if [ -f /etc/dnsmasq.conf ] && [ ! -f /etc/dnsmasq.conf.orig ]; then
    mv /etc/dnsmasq.conf /etc/dnsmasq.conf.orig
    echo "   ✓ Backup creado: /etc/dnsmasq.conf.orig"
else
    echo "   ℹ Backup ya existe o no hay archivo original"
fi

echo ""
echo "[9/12] Creando configuración limpia de dnsmasq..."

cat > /etc/dnsmasq.conf << EOF
# SENTINEL IoT - Configuración de dnsmasq

# Interfaz a usar
interface=$WIFI_INTERFACE

# Dirección de escucha
listen-address=$IOT_IP

# Vincular solo a esta interfaz
bind-interfaces

# Servidor DNS upstream (Google DNS)
server=8.8.8.8
server=8.8.4.4

# No reenviar nombres sin dominio
domain-needed

# No reenviar direcciones privadas a DNS upstream
bogus-priv

# Rango DHCP
dhcp-range=$DHCP_START,$DHCP_END,$IOT_NETMASK,24h

# Gateway por defecto
dhcp-option=3,$IOT_IP

# Servidor DNS para clientes
dhcp-option=6,$IOT_IP

# Archivo de leases
dhcp-leasefile=/var/lib/misc/dnsmasq.leases

# Log de DHCP (útil para debugging)
log-dhcp

# Archivo de log
log-facility=/var/log/dnsmasq.log
EOF

echo "   ✓ dnsmasq.conf creado"

# Crear directorio y archivo de leases
mkdir -p /var/lib/misc
touch /var/lib/misc/dnsmasq.leases
chmod 644 /var/lib/misc/dnsmasq.leases

echo "   ✓ Archivo de leases creado"

# ============================================================================
# FASE 5: CONFIGURAR NAT E IP FORWARDING
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  FASE 5: Configurar NAT e IP Forwarding"
echo "════════════════════════════════════════════════════════════════"
echo ""

echo "[10/12] Habilitando IP forwarding..."

# Hacer backup de sysctl.conf
cp /etc/sysctl.conf /etc/sysctl.conf.backup.$(date +%Y%m%d_%H%M%S)

# Descomentar o añadir net.ipv4.ip_forward=1
sed -i 's|^#net.ipv4.ip_forward=1|net.ipv4.ip_forward=1|' /etc/sysctl.conf

if ! grep -q "^net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
fi

# Aplicar inmediatamente
sysctl -w net.ipv4.ip_forward=1 > /dev/null

echo "   ✓ IP forwarding habilitado"

echo ""
echo "[11/12] Configurando NAT con iptables..."

# Detectar interfaz principal
MAIN_IF=$(ip route | grep default | awk '{print $5}' | head -1)

if [ -z "$MAIN_IF" ]; then
    echo "   ⚠ No se detectó interfaz con Internet"
    echo ""
    ip link show | grep -E "^[0-9]+" | awk '{print "   - " $2}' | sed 's/:$//'
    echo ""
    read -p "   Ingresa el nombre de la interfaz con Internet (ej: eth0, wlan0): " MAIN_IF
fi

echo "   • Interfaz principal: $MAIN_IF"

# Configurar iptables
iptables -t nat -A POSTROUTING -o $MAIN_IF -j MASQUERADE
iptables -A FORWARD -i $MAIN_IF -o $WIFI_INTERFACE -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i $WIFI_INTERFACE -o $MAIN_IF -j ACCEPT

echo "   ✓ Reglas de iptables aplicadas"

# Guardar reglas
sh -c "iptables-save > /etc/iptables.ipv4.nat"
echo "   ✓ Reglas guardadas en /etc/iptables.ipv4.nat"

# Configurar restauración automática en rc.local
if [ -f /etc/rc.local ]; then
    cp /etc/rc.local /etc/rc.local.backup.$(date +%Y%m%d_%H%M%S)
    
    # Eliminar líneas anteriores de iptables-restore
    sed -i '/iptables-restore/d' /etc/rc.local
    
    # Añadir antes de exit 0
    sed -i '/^exit 0/i iptables-restore < /etc/iptables.ipv4.nat' /etc/rc.local
else
    # Crear rc.local si no existe
    cat > /etc/rc.local << 'EOF'
#!/bin/sh -e
#
# rc.local
#
# This script is executed at the end of each multiuser runlevel.

iptables-restore < /etc/iptables.ipv4.nat

exit 0
EOF
    chmod +x /etc/rc.local
fi

echo "   ✓ Restauración automática configurada"

# ============================================================================
# FASE 6: DESACTIVAR SERVICIOS CONFLICTIVOS
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  FASE 6: Desactivar Servicios Conflictivos"
echo "════════════════════════════════════════════════════════════════"
echo ""

echo "[12/12] Desactivando wpa_supplicant en $WIFI_INTERFACE..."

# Detener wpa_supplicant
systemctl stop wpa_supplicant 2>/dev/null || true
killall wpa_supplicant 2>/dev/null || true

# Configurar NetworkManager para ignorar wlan1
if [ -f /etc/NetworkManager/NetworkManager.conf ]; then
    if ! grep -q "unmanaged-devices=interface-name:$WIFI_INTERFACE" /etc/NetworkManager/NetworkManager.conf; then
        echo "" >> /etc/NetworkManager/NetworkManager.conf
        echo "[keyfile]" >> /etc/NetworkManager/NetworkManager.conf
        echo "unmanaged-devices=interface-name:$WIFI_INTERFACE" >> /etc/NetworkManager/NetworkManager.conf
        systemctl restart NetworkManager 2>/dev/null || true
    fi
fi

echo "   ✓ Servicios conflictivos desactivados"

# ============================================================================
# FASE 7: HABILITAR E INICIAR SERVICIOS
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  FASE 7: Habilitar e Iniciar Servicios"
echo "════════════════════════════════════════════════════════════════"
echo ""

echo "Habilitando servicios para inicio automático..."
systemctl unmask hostapd 2>/dev/null || true
systemctl enable hostapd
systemctl enable dnsmasq
echo "   ✓ Servicios habilitados"

echo ""
echo "Iniciando servicios..."

# Configurar wlan1 manualmente primero
ip link set $WIFI_INTERFACE down 2>/dev/null || true
ip addr flush dev $WIFI_INTERFACE 2>/dev/null || true
ip link set $WIFI_INTERFACE up
ip addr add $IOT_IP/24 dev $WIFI_INTERFACE

echo "   ✓ $WIFI_INTERFACE configurado"

# Iniciar hostapd
systemctl start hostapd
sleep 3

# Verificar hostapd
if systemctl is-active --quiet hostapd; then
    echo "   ✓ hostapd iniciado correctamente"
else
    echo "   ✗ Error al iniciar hostapd"
    echo ""
    echo "Logs de hostapd:"
    journalctl -u hostapd -n 20 --no-pager
    exit 1
fi

# Iniciar dnsmasq
systemctl start dnsmasq
sleep 2

# Verificar dnsmasq
if systemctl is-active --quiet dnsmasq; then
    echo "   ✓ dnsmasq iniciado correctamente"
else
    echo "   ✗ Error al iniciar dnsmasq"
    echo ""
    echo "Logs de dnsmasq:"
    journalctl -u dnsmasq -n 20 --no-pager
    exit 1
fi

# ============================================================================
# VERIFICACIÓN FINAL
# ============================================================================
echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║              INSTALACIÓN COMPLETADA EXITOSAMENTE               ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

echo "Configuración del Punto de Acceso:"
echo "  • SSID: $SSID"
echo "  • Contraseña: $PASSWORD"
echo "  • IP Gateway: $IOT_IP"
echo "  • Rango DHCP: $DHCP_START - $DHCP_END"
echo "  • Interfaz: $WIFI_INTERFACE"
echo "  • Interfaz Internet: $MAIN_IF"
echo ""

echo "Estado de Servicios:"
systemctl is-active --quiet hostapd && echo "  ✓ hostapd: ACTIVO" || echo "  ✗ hostapd: INACTIVO"
systemctl is-active --quiet dnsmasq && echo "  ✓ dnsmasq: ACTIVO" || echo "  ✗ dnsmasq: INACTIVO"
echo ""

echo "Configuración de Red:"
echo "  • IP Forwarding: $(cat /proc/sys/net/ipv4/ip_forward)"
echo "  • Reglas NAT: $(iptables -t nat -L POSTROUTING | grep -c MASQUERADE) configuradas"
echo ""

echo "════════════════════════════════════════════════════════════════"
echo "  PRÓXIMOS PASOS"
echo "════════════════════════════════════════════════════════════════"
echo ""
echo "1. Desde otro dispositivo, busca la red Wi-Fi: $SSID"
echo "2. Conéctate usando la contraseña: $PASSWORD"
echo "3. Deberías obtener una IP en el rango $DHCP_START - $DHCP_END"
echo "4. Prueba el acceso a Internet: ping 8.8.8.8"
echo ""
echo "Comandos útiles:"
echo "  • Ver dispositivos conectados:"
echo "    cat /var/lib/misc/dnsmasq.leases"
echo ""
echo "  • Ver logs de hostapd:"
echo "    sudo journalctl -u hostapd -f"
echo ""
echo "  • Ver logs de dnsmasq:"
echo "    sudo journalctl -u dnsmasq -f"
echo ""
echo "  • Reiniciar servicios:"
echo "    sudo systemctl restart hostapd dnsmasq"
echo ""
echo "════════════════════════════════════════════════════════════════"
echo ""

# Guardar contraseña en archivo
echo "$PASSWORD" > /root/sentinel-wifi-password.txt
chmod 600 /root/sentinel-wifi-password.txt
echo "Contraseña guardada en: /root/sentinel-wifi-password.txt"
echo ""

echo "✓ Instalación completada. El sistema está listo para usar."
echo ""

exit 0
