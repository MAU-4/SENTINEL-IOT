#!/bin/bash
#
# SENTINEL IoT v2.0 - Script de Instalación Completo y Definitivo
# 
# Este script instala SENTINEL IoT completo manejando correctamente:
# - Entornos virtuales de Python en Debian/Ubuntu modernos
# - Configuración de hostapd y dnsmasq
# - Firewall con nftables
# - Servicio systemd
#

set -e  # Salir si hay error (excepto donde se maneja explícitamente)

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables de configuración
INSTALL_DIR="/opt/sentinel-iot"
DATA_DIR="/var/lib/sentinel-iot"
LOG_DIR="/var/log/sentinel-iot"
BACKUP_DIR="$DATA_DIR/backups"

# Configuración de red
IOT_INTERFACE="wlan1"
MAIN_INTERFACE="eth0"
IOT_NETWORK="192.168.50.0/24"
IOT_GATEWAY="192.168.50.1"
DHCP_START="192.168.50.10"
DHCP_END="192.168.50.250"

# Configuración de Wi-Fi
SSID="SENTINEL_IoT"
PASSWORD="Sentinel2024!"
CHANNEL="6"

# Funciones de utilidad
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    log_error "Este script debe ejecutarse como root (sudo)"
    exit 1
fi

# Banner
echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║       SENTINEL IoT v2.0 - Instalación Definitiva         ║"
echo "║                                                           ║"
echo "║     Plataforma Integral de Seguridad IoT con ML          ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""

# ============================================================================
# PASO 1: Verificar requisitos del sistema
# ============================================================================
log_info "Verificando requisitos del sistema..."

# Detectar interfaz principal con Internet
if ip link show eth0 > /dev/null 2>&1 && ip route | grep -q "default.*eth0"; then
    MAIN_INTERFACE="eth0"
elif ip link show wlan0 > /dev/null 2>&1 && ip route | grep -q "default.*wlan0"; then
    MAIN_INTERFACE="wlan0"
else
    log_warning "No se detectó interfaz principal, usando eth0 por defecto"
    MAIN_INTERFACE="eth0"
fi

log_info "Interfaz principal detectada: $MAIN_INTERFACE"

# Verificar interfaz IoT
if ! ip link show $IOT_INTERFACE > /dev/null 2>&1; then
    log_warning "Interfaz IoT $IOT_INTERFACE no encontrada"
    log_warning "Continuando de todos modos (puede ser un entorno de prueba)"
fi

log_success "Requisitos verificados"

# ============================================================================
# PASO 2: Actualizar sistema
# ============================================================================
log_info "Actualizando sistema (esto puede tomar varios minutos)..."
apt-get update -qq > /dev/null 2>&1
log_success "Sistema actualizado"

# ============================================================================
# PASO 3: Instalar dependencias del sistema
# ============================================================================
log_info "Instalando dependencias del sistema..."

# Herramientas de red
apt-get install -y -qq \
    hostapd \
    dnsmasq \
    nftables \
    net-tools \
    iptables-persistent > /dev/null 2>&1

# Python y herramientas
apt-get install -y -qq \
    python3 \
    python3-pip \
    python3-venv \
    python3-full > /dev/null 2>&1

log_success "Dependencias instaladas"

# ============================================================================
# PASO 4: Crear estructura de directorios
# ============================================================================
log_info "Creando estructura de directorios..."

mkdir -p $INSTALL_DIR
mkdir -p $DATA_DIR/{logs,backups,models,reports}
mkdir -p $LOG_DIR
mkdir -p /etc/sentinel-iot

chmod 755 $INSTALL_DIR
chmod 755 $DATA_DIR
chmod 755 $LOG_DIR

log_success "Directorios creados"

# ============================================================================
# PASO 5: Copiar archivos de la aplicación
# ============================================================================
log_info "Copiando archivos de la aplicación..."

# Obtener el directorio del proyecto
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")"

log_info "Directorio del proyecto: $PROJECT_DIR"

# Copiar backend
if [ -d "$PROJECT_DIR/backend" ]; then
    cp -r "$PROJECT_DIR/backend/"* $INSTALL_DIR/ 2>/dev/null || true
    log_success "Archivos del backend copiados"
else
    log_warning "No se encontró directorio backend, creando estructura básica..."
    mkdir -p $INSTALL_DIR/app/{core,models,services,ml,api}
    touch $INSTALL_DIR/app/__init__.py
    touch $INSTALL_DIR/app/core/__init__.py
    touch $INSTALL_DIR/app/models/__init__.py
    touch $INSTALL_DIR/app/services/__init__.py
    touch $INSTALL_DIR/app/ml/__init__.py
    touch $INSTALL_DIR/app/api/__init__.py
fi

# Copiar frontend
if [ -d "$PROJECT_DIR/frontend/public" ]; then
    mkdir -p $INSTALL_DIR/frontend/public
    cp -r "$PROJECT_DIR/frontend/public/"* $INSTALL_DIR/frontend/public/ 2>/dev/null || true
    chmod -R 755 $INSTALL_DIR/frontend
    log_success "Interfaz web copiada"
else
    log_warning "No se encontró frontend, la interfaz web no estará disponible"
fi

# ============================================================================
# PASO 6: Configurar entorno Python (CORREGIDO)
# ============================================================================
log_info "Configurando entorno Python..."

cd $INSTALL_DIR

# Eliminar venv anterior si existe
if [ -d "venv" ]; then
    log_info "Eliminando entorno virtual anterior..."
    rm -rf venv
fi

# Crear entorno virtual con acceso a paquetes del sistema
log_info "Creando entorno virtual..."
python3 -m venv venv --system-site-packages

# Cambiar permisos del venv
chown -R root:root venv
chmod -R 755 venv

# Activar entorno virtual
source venv/bin/activate

# Actualizar pip dentro del venv
log_info "Actualizando pip..."
pip install --upgrade pip --quiet 2>/dev/null || pip install --upgrade pip --break-system-packages --quiet

# Instalar dependencias Python
log_info "Instalando paquetes Python (esto puede tomar un momento)..."

# Intentar instalación normal primero
if pip install fastapi uvicorn[standard] sqlalchemy pydantic pydantic-settings --quiet 2>/dev/null; then
    log_success "Paquetes Python instalados correctamente"
else
    # Si falla, intentar con --break-system-packages
    log_info "Instalación normal falló, intentando método alternativo..."
    if pip install --break-system-packages fastapi uvicorn[standard] sqlalchemy pydantic pydantic-settings --quiet 2>/dev/null; then
        log_success "Paquetes Python instalados (método alternativo)"
    else
        log_error "No se pudieron instalar los paquetes Python"
        log_error "Intenta ejecutar manualmente:"
        log_error "  cd $INSTALL_DIR"
        log_error "  source venv/bin/activate"
        log_error "  pip install fastapi uvicorn sqlalchemy pydantic pydantic-settings"
        exit 1
    fi
fi

# Desactivar venv
deactivate

log_success "Entorno Python configurado"

# ============================================================================
# PASO 7: Crear archivo de configuración
# ============================================================================
log_info "Creando archivo de configuración..."

cat > /etc/sentinel-iot/config.env << EOF
# SENTINEL IoT Configuration
PROJECT_NAME="SENTINEL IoT v2.0"
DEBUG=false
LOG_LEVEL=INFO
DATABASE_URL=sqlite:///$DATA_DIR/sentinel.db
IOT_INTERFACE=$IOT_INTERFACE
IOT_GATEWAY=$IOT_GATEWAY
IOT_NETWORK=$IOT_NETWORK
MAIN_INTERFACE=$MAIN_INTERFACE
EOF

chmod 644 /etc/sentinel-iot/config.env
log_success "Configuración creada"

# ============================================================================
# PASO 8: Configurar hostapd
# ============================================================================
log_info "Configurando hostapd..."

# Detener servicios si están corriendo
systemctl stop hostapd 2>/dev/null || true
systemctl stop dnsmasq 2>/dev/null || true

# Hacer backup de configuración anterior
if [ -f /etc/hostapd/hostapd.conf ]; then
    mv /etc/hostapd/hostapd.conf /etc/hostapd/hostapd.conf.backup.$(date +%Y%m%d_%H%M%S)
fi

# Crear configuración de hostapd
cat > /etc/hostapd/hostapd.conf << EOF
# Interfaz
interface=$IOT_INTERFACE
driver=nl80211

# Red
ssid=$SSID
hw_mode=g
channel=$CHANNEL
ieee80211n=1
wmm_enabled=1

# Seguridad
auth_algs=1
wpa=2
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP
wpa_passphrase=$PASSWORD

# Configuración adicional
macaddr_acl=0
ignore_broadcast_ssid=0
EOF

chmod 600 /etc/hostapd/hostapd.conf

# Configurar daemon
if [ -f /etc/default/hostapd ]; then
    sed -i 's|#DAEMON_CONF=""|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd
fi

log_success "hostapd configurado"

# ============================================================================
# PASO 9: Configurar dnsmasq
# ============================================================================
log_info "Configurando dnsmasq..."

# Hacer backup
if [ -f /etc/dnsmasq.conf ]; then
    mv /etc/dnsmasq.conf /etc/dnsmasq.conf.backup.$(date +%Y%m%d_%H%M%S)
fi

# Crear configuración limpia
cat > /etc/dnsmasq.conf << EOF
# Interfaz
interface=$IOT_INTERFACE
bind-dynamic

# Rango DHCP
dhcp-range=$DHCP_START,$DHCP_END,255.255.255.0,24h

# Gateway y DNS
dhcp-option=3,$IOT_GATEWAY
dhcp-option=6,$IOT_GATEWAY

# Archivo de leases
dhcp-leasefile=/var/lib/misc/dnsmasq.leases
EOF

# Crear archivo de leases
mkdir -p /var/lib/misc
touch /var/lib/misc/dnsmasq.leases
chmod 644 /var/lib/misc/dnsmasq.leases

log_success "dnsmasq configurado"

# ============================================================================
# PASO 10: Configurar interfaces de red
# ============================================================================
log_info "Configurando interfaces de red..."

# Desactivar NetworkManager en la interfaz IoT
if command -v nmcli &> /dev/null; then
    nmcli device set $IOT_INTERFACE managed no 2>/dev/null || true
fi

# Configurar IP estática en dhcpcd
if [ -f /etc/dhcpcd.conf ]; then
    # Eliminar configuración anterior de wlan1 si existe
    sed -i '/interface wlan1/,/^$/d' /etc/dhcpcd.conf
    
    # Añadir nueva configuración
    cat >> /etc/dhcpcd.conf << EOF

# SENTINEL IoT - Interfaz IoT
interface $IOT_INTERFACE
    static ip_address=$IOT_GATEWAY/24
    nohook wpa_supplicant
EOF
fi

# Configurar interfaz inmediatamente
ip link set $IOT_INTERFACE down 2>/dev/null || true
ip addr flush dev $IOT_INTERFACE 2>/dev/null || true
ip link set $IOT_INTERFACE up 2>/dev/null || true
ip addr add $IOT_GATEWAY/24 dev $IOT_INTERFACE 2>/dev/null || true

log_success "Interfaces configuradas"

# ============================================================================
# PASO 11: Configurar IP forwarding y NAT
# ============================================================================
log_info "Configurando IP forwarding y NAT..."

# Habilitar IP forwarding
echo 1 > /proc/sys/net/ipv4/ip_forward
if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
fi

# Configurar NAT con iptables (más compatible)
iptables -t nat -F
iptables -t nat -A POSTROUTING -o $MAIN_INTERFACE -j MASQUERADE
iptables -A FORWARD -i $IOT_INTERFACE -o $MAIN_INTERFACE -j ACCEPT
iptables -A FORWARD -i $MAIN_INTERFACE -o $IOT_INTERFACE -m state --state RELATED,ESTABLISHED -j ACCEPT

# Guardar reglas
iptables-save > /etc/iptables/rules.v4

log_success "NAT configurado"

# ============================================================================
# PASO 12: Crear servicio systemd
# ============================================================================
log_info "Creando servicio systemd..."

cat > /etc/systemd/system/sentinel-iot.service << EOF
[Unit]
Description=SENTINEL IoT Security Platform
After=network.target hostapd.service dnsmasq.service
Wants=hostapd.service dnsmasq.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
ExecStart=$INSTALL_DIR/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

chmod 644 /etc/systemd/system/sentinel-iot.service

# Recargar systemd
systemctl daemon-reload

log_success "Servicio systemd creado"

# ============================================================================
# PASO 13: Habilitar e iniciar servicios
# ============================================================================
log_info "Habilitando e iniciando servicios..."

# Deshabilitar wpa_supplicant en wlan1
systemctl disable wpa_supplicant 2>/dev/null || true
systemctl mask wpa_supplicant 2>/dev/null || true

# Habilitar servicios
systemctl unmask hostapd 2>/dev/null || true
systemctl enable hostapd
systemctl enable dnsmasq
systemctl enable sentinel-iot

# Iniciar hostapd primero
log_info "Iniciando hostapd..."
systemctl start hostapd
sleep 3

if systemctl is-active --quiet hostapd; then
    log_success "hostapd iniciado correctamente"
else
    log_error "hostapd no se pudo iniciar"
    log_info "Ver logs: journalctl -u hostapd -n 50"
fi

# Iniciar dnsmasq
log_info "Iniciando dnsmasq..."
systemctl start dnsmasq
sleep 2

if systemctl is-active --quiet dnsmasq; then
    log_success "dnsmasq iniciado correctamente"
else
    log_error "dnsmasq no se pudo iniciar"
    log_info "Ver logs: journalctl -u dnsmasq -n 50"
fi

# Iniciar SENTINEL IoT
log_info "Iniciando SENTINEL IoT..."
systemctl start sentinel-iot
sleep 3

if systemctl is-active --quiet sentinel-iot; then
    log_success "SENTINEL IoT iniciado correctamente"
else
    log_warning "SENTINEL IoT no se pudo iniciar (puede ser normal si falta configuración)"
    log_info "Ver logs: journalctl -u sentinel-iot -n 50"
fi

# ============================================================================
# PASO 14: Verificación final
# ============================================================================
echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}║          Instalación Completada Exitosamente             ║${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

log_info "Resumen de la instalación:"
echo ""
echo "  📡 Red Wi-Fi:"
echo "     SSID: $SSID"
echo "     Contraseña: $PASSWORD"
echo "     Canal: $CHANNEL"
echo ""
echo "  🌐 Configuración de red:"
echo "     Gateway: $IOT_GATEWAY"
echo "     Rango DHCP: $DHCP_START - $DHCP_END"
echo "     Interfaz IoT: $IOT_INTERFACE"
echo "     Interfaz principal: $MAIN_INTERFACE"
echo ""
echo "  🔧 Servicios:"
echo "     hostapd: $(systemctl is-active hostapd)"
echo "     dnsmasq: $(systemctl is-active dnsmasq)"
echo "     sentinel-iot: $(systemctl is-active sentinel-iot)"
echo ""
echo "  📊 Dashboard:"
echo "     URL: http://$IOT_GATEWAY:8000"
echo "     API: http://$IOT_GATEWAY:8000/docs"
echo ""
echo "  📁 Directorios:"
echo "     Instalación: $INSTALL_DIR"
echo "     Datos: $DATA_DIR"
echo "     Logs: $LOG_DIR"
echo ""

log_info "Comandos útiles:"
echo ""
echo "  # Ver estado de servicios"
echo "  sudo systemctl status hostapd"
echo "  sudo systemctl status dnsmasq"
echo "  sudo systemctl status sentinel-iot"
echo ""
echo "  # Ver logs"
echo "  sudo journalctl -u hostapd -f"
echo "  sudo journalctl -u dnsmasq -f"
echo "  sudo journalctl -u sentinel-iot -f"
echo ""
echo "  # Reiniciar servicios"
echo "  sudo systemctl restart hostapd"
echo "  sudo systemctl restart dnsmasq"
echo "  sudo systemctl restart sentinel-iot"
echo ""
echo "  # Ver dispositivos conectados"
echo "  cat /var/lib/misc/dnsmasq.leases"
echo "  arp -n | grep $IOT_NETWORK"
echo ""

log_success "¡SENTINEL IoT está listo para usar!"
echo ""
