#!/bin/bash

################################################################################
# SENTINEL IoT v2.0 - Script de Instalación (Sin DHCP - Solo IPs Estáticas)
# 
# Este script instala SENTINEL IoT sin configurar dnsmasq (servidor DHCP).
# Los dispositivos IoT deberán configurarse manualmente con IPs estáticas.
#
# Red IoT: 192.168.50.0/24
# Gateway (Raspberry Pi): 192.168.50.1
# Rango disponible para dispositivos: 192.168.50.10 - 192.168.50.254
#
# Autor: SENTINEL IoT Team
# Versión: 2.0
################################################################################

set -e  # Salir si hay errores

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables de configuración
INSTALL_DIR="/opt/sentinel-iot"
SERVICE_NAME="sentinel-iot"
WIFI_INTERFACE="wlan0"
MAIN_INTERFACE="eth0"
IOT_NETWORK="192.168.50.0/24"
GATEWAY_IP="192.168.50.1"
SSID="SENTINEL_IoT"
WIFI_PASSWORD="sentinel2024"

# Función para imprimir mensajes
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[ADVERTENCIA]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then 
    print_error "Este script debe ejecutarse como root (sudo)"
    exit 1
fi

# Verificar que estamos en Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/cpuinfo; then
    print_warning "Este script está diseñado para Raspberry Pi"
    read -p "¿Deseas continuar de todos modos? (s/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        exit 1
    fi
fi

print_info "==================================================================="
print_info "  SENTINEL IoT v2.0 - Instalación (Sin DHCP - Solo IPs Estáticas)"
print_info "==================================================================="
echo

# 1. Actualizar sistema
print_info "Actualizando sistema..."
apt-get update -y
apt-get upgrade -y
print_success "Sistema actualizado"

# 2. Instalar dependencias del sistema
print_info "Instalando dependencias del sistema..."
apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    hostapd \
    nftables \
    iptables \
    net-tools \
    wireless-tools \
    iw \
    rfkill \
    git \
    curl \
    vim

print_success "Dependencias instaladas"

# 3. Configurar interfaz Wi-Fi
print_info "Configurando interfaz Wi-Fi ($WIFI_INTERFACE)..."

# Desbloquear Wi-Fi
rfkill unblock wifi

# Configurar IP estática para wlan0
cat > /etc/network/interfaces.d/wlan0 << EOF
# Interfaz Wi-Fi para red IoT
auto $WIFI_INTERFACE
iface $WIFI_INTERFACE inet static
    address $GATEWAY_IP
    netmask 255.255.255.0
    network 192.168.50.0
    broadcast 192.168.50.255
EOF

print_success "Interfaz Wi-Fi configurada"

# 4. Configurar hostapd (Access Point)
print_info "Configurando hostapd..."

cat > /etc/hostapd/hostapd.conf << EOF
# Configuración de Access Point para SENTINEL IoT
interface=$WIFI_INTERFACE
driver=nl80211
ssid=$SSID
hw_mode=g
channel=6
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=$WIFI_PASSWORD
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
EOF

# Configurar ruta del archivo de configuración
echo 'DAEMON_CONF="/etc/hostapd/hostapd.conf"' > /etc/default/hostapd

# Habilitar y arrancar hostapd
systemctl unmask hostapd
systemctl enable hostapd

print_success "hostapd configurado"

# 5. Configurar nftables (firewall y NAT)
print_info "Configurando nftables..."

cat > /etc/nftables.conf << EOF
#!/usr/sbin/nft -f

# Limpiar reglas existentes
flush ruleset

# Tabla para NAT
table ip nat {
    chain prerouting {
        type nat hook prerouting priority -100;
    }

    chain postrouting {
        type nat hook postrouting priority 100;
        # NAT para salida a Internet
        oifname "$MAIN_INTERFACE" masquerade
    }
}

# Tabla para filtrado (SENTINEL)
table ip sentinel {
    chain forward {
        type filter hook forward priority 0; policy accept;
        # Las reglas de Internet se agregarán dinámicamente desde la API
    }

    chain input {
        type filter hook input priority 0; policy accept;
        # Permitir tráfico local
        iif lo accept
        # Permitir conexiones establecidas
        ct state established,related accept
        # Permitir SSH
        tcp dport 22 accept
        # Permitir API (puerto 8000)
        tcp dport 8000 accept
        # Permitir DHCP (aunque no lo usemos, por si acaso)
        udp dport 67 accept
        udp dport 68 accept
        # Permitir DNS
        udp dport 53 accept
        tcp dport 53 accept
    }

    chain output {
        type filter hook output priority 0; policy accept;
    }
}
EOF

# Habilitar nftables
systemctl enable nftables
systemctl start nftables

print_success "nftables configurado"

# 6. Habilitar IP forwarding
print_info "Habilitando IP forwarding..."
echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
sysctl -p
print_success "IP forwarding habilitado"

# 7. Crear directorio de instalación
print_info "Creando directorio de instalación..."
mkdir -p $INSTALL_DIR
mkdir -p $INSTALL_DIR/backend
mkdir -p $INSTALL_DIR/frontend
mkdir -p $INSTALL_DIR/data
mkdir -p $INSTALL_DIR/logs
print_success "Directorios creados"

# 8. Copiar archivos del proyecto
print_info "Copiando archivos del proyecto..."

# Determinar directorio de origen
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

if [ -d "$SOURCE_DIR/backend" ]; then
    cp -r "$SOURCE_DIR/backend"/* "$INSTALL_DIR/backend/"
    cp -r "$SOURCE_DIR/frontend"/* "$INSTALL_DIR/frontend/"
    print_success "Archivos copiados desde $SOURCE_DIR"
else
    print_error "No se encontró el directorio backend en $SOURCE_DIR"
    print_info "Por favor, copia manualmente los archivos a $INSTALL_DIR"
fi

# 9. Crear entorno virtual de Python
print_info "Creando entorno virtual de Python..."
cd $INSTALL_DIR/backend
python3 -m venv venv
source venv/bin/activate

# 10. Instalar dependencias de Python
print_info "Instalando dependencias de Python..."
pip install --upgrade pip
pip install \
    fastapi \
    uvicorn[standard] \
    pydantic \
    pydantic-settings \
    sqlalchemy \
    python-multipart \
    requests \
    scapy \
    scikit-learn \
    numpy \
    pandas

print_success "Dependencias de Python instaladas"

# 11. Crear servicio systemd
print_info "Creando servicio systemd..."

cat > /etc/systemd/system/$SERVICE_NAME.service << EOF
[Unit]
Description=SENTINEL IoT Security Platform
After=network.target hostapd.service nftables.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR/backend
Environment="PATH=$INSTALL_DIR/backend/venv/bin"
ExecStart=$INSTALL_DIR/backend/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable $SERVICE_NAME

print_success "Servicio systemd creado"

# 12. Crear script de inicio manual
print_info "Creando script de inicio manual..."

cat > $INSTALL_DIR/start.sh << 'EOF'
#!/bin/bash
cd /opt/sentinel-iot/backend
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
EOF

chmod +x $INSTALL_DIR/start.sh

print_success "Script de inicio creado"

# 13. Información final
echo
print_success "==================================================================="
print_success "  INSTALACIÓN COMPLETADA (Sin DHCP - Solo IPs Estáticas)"
print_success "==================================================================="
echo
print_info "Configuración de red:"
print_info "  - Red Wi-Fi: $SSID"
print_info "  - Contraseña: $WIFI_PASSWORD"
print_info "  - Gateway (Raspberry Pi): $GATEWAY_IP"
print_info "  - Red IoT: $IOT_NETWORK"
echo
print_warning "IMPORTANTE: DHCP NO CONFIGURADO"
print_warning "Los dispositivos IoT deben configurarse manualmente con:"
print_warning "  - IP estática en rango: 192.168.50.10 - 192.168.50.254"
print_warning "  - Máscara de subred: 255.255.255.0"
print_warning "  - Gateway: 192.168.50.1"
print_warning "  - DNS: 192.168.50.1 (o 8.8.8.8)"
echo
print_info "Servicios instalados:"
print_info "  - hostapd: Access Point Wi-Fi"
print_info "  - nftables: Firewall y NAT"
print_info "  - sentinel-iot: API y Dashboard"
echo
print_info "Para iniciar los servicios:"
print_info "  sudo systemctl start hostapd"
print_info "  sudo systemctl start nftables"
print_info "  sudo systemctl start sentinel-iot"
echo
print_info "Para reiniciar el sistema (recomendado):"
print_info "  sudo reboot"
echo
print_info "Después del reinicio, accede al dashboard en:"
print_info "  http://$GATEWAY_IP:8000"
echo
print_info "Logs del servicio:"
print_info "  sudo journalctl -u sentinel-iot -f"
echo
print_success "==================================================================="
