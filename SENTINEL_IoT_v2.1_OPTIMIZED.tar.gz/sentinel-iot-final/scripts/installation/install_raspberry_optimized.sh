#!/bin/bash

################################################################################
# SENTINEL IoT - Instalador Optimizado para Raspberry Pi (IPs Estáticas)
# Versión: 2.1-OPTIMIZED
# Descripción: Instalación completa con backend, dashboard y control de Internet
################################################################################

set -e  # Salir si hay algún error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Variables de configuración
INSTALL_DIR="/opt/sentinel-iot"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
VENV_DIR="$INSTALL_DIR/venv"
LOG_FILE="/var/log/sentinel-install.log"

# Configuración de red
WAN_INTERFACE="wlan0"           # Interfaz para Internet
IOT_INTERFACE="wlan1"           # Interfaz para red IoT
IOT_IP="192.168.50.1"          # IP del gateway
IOT_NETWORK="192.168.50.0/24"  # Red IoT
WIFI_SSID="SENTINEL_IoT"       # Nombre de la red Wi-Fi
WIFI_PASSWORD="Raspberry"      # Contraseña Wi-Fi (CAMBIAR EN PRODUCCIÓN)

# Funciones de utilidad
print_header() {
    echo -e "${CYAN}========================================${NC}"
    echo -e "${CYAN}$1${NC}"
    echo -e "${CYAN}========================================${NC}"
}

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1" | tee -a "$LOG_FILE"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1" | tee -a "$LOG_FILE"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1" | tee -a "$LOG_FILE"
}

# Verificar que se ejecuta como root
if [[ $EUID -ne 0 ]]; then
   print_error "Este script debe ejecutarse como root (sudo)"
   exit 1
fi

print_header "SENTINEL IoT - Instalación Optimizada"
print_info "Iniciando instalación en Raspberry Pi..."
print_info "Configuración: IPs estáticas + Backend + Dashboard"
echo ""

# Paso 1: Actualizar sistema
print_header "Paso 1/10: Actualizando sistema"
print_info "Actualizando lista de paquetes..."
apt-get update -qq >> "$LOG_FILE" 2>&1
print_success "Sistema actualizado"
echo ""

# Paso 2: Instalar dependencias del sistema
print_header "Paso 2/10: Instalando dependencias"
print_info "Instalando paquetes necesarios..."
apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    hostapd \
    nftables \
    net-tools \
    iproute2 \
    wireless-tools \
    rfkill \
    >> "$LOG_FILE" 2>&1
print_success "Dependencias instaladas"
echo ""

# Paso 3: Desbloquear Wi-Fi
print_header "Paso 3/10: Configurando Wi-Fi"
print_info "Desbloqueando interfaces Wi-Fi..."
rfkill unblock wifi >> "$LOG_FILE" 2>&1 || true
rfkill unblock all >> "$LOG_FILE" 2>&1 || true
print_success "Wi-Fi desbloqueado"
echo ""

# Paso 4: Detener servicios conflictivos
print_header "Paso 4/10: Deteniendo servicios conflictivos"
print_info "Deteniendo wpa_supplicant y NetworkManager..."
systemctl stop wpa_supplicant >> "$LOG_FILE" 2>&1 || true
systemctl disable wpa_supplicant >> "$LOG_FILE" 2>&1 || true
systemctl stop NetworkManager >> "$LOG_FILE" 2>&1 || true
systemctl disable NetworkManager >> "$LOG_FILE" 2>&1 || true
systemctl stop dhcpcd >> "$LOG_FILE" 2>&1 || true
systemctl disable dhcpcd >> "$LOG_FILE" 2>&1 || true
print_success "Servicios conflictivos detenidos"
echo ""

# Paso 5: Configurar interfaces de red
print_header "Paso 5/10: Configurando interfaces de red"

# Configurar /etc/network/interfaces
print_info "Configurando /etc/network/interfaces..."
cat > /etc/network/interfaces << EOF
# Loopback
auto lo
iface lo inet loopback

# Interfaz WAN (Internet) - DHCP
allow-hotplug $WAN_INTERFACE
iface $WAN_INTERFACE inet dhcp
    wpa-conf /etc/wpa_supplicant/wpa_supplicant.conf

# Interfaz IoT - IP Estática
allow-hotplug $IOT_INTERFACE
iface $IOT_INTERFACE inet static
    address $IOT_IP
    netmask 255.255.255.0
    network 192.168.50.0
    broadcast 192.168.50.255
EOF

print_success "Interfaces configuradas"
echo ""

# Paso 6: Configurar hostapd
print_header "Paso 6/10: Configurando punto de acceso Wi-Fi"
print_info "Creando configuración de hostapd..."
cat > /etc/hostapd/hostapd.conf << EOF
# Configuración de SENTINEL IoT Access Point
interface=$IOT_INTERFACE
driver=nl80211
ssid=$WIFI_SSID
hw_mode=g
channel=7
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=$WIFI_PASSWORD
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
EOF

# Configurar ruta del archivo de configuración
echo 'DAEMON_CONF="/etc/hostapd/hostapd.conf"' > /etc/default/hostapd

systemctl unmask hostapd >> "$LOG_FILE" 2>&1 || true
systemctl enable hostapd >> "$LOG_FILE" 2>&1
print_success "hostapd configurado"
echo ""

# Paso 7: Habilitar IP forwarding
print_header "Paso 7/10: Habilitando enrutamiento"
print_info "Configurando IP forwarding..."
echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-sentinel-iot.conf
sysctl -p /etc/sysctl.d/99-sentinel-iot.conf >> "$LOG_FILE" 2>&1
print_success "IP forwarding habilitado"
echo ""

# Paso 8: Configurar nftables
print_header "Paso 8/10: Configurando firewall (nftables)"
print_info "Creando reglas de nftables..."

# Crear archivo de configuración de nftables
cat > /etc/nftables.conf << 'EOF'
#!/usr/sbin/nft -f

flush ruleset

# Tabla para filtrado
table inet filter {
    chain input {
        type filter hook input priority 0; policy accept;
        ct state invalid drop
        ct state {established, related} accept
        iif lo accept
        ip protocol icmp accept
        tcp dport 22 accept
        tcp dport 8000 accept
    }

    chain forward {
        type filter hook forward priority 0; policy accept;
        ct state invalid drop
        ct state {established, related} accept
        iifname "wlan1" oifname "wlan0" accept
        iifname "wlan0" oifname "wlan1" ct state {established, related} accept
    }

    chain output {
        type filter hook output priority 0; policy accept;
    }
}

# Tabla para NAT
table ip nat {
    chain prerouting {
        type nat hook prerouting priority -100;
    }

    chain postrouting {
        type nat hook postrouting priority 100;
        oifname "wlan0" masquerade
    }
}
EOF

systemctl enable nftables >> "$LOG_FILE" 2>&1
systemctl restart nftables >> "$LOG_FILE" 2>&1
print_success "nftables configurado"
echo ""

# Paso 9: Instalar backend de SENTINEL
print_header "Paso 9/10: Instalando backend de SENTINEL"

# Crear directorio de instalación
print_info "Creando directorio de instalación..."
mkdir -p "$INSTALL_DIR"

# Copiar archivos del proyecto
print_info "Copiando archivos del proyecto..."
if [ -d "$PROJECT_DIR/backend" ]; then
    cp -r "$PROJECT_DIR/backend" "$INSTALL_DIR/"
    print_success "Backend copiado"
else
    print_error "No se encontró el directorio backend"
    exit 1
fi

if [ -d "$PROJECT_DIR/frontend" ]; then
    cp -r "$PROJECT_DIR/frontend" "$INSTALL_DIR/"
    print_success "Frontend copiado"
else
    print_error "No se encontró el directorio frontend"
    exit 1
fi

# Crear entorno virtual de Python
print_info "Creando entorno virtual de Python..."
python3 -m venv "$VENV_DIR" >> "$LOG_FILE" 2>&1
print_success "Entorno virtual creado"

# Instalar dependencias de Python
print_info "Instalando dependencias de Python..."
"$VENV_DIR/bin/pip" install --upgrade pip >> "$LOG_FILE" 2>&1
"$VENV_DIR/bin/pip" install \
    fastapi \
    uvicorn \
    scapy \
    python-multipart \
    >> "$LOG_FILE" 2>&1
print_success "Dependencias de Python instaladas"

# Crear servicio systemd para el backend
print_info "Creando servicio systemd..."
cat > /etc/systemd/system/sentinel-backend.service << EOF
[Unit]
Description=SENTINEL IoT Backend Service
After=network.target nftables.service hostapd.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR/backend
Environment="PATH=$VENV_DIR/bin"
ExecStart=$VENV_DIR/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable sentinel-backend >> "$LOG_FILE" 2>&1
print_success "Backend configurado"
echo ""

# Paso 10: Iniciar servicios
print_header "Paso 10/10: Iniciando servicios"
print_info "Levantando interfaz IoT..."
ip link set $IOT_INTERFACE up >> "$LOG_FILE" 2>&1 || true
ip addr add $IOT_IP/24 dev $IOT_INTERFACE >> "$LOG_FILE" 2>&1 || true

print_info "Iniciando hostapd..."
systemctl restart hostapd >> "$LOG_FILE" 2>&1

print_info "Iniciando backend..."
systemctl restart sentinel-backend >> "$LOG_FILE" 2>&1

sleep 5

# Verificar servicios
print_info "Verificando servicios..."
if systemctl is-active --quiet hostapd; then
    print_success "hostapd está activo"
else
    print_warning "hostapd no está activo - verificar logs"
fi

if systemctl is-active --quiet sentinel-backend; then
    print_success "sentinel-backend está activo"
else
    print_warning "sentinel-backend no está activo - verificar logs"
fi

if systemctl is-active --quiet nftables; then
    print_success "nftables está activo"
else
    print_warning "nftables no está activo - verificar logs"
fi

echo ""

# Resumen final
print_header "¡Instalación Completada!"
echo ""
print_success "SENTINEL IoT ha sido instalado exitosamente"
echo ""
print_info "Configuración de red IoT:"
print_info "  Red Wi-Fi: $WIFI_SSID"
print_info "  Contraseña: $WIFI_PASSWORD"
print_info "  IP Gateway: $IOT_IP"
print_info "  Red: $IOT_NETWORK"
echo ""
print_info "Acceso al dashboard:"
print_info "  URL: http://$IOT_IP:8000"
echo ""
print_info "Dispositivos IoT deben configurarse con:"
print_info "  IP: 192.168.50.X (ej: 192.168.50.100)"
print_info "  Máscara: 255.255.255.0"
print_info "  Gateway: $IOT_IP"
print_info "  DNS: 8.8.8.8"
echo ""
print_info "Comandos útiles:"
print_info "  Ver logs del backend: sudo journalctl -u sentinel-backend -f"
print_info "  Ver estado de hostapd: sudo systemctl status hostapd"
print_info "  Ver reglas de firewall: sudo nft list ruleset"
echo ""
print_warning "IMPORTANTE: Cambia la contraseña Wi-Fi en /etc/hostapd/hostapd.conf"
print_warning "Luego ejecuta: sudo systemctl restart hostapd"
echo ""
print_success "¡SENTINEL IoT está listo para usar!"
print_info "Reinicia la Raspberry Pi para aplicar todos los cambios:"
print_info "  sudo reboot"
