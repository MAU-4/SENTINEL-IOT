#!/bin/bash
################################################################################
# SENTINEL IoT - Habilitar Acceso a Internet
# 
# Este script configura NAT para que los dispositivos conectados a la red
# SENTINEL_IoT puedan acceder a Internet
################################################################################

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║     SENTINEL IoT - Configuración de Acceso a Internet         ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Error: Este script debe ejecutarse como root"
    echo "   Usa: sudo bash $0"
    exit 1
fi

# Variables
IOT_INTERFACE="wlan1"
IOT_NETWORK="192.168.50.0/24"

# ============================================================================
# 1. HABILITAR IP FORWARDING
# ============================================================================
echo "[1/6] Habilitando IP forwarding..."

# Habilitar temporalmente
sysctl -w net.ipv4.ip_forward=1 > /dev/null

# Habilitar permanentemente
if ! grep -q "^net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
    echo "   ✓ IP forwarding habilitado permanentemente"
else
    echo "   ✓ IP forwarding ya estaba habilitado"
fi

# ============================================================================
# 2. DETECTAR INTERFAZ PRINCIPAL (CON INTERNET)
# ============================================================================
echo ""
echo "[2/6] Detectando interfaz con acceso a Internet..."

# Intentar detectar automáticamente
MAIN_IF=$(ip route | grep default | awk '{print $5}' | head -1)

if [ -z "$MAIN_IF" ]; then
    echo "   ⚠ No se detectó interfaz con ruta por defecto"
    echo ""
    echo "   Interfaces disponibles:"
    ip link show | grep -E "^[0-9]+" | awk '{print "   - " $2}' | sed 's/:$//'
    echo ""
    read -p "   Ingresa el nombre de la interfaz con Internet (ej: eth0, wlan0): " MAIN_IF
    
    if [ -z "$MAIN_IF" ]; then
        echo "   ❌ Error: Debes especificar una interfaz"
        exit 1
    fi
fi

# Verificar que la interfaz existe
if ! ip link show "$MAIN_IF" > /dev/null 2>&1; then
    echo "   ❌ Error: La interfaz $MAIN_IF no existe"
    exit 1
fi

echo "   ✓ Interfaz principal: $MAIN_IF"

# ============================================================================
# 3. CONFIGURAR NAT CON NFTABLES
# ============================================================================
echo ""
echo "[3/6] Configurando NAT con nftables..."

# Crear tabla nat si no existe
nft add table ip nat 2>/dev/null || true

# Crear chain postrouting si no existe
nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; } 2>/dev/null || true

# Limpiar reglas anteriores de la chain
nft flush chain ip nat postrouting 2>/dev/null || true

# Añadir regla de masquerade
nft add rule ip nat postrouting oifname "$MAIN_IF" masquerade

echo "   ✓ NAT configurado para interfaz $MAIN_IF"

# ============================================================================
# 4. CONFIGURAR FIREWALL PARA PERMITIR FORWARDING
# ============================================================================
echo ""
echo "[4/6] Configurando reglas de firewall..."

# Crear tabla filter si no existe
nft add table inet filter 2>/dev/null || true

# Crear chain forward si no existe
nft add chain inet filter forward { type filter hook forward priority 0 \; policy accept \; } 2>/dev/null || true

# Permitir forwarding desde red IoT
nft add rule inet filter forward iifname "$IOT_INTERFACE" oifname "$MAIN_IF" accept 2>/dev/null || true

# Permitir forwarding de respuestas
nft add rule inet filter forward iifname "$MAIN_IF" oifname "$IOT_INTERFACE" ct state related,established accept 2>/dev/null || true

echo "   ✓ Reglas de firewall configuradas"

# ============================================================================
# 5. GUARDAR CONFIGURACIÓN DE NFTABLES
# ============================================================================
echo ""
echo "[5/6] Guardando configuración de nftables..."

# Crear directorio si no existe
mkdir -p /etc/nftables

# Guardar configuración actual
nft list ruleset > /etc/nftables/sentinel-iot.nft

# Crear servicio para cargar reglas al inicio
cat > /etc/systemd/system/nftables-sentinel.service << 'EOF'
[Unit]
Description=SENTINEL IoT nftables rules
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/sbin/nft -f /etc/nftables/sentinel-iot.nft
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

# Habilitar servicio
systemctl daemon-reload
systemctl enable nftables-sentinel.service 2>/dev/null

echo "   ✓ Configuración guardada y persistente"

# ============================================================================
# 6. VERIFICAR CONFIGURACIÓN
# ============================================================================
echo ""
echo "[6/6] Verificando configuración..."
echo ""

# Verificar IP forwarding
IP_FORWARD=$(cat /proc/sys/net/ipv4/ip_forward)
if [ "$IP_FORWARD" = "1" ]; then
    echo "   ✓ IP Forwarding: HABILITADO"
else
    echo "   ✗ IP Forwarding: DESHABILITADO"
fi

# Verificar reglas de NAT
NAT_RULES=$(nft list chain ip nat postrouting 2>/dev/null | grep -c masquerade)
if [ "$NAT_RULES" -gt 0 ]; then
    echo "   ✓ Reglas de NAT: CONFIGURADAS"
else
    echo "   ✗ Reglas de NAT: NO ENCONTRADAS"
fi

# Verificar conectividad a Internet desde Raspberry Pi
echo ""
echo "   Probando conectividad a Internet desde Raspberry Pi..."
if ping -c 2 -W 3 8.8.8.8 > /dev/null 2>&1; then
    echo "   ✓ Internet: FUNCIONA"
else
    echo "   ⚠ Internet: NO DISPONIBLE (verifica tu conexión principal)"
fi

# ============================================================================
# RESUMEN
# ============================================================================
echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                  CONFIGURACIÓN COMPLETADA                      ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "Configuración aplicada:"
echo "  • Interfaz IoT: $IOT_INTERFACE"
echo "  • Red IoT: $IOT_NETWORK"
echo "  • Interfaz principal: $MAIN_IF"
echo "  • IP Forwarding: Habilitado"
echo "  • NAT: Configurado"
echo ""
echo "Pruebas desde dispositivos conectados a SENTINEL_IoT:"
echo "  1. ping 192.168.50.1     (gateway)"
echo "  2. ping 8.8.8.8          (Internet)"
echo "  3. ping google.com       (DNS)"
echo ""
echo "Ver reglas de NAT:"
echo "  sudo nft list ruleset | grep -A 5 nat"
echo ""
echo "Ver logs de tráfico:"
echo "  sudo tcpdump -i $IOT_INTERFACE -n"
echo ""

exit 0
