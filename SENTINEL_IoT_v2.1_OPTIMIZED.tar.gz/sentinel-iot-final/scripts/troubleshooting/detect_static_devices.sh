#!/bin/bash
################################################################################
# SENTINEL IoT - Detectar Dispositivos con IP Estática
# 
# Este script escanea la red para detectar dispositivos tanto con DHCP
# como con IP estática usando la tabla ARP
################################################################################

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║     SENTINEL IoT - Detección de Dispositivos                  ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Variables
IOT_NETWORK="192.168.50"
TEMP_FILE="/tmp/sentinel_devices.txt"
OUTPUT_FILE="/tmp/sentinel_devices_final.txt"

# Limpiar archivos temporales
> $TEMP_FILE
> $OUTPUT_FILE

echo "[1/3] Escaneando tabla ARP..."

# Escanear tabla ARP
ARP_COUNT=0
arp -n | grep -E "$IOT_NETWORK\." | while read line; do
    IP=$(echo $line | awk '{print $1}')
    MAC=$(echo $line | awk '{print $3}')
    INTERFACE=$(echo $line | awk '{print $5}')
    
    # Validar formato de MAC
    if [[ $MAC =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]]; then
        echo "$MAC|$IP|ARP|Unknown|$INTERFACE" >> $TEMP_FILE
        ARP_COUNT=$((ARP_COUNT + 1))
    fi
done

# Contar dispositivos en ARP (fuera del while por el subshell)
ARP_COUNT=$(grep -c "ARP" $TEMP_FILE 2>/dev/null || echo "0")
echo "   ✓ Dispositivos encontrados en ARP: $ARP_COUNT"

echo ""
echo "[2/3] Escaneando leases de DHCP..."

# Escanear leases de DHCP
DHCP_COUNT=0
if [ -f /var/lib/misc/dnsmasq.leases ]; then
    while read line; do
        TIMESTAMP=$(echo $line | awk '{print $1}')
        MAC=$(echo $line | awk '{print $2}')
        IP=$(echo $line | awk '{print $3}')
        HOSTNAME=$(echo $line | awk '{print $4}')
        
        # Validar formato de MAC
        if [[ $MAC =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]]; then
            echo "$MAC|$IP|DHCP|$HOSTNAME|wlan1" >> $TEMP_FILE
            DHCP_COUNT=$((DHCP_COUNT + 1))
        fi
    done < /var/lib/misc/dnsmasq.leases
    
    echo "   ✓ Dispositivos encontrados en DHCP: $DHCP_COUNT"
else
    echo "   ⚠ Archivo de leases no encontrado"
fi

echo ""
echo "[3/3] Consolidando resultados..."

# Consolidar y eliminar duplicados (priorizar DHCP sobre ARP)
# Primero añadir DHCP, luego ARP solo si no existe
declare -A seen_macs

while IFS='|' read -r mac ip source hostname interface; do
    if [ -z "${seen_macs[$mac]}" ]; then
        seen_macs[$mac]=1
        echo "$mac|$ip|$source|$hostname|$interface" >> $OUTPUT_FILE
    fi
done < <(grep "DHCP" $TEMP_FILE; grep "ARP" $TEMP_FILE)

TOTAL_COUNT=$(wc -l < $OUTPUT_FILE 2>/dev/null || echo "0")
echo "   ✓ Total de dispositivos únicos: $TOTAL_COUNT"

# ============================================================================
# MOSTRAR RESULTADOS
# ============================================================================
echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                  DISPOSITIVOS DETECTADOS                       ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

if [ "$TOTAL_COUNT" -eq 0 ]; then
    echo "⚠ No se detectaron dispositivos en la red $IOT_NETWORK.x"
    echo ""
    echo "Posibles causas:"
    echo "  • No hay dispositivos conectados"
    echo "  • Los servicios hostapd/dnsmasq no están corriendo"
    echo "  • La red IoT usa un rango diferente"
    echo ""
    exit 0
fi

# Encabezado de tabla
printf "%-18s %-15s %-8s %-20s %-10s\n" "MAC Address" "IP Address" "Source" "Hostname" "Interface"
printf "%-18s %-15s %-8s %-20s %-10s\n" "==================" "===============" "========" "====================" "=========="

# Mostrar dispositivos
while IFS='|' read -r mac ip source hostname interface; do
    # Truncar hostname si es muy largo
    hostname_short=$(echo "$hostname" | cut -c1-20)
    printf "%-18s %-15s %-8s %-20s %-10s\n" "$mac" "$ip" "$source" "$hostname_short" "$interface"
done < $OUTPUT_FILE

echo ""
echo "Leyenda:"
echo "  DHCP  = Dispositivo obtuvo IP automáticamente"
echo "  ARP   = Dispositivo con IP estática o detectado por ARP"
echo ""

# ============================================================================
# EXPORTAR A JSON (para integración con backend)
# ============================================================================
JSON_FILE="/tmp/sentinel_devices.json"
echo "[" > $JSON_FILE

FIRST=true
while IFS='|' read -r mac ip source hostname interface; do
    if [ "$FIRST" = true ]; then
        FIRST=false
    else
        echo "," >> $JSON_FILE
    fi
    
    cat >> $JSON_FILE << EOF
  {
    "mac_address": "$mac",
    "ip_address": "$ip",
    "detection_method": "$source",
    "hostname": "$hostname",
    "interface": "$interface",
    "timestamp": "$(date -Iseconds)"
  }
EOF
done < $OUTPUT_FILE

echo "" >> $JSON_FILE
echo "]" >> $JSON_FILE

echo "Datos exportados a: $JSON_FILE"
echo ""

# ============================================================================
# SUGERENCIAS
# ============================================================================
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                        SUGERENCIAS                             ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Contar dispositivos por tipo
ARP_ONLY=$(grep -c "ARP" $OUTPUT_FILE)
DHCP_ONLY=$(grep -c "DHCP" $OUTPUT_FILE)

if [ "$ARP_ONLY" -gt 0 ]; then
    echo "⚠ Hay $ARP_ONLY dispositivo(s) con IP estática (detectados por ARP)"
    echo ""
    echo "  Para que aparezcan en el dashboard de SENTINEL:"
    echo ""
    echo "  Opción 1 (Recomendada): Cambiar a DHCP"
    echo "    • En el dispositivo, cambiar configuración de IP estática a DHCP"
    echo "    • Reconectar a la red SENTINEL_IoT"
    echo ""
    echo "  Opción 2: Modificar backend para escanear ARP"
    echo "    • Editar: /opt/sentinel-iot/app/services/device_manager.py"
    echo "    • Añadir escaneo de tabla ARP además de leases"
    echo "    • Reiniciar: sudo systemctl restart sentinel-iot"
    echo ""
fi

if [ "$DHCP_ONLY" -gt 0 ]; then
    echo "✓ Hay $DHCP_ONLY dispositivo(s) con DHCP"
    echo "  Estos deberían aparecer automáticamente en el dashboard"
    echo ""
fi

echo "Comandos útiles:"
echo "  • Ver tabla ARP en tiempo real:"
echo "    watch -n 2 'arp -n | grep $IOT_NETWORK'"
echo ""
echo "  • Ver leases de DHCP en tiempo real:"
echo "    watch -n 2 'cat /var/lib/misc/dnsmasq.leases'"
echo ""
echo "  • Ejecutar este script automáticamente cada 30s:"
echo "    watch -n 30 'sudo bash $0'"
echo ""

exit 0
