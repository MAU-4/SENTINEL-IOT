# Guía de Instalación Completa - SENTINEL IoT v2.0

Esta guía proporciona instrucciones detalladas para instalar y configurar la plataforma de seguridad SENTINEL IoT v2.0 en un dispositivo Raspberry Pi.

## Tabla de Contenidos

1.  [Requisitos Previos](#1-requisitos-previos)
2.  [Preparación del Sistema Operativo](#2-preparación-del-sistema-operativo)
3.  [Instalación Automática](#3-instalación-automática)
4.  [Instalación Manual (Avanzado)](#4-instalación-manual-avanzado)
    *   [4.1. Actualizar Sistema e Instalar Dependencias](#41-actualizar-sistema-e-instalar-dependencias)
    *   [4.2. Configurar Interfaces de Red](#42-configurar-interfaces-de-red)
    *   [4.3. Configurar Punto de Acceso (hostapd)](#43-configurar-punto-de-acceso-hostapd)
    *   [4.4. Configurar DHCP/DNS (dnsmasq)](#44-configurar-dhcpdns-dnsmasq)
    *   [4.5. Configurar Firewall (nftables)](#45-configurar-firewall-nftables)
    *   [4.6. Habilitar IP Forwarding](#46-habilitar-ip-forwarding)
    *   [4.7. Instalar Aplicación Backend](#47-instalar-aplicación-backend)
    *   [4.8. Configurar Servicio Systemd](#48-configurar-servicio-systemd)
5.  [Post-Instalación](#5-post-instalación)
6.  [Solución de Problemas](#6-solución-de-problemas)

---

## 1. Requisitos Previos

### Hardware

| Componente | Requisito Mínimo | Recomendado |
| :--- | :--- | :--- |
| **Placa** | Raspberry Pi 3B+ | Raspberry Pi 4 Modelo B |
| **RAM** | 1 GB | 4 GB o superior |
| **Almacenamiento** | Tarjeta microSD 16 GB | Tarjeta microSD 32 GB (Clase 10/A1) o superior |
| **Adaptador Wi-Fi** | 1x Adaptador USB Wi-Fi | 1x Adaptador USB Wi-Fi de alta ganancia |
| **Red** | 1x Puerto Ethernet | 1x Puerto Ethernet Gigabit |
| **Alimentación** | Adaptador de corriente oficial | Adaptador de corriente oficial |

> **Nota:** El adaptador Wi-Fi USB es **esencial** para crear la red IoT aislada (`wlan1`), mientras que el Wi-Fi integrado (`wlan0`) puede usarse para otras tareas o deshabilitarse. La interfaz Ethernet (`eth0`) se usa para la conexión a la red principal (WAN).

### Software

*   **Sistema Operativo:** Raspberry Pi OS Lite (64-bit), versión "Bookworm" o superior.
*   **Acceso:** Conexión SSH al Raspberry Pi o acceso físico con teclado y monitor.
*   **Conectividad:** Conexión a Internet a través de la interfaz Ethernet.

---

## 2. Preparación del Sistema Operativo

1.  **Descargar Raspberry Pi Imager:** Obtén la herramienta oficial desde [raspberrypi.com](https://www.raspberrypi.com/software/).

2.  **Flashear el SO:**
    *   Abre Raspberry Pi Imager.
    *   Selecciona "Raspberry Pi OS (other)" -> "Raspberry Pi OS Lite (64-bit)".
    *   Elige tu tarjeta microSD.
    *   Haz clic en "Next" y luego en "Edit settings":
        *   En la pestaña **General**, define un `hostname` (ej. `sentinel`), y un usuario/contraseña.
        *   En la pestaña **Services**, habilita **SSH** y selecciona "Use password authentication".
        *   Guarda y escribe la imagen en la tarjeta.

3.  **Primer Arranque:**
    *   Inserta la tarjeta microSD en el Raspberry Pi.
    *   Conecta el cable Ethernet y el adaptador Wi-Fi USB.
    *   Enciende el dispositivo.
    *   Encuentra la dirección IP del Raspberry Pi en tu router o usando un escáner de red.

4.  **Conexión SSH:**
    *   Conéctate al dispositivo usando el cliente SSH de tu preferencia:
        ```bash
        ssh tu_usuario@<DIRECCION_IP_RASPBERRY>
        ```

---

## 3. Instalación Automática

El método más sencillo y recomendado es usar el script de instalación automatizada. Este se encargará de todo el proceso de configuración.

1.  **Descargar el script:**
    ```bash
    wget https://raw.githubusercontent.com/sentinel-iot/sentinel-v2/main/scripts/install.sh
    ```

2.  **Dar permisos de ejecución:**
    ```bash
    chmod +x install.sh
    ```

3.  **Ejecutar como root:**
    ```bash
    sudo ./install.sh
    ```

El script realizará los siguientes pasos:

*   Verificación de requisitos del sistema.
*   Actualización de paquetes del sistema operativo.
*   Instalación de todas las dependencias (hostapd, dnsmasq, nftables, Python, etc.).
*   Creación de la estructura de directorios necesaria.
*   Configuración de las interfaces de red (`eth0` y `wlan1`).
*   Configuración del punto de acceso Wi-Fi con una contraseña segura generada automáticamente.
*   Configuración del servidor DHCP y DNS para la red IoT.
*   Configuración del firewall con reglas base y NAT.
*   Habilitación de IP forwarding.
*   Instalación de la aplicación backend de SENTINEL en un entorno virtual de Python.
*   Creación y habilitación de un servicio `systemd` para que la aplicación se inicie automáticamente.
*   Generación de un certificado SSL autofirmado para HTTPS.
*   Inicio de todos los servicios.

Al finalizar, el script mostrará la **contraseña de la red Wi-Fi** y la **URL de acceso** a la interfaz web. Esta información también se guardará en `/root/sentinel-info.txt`.

---

## 4. Instalación Manual (Avanzado)

Sigue estos pasos si prefieres realizar la instalación manualmente para entender cada componente.

### 4.1. Actualizar Sistema e Instalar Dependencias

```bash
# Actualizar sistema
sudo apt-get update && sudo apt-get upgrade -y

# Instalar herramientas de red
sudo apt-get install -y hostapd dnsmasq nftables bridge-utils net-tools iptables tcpdump nmap wireless-tools iw

# Instalar Python y herramientas de desarrollo
sudo apt-get install -y python3 python3-pip python3-venv python3-dev git curl wget
```

### 4.2. Configurar Interfaces de Red

Asigna una IP estática a la interfaz Wi-Fi USB (`wlan1`), que actuará como gateway para la red IoT.

```bash
sudo nano /etc/network/interfaces.d/wlan1
```

Añade el siguiente contenido:

```
auto wlan1
iface wlan1 inet static
    address 192.168.100.1
    netmask 255.255.255.0
```

### 4.3. Configurar Punto de Acceso (hostapd)

Crea el archivo de configuración para el punto de acceso.

```bash
sudo nano /etc/hostapd/hostapd.conf
```

Añade el siguiente contenido. **Recuerda cambiar `TU_CONTRASEÑA_WIFI` por una contraseña segura.**

```
interface=wlan1
driver=nl80211
ssid=SENTINEL_IoT
hw_mode=g
channel=6
country_code=US
wpa=2
wpa_passphrase=TU_CONTRASEÑA_WIFI
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
```

### 4.4. Configurar DHCP/DNS (dnsmasq)

Configura el servidor que asignará IPs a los dispositivos IoT.

```bash
sudo mv /etc/dnsmasq.conf /etc/dnsmasq.conf.backup
sudo nano /etc/dnsmasq.conf
```

Añade:

```
interface=wlan1
bind-interfaces
dhcp-range=192.168.100.10,192.168.100.250,255.255.255.0,24h
dhcp-option=3,192.168.100.1
dhcp-option=6,192.168.100.1
domain=sentinel.local
local=/sentinel.local/
```

### 4.5. Configurar Firewall (nftables)

Crea el archivo de reglas del firewall.

```bash
sudo nano /etc/nftables.conf
```

Añade el conjunto de reglas base:

```nftables
#!/usr/sbin/nft -f

flush ruleset

table inet sentinel {
    chain input { type filter hook input priority 0; policy drop; }
    chain forward { type filter hook forward priority 0; policy drop; }
    chain output { type filter hook output priority 0; policy accept; }
}

table ip nat {
    chain postrouting {
        type nat hook postrouting priority 100;
        oif eth0 masquerade
    }
}
```

### 4.6. Habilitar IP Forwarding

Permite que el Raspberry Pi enrute paquetes entre la red IoT y la red principal.

```bash
sudo sh -c "echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf"
sudo sysctl -p
```

### 4.7. Instalar Aplicación Backend

Clona el repositorio y configura el entorno de Python.

```bash
# Clonar repositorio (o copiar archivos)
sudo git clone https://github.com/sentinel-iot/sentinel-v2.git /opt/sentinel-iot
cd /opt/sentinel-iot

# Crear entorno virtual
sudo python3 -m venv venv

# Activar entorno (temporalmente para instalar)
source venv/bin/activate

# Instalar dependencias
pip install -r backend/requirements.txt

# Desactivar entorno
deactivate
```

### 4.8. Configurar Servicio Systemd

Crea un servicio para que la API de SENTINEL se ejecute automáticamente.

```bash
sudo nano /etc/systemd/system/sentinel-iot.service
```

Añade el siguiente contenido:

```ini
[Unit]
Description=SENTINEL IoT v2.0 API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/sentinel-iot/backend
ExecStart=/opt/sentinel-iot/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

Finalmente, habilita e inicia todos los servicios:

```bash
sudo systemctl unmask hostapd
sudo systemctl enable hostapd
sudo systemctl enable dnsmasq
sudo systemctl enable nftables
sudo systemctl enable sentinel-iot

sudo systemctl restart hostapd
sudo systemctl restart dnsmasq
sudo systemctl restart nftables
sudo systemctl start sentinel-iot
```

---

## 5. Post-Instalación

1.  **Acceder a la Interfaz Web:**
    *   Abre tu navegador y ve a `http://<DIRECCION_IP_RASPBERRY>:8000`.
    *   (Si usaste el script automático, será `https://<IP>` y deberás aceptar el certificado autofirmado).

2.  **Conectar un Dispositivo IoT:**
    *   En tu smartphone o dispositivo IoT, busca redes Wi-Fi y conéctate a **SENTINEL_IoT** usando la contraseña que configuraste (o la que generó el script).

3.  **Verificar en el Dashboard:**
    *   El nuevo dispositivo debería aparecer en el dashboard de SENTINEL, probablemente como "Nuevo" y "Desconocido".
    *   Desde aquí, puedes clasificarlo, asignarle un perfil de seguridad y crear reglas de firewall específicas.

---

## 6. Solución de Problemas

*   **El punto de acceso `SENTINEL_IoT` no aparece:**
    *   Verifica que el adaptador Wi-Fi USB esté bien conectado.
    *   Asegúrate de que `wlan1` es el nombre correcto de la interfaz (`ip a`).
    *   Revisa los logs de hostapd: `sudo journalctl -u hostapd`.

*   **No se puede conectar a la red Wi-Fi:**
    *   Verifica que la contraseña sea correcta.
    *   Revisa los logs de hostapd para ver mensajes de error de autenticación.

*   **El dispositivo se conecta pero no tiene internet:**
    *   Verifica que el servicio `dnsmasq` esté activo: `sudo systemctl status dnsmasq`.
    *   Asegúrate de que IP forwarding esté habilitado: `cat /proc/sys/net/ipv4/ip_forward` (debe ser `1`).
    *   Revisa las reglas de `nftables` (`sudo nft list ruleset`) para asegurarte de que el tráfico FORWARD y NAT esté permitido.

*   **La interfaz web no carga:**
    *   Verifica que el servicio `sentinel-iot` esté activo: `sudo systemctl status sentinel-iot`.
    *   Revisa los logs de la aplicación: `sudo journalctl -u sentinel-iot -f`.

Para más ayuda, abre un *issue* en el [repositorio de GitHub](https://github.com/sentinel-iot/sentinel-v2/issues).
