# Referencia de API - SENTINEL IoT v2.0

Esta documentación detalla los endpoints de la API RESTful de SENTINEL IoT v2.0. La API permite la gestión programática de dispositivos, reglas de firewall, y el monitoreo del sistema.

**URL Base:** `http://<IP_SENTINEL>:8000/api/v1`
**Autenticación:** Todos los endpoints (excepto `/health`) requieren un `Bearer Token` en la cabecera `Authorization`.

## Tabla de Contenidos

1.  [Autenticación](#1-autenticación)
2.  [Sistema](#2-sistema)
3.  [Dispositivos](#3-dispositivos)
4.  [Firewall](#4-firewall)
5.  [Alertas](#5-alertas)
6.  [Modelos de Datos](#6-modelos-de-datos)

---

## 1. Autenticación

### `POST /auth/token`

Obtiene un token de acceso JWT a partir de credenciales de usuario.

*   **Request Body:** `application/x-www-form-urlencoded`
    *   `username` (string, required): Nombre de usuario.
    *   `password` (string, required): Contraseña.
*   **Success Response (200):**
    ```json
    {
      "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "token_type": "bearer",
      "refresh_token": "azJ3aG9kbmFzZGtqYXNk..."
    }
    ```
*   **Error Response (401):** Si las credenciales son incorrectas.

### `POST /auth/refresh`

Obtiene un nuevo `access_token` usando un `refresh_token`.

*   **Request Body:**
    ```json
    {
      "refresh_token": "azJ3aG9kbmFzZGtqYXNk..."
    }
    ```
*   **Success Response (200):** Similar a `/auth/token`.

---

## 2. Sistema

### `GET /health`

Verifica el estado de salud del sistema. No requiere autenticación.

*   **Success Response (200):**
    ```json
    {
      "status": "healthy",
      "firewall": true,
      "database": "connected",
      "timestamp": "2025-11-06T12:00:00Z"
    }
    ```

### `GET /stats`

Obtiene estadísticas generales del sistema.

*   **Success Response (200):**
    ```json
    {
      "firewall": {
        "total_rules": 52,
        "chains": ["input", "forward", "output"]
      },
      "devices": {
        "total_devices": 15,
        "online_devices": 12,
        "new_devices": 1,
        "device_types": {
          "camera": 5,
          "sensor": 8,
          "unknown": 2
        }
      },
      "timestamp": "2025-11-06T12:00:00Z"
    }
    ```

---

## 3. Dispositivos

### `GET /devices`

Lista todos los dispositivos detectados.

*   **Query Parameters:**
    *   `online_only` (boolean, optional): Si es `true`, devuelve solo los dispositivos actualmente en línea.
    *   `sort_by` (string, optional): Campo por el cual ordenar (`name`, `last_seen`).
    *   `order` (string, optional): `asc` o `desc`.
*   **Success Response (200):**
    ```json
    {
      "total": 15,
      "devices": [
        {
          "id": 1,
          "mac_address": "B8:27:EB:XX:XX:XX",
          "ip_address": "192.168.100.15",
          "name": "Cámara del Salón",
          "device_type": "camera",
          "status": "online",
          "is_trusted": true,
          "last_seen": "2025-11-06T11:58:00Z"
        }
      ]
    }
    ```

### `GET /devices/{device_id}`

Obtiene los detalles de un dispositivo específico.

*   **Path Parameters:**
    *   `device_id` (integer, required): El ID del dispositivo.
*   **Success Response (200):** Devuelve un objeto `Device` (ver [Modelos de Datos](#6-modelos-de-datos)).
*   **Error Response (404):** Si el dispositivo no existe.

### `PUT /devices/{device_id}`

Actualiza la información de un dispositivo.

*   **Path Parameters:**
    *   `device_id` (integer, required): El ID del dispositivo.
*   **Request Body:**
    ```json
    {
      "name": "Cámara del Salón (Actualizado)",
      "device_type": "camera",
      "is_trusted": true,
      "security_profile": "moderate"
    }
    ```
*   **Success Response (200):** Devuelve el objeto `Device` actualizado.

### `POST /devices/{device_id}/action`

Ejecuta una acción sobre un dispositivo.

*   **Path Parameters:**
    *   `device_id` (integer, required): El ID del dispositivo.
*   **Request Body:**
    ```json
    {
      "action": "block" 
    }
    ```
    *   Acciones posibles: `block`, `unblock`, `quarantine`, `scan`.
*   **Success Response (200):**
    ```json
    {
      "status": "success",
      "message": "Device 1 has been blocked"
    }
    ```

---

## 4. Firewall

### `GET /firewall/rules`

Lista las reglas del firewall.

*   **Query Parameters:**
    *   `chain` (string, optional): Filtra por chain (`input`, `forward`).
    *   `device_id` (integer, optional): Filtra por reglas aplicadas a un dispositivo.
*   **Success Response (200):**
    ```json
    {
      "total": 52,
      "rules": [
        {
          "id": 101,
          "name": "Allow-Cloud-Camera",
          "direction": "forward",
          "source_ip": "192.168.100.15",
          "dest_ip": "34.22.11.88",
          "protocol": "tcp",
          "dest_port": 443,
          "action": "accept",
          "priority": 100
        }
      ]
    }
    ```

### `POST /firewall/rules`

Crea una nueva regla de firewall.

*   **Request Body:** Un objeto `FirewallRule` (ver [Modelos de Datos](#6-modelos-de-datos)) sin el `id`.
*   **Success Response (201):** Devuelve la regla creada con su nuevo `id`.
*   **Error Response (400):** Si la definición de la regla es inválida.

### `PUT /firewall/rules/{rule_id}`

Actualiza una regla existente.

*   **Path Parameters:**
    *   `rule_id` (integer, required): El ID de la regla.
*   **Request Body:** Un objeto `FirewallRule`.
*   **Success Response (200):** Devuelve la regla actualizada.

### `DELETE /firewall/rules/{rule_id}`

Elimina una regla de firewall.

*   **Path Parameters:**
    *   `rule_id` (integer, required): El ID de la regla.
*   **Success Response (204):** No Content.

### `GET /firewall/profiles`

Lista los perfiles de seguridad predefinidos (`strict`, `moderate`, `permissive`).

---

## 5. Alertas

### `GET /alerts`

Obtiene una lista de eventos y alertas de seguridad.

*   **Query Parameters:**
    *   `severity` (string, optional): Filtra por severidad (`info`, `warning`, `critical`).
    *   `limit` (integer, optional): Número de resultados a devolver (default: 50).
    *   `start_date` / `end_date` (string, optional): Rango de fechas en formato ISO 8601.
*   **Success Response (200):**
    ```json
    {
      "total": 5,
      "alerts": [
        {
          "id": 1,
          "timestamp": "2025-11-06T10:30:00Z",
          "severity": "critical",
          "type": "anomaly_detected",
          "description": "High anomaly score (0.92) detected for device Camera-Living-Room (B8:27:EB:XX:XX:XX)",
          "device_id": 1,
          "acknowledged": false
        }
      ]
    }
    ```

### `POST /alerts/{alert_id}/ack`

Marca una alerta como reconocida (revisada por un administrador).

*   **Path Parameters:**
    *   `alert_id` (integer, required): El ID de la alerta.
*   **Success Response (200):**
    ```json
    {
      "status": "success",
      "message": "Alert 1 acknowledged"
    }
    ```

---

## 6. Modelos de Datos

### Objeto `Device`

| Campo | Tipo | Descripción |
| :--- | :--- | :--- |
| `id` | integer | ID único del dispositivo. |
| `mac_address` | string | Dirección MAC. |
| `ip_address` | string | Última dirección IP conocida. |
| `name` | string | Nombre asignado por el usuario. |
| `device_type` | string (enum) | Tipo de dispositivo (`camera`, `sensor`, etc.). |
| `status` | string (enum) | Estado actual (`online`, `offline`, `blocked`). |
| `is_trusted` | boolean | Si el dispositivo ha sido clasificado y es de confianza. |
| `security_profile` | string (enum) | Perfil de seguridad aplicado (`strict`, `moderate`, etc.). |
| `manufacturer` | string | Fabricante detectado. |
| `first_seen` | string (ISO 8601) | Fecha de la primera conexión. |
| `last_seen` | string (ISO 8601) | Fecha de la última conexión. |
| `anomaly_score` | float | Puntuación de anomalía (0.0 a 1.0). |

### Objeto `FirewallRule`

| Campo | Tipo | Descripción |
| :--- | :--- | :--- |
| `id` | integer | ID único de la regla. |
| `name` | string | Nombre descriptivo. |
| `direction` | string (enum) | `input` o `forward`. |
| `source_ip` | string | IP o CIDR de origen. |
| `dest_ip` | string | IP o CIDR de destino. |
| `protocol` | string (enum) | `tcp`, `udp`, `icmp`, `all`. |
| `source_port` | integer | Puerto de origen. |
| `dest_port` | integer | Puerto de destino.|
| `action` | string (enum) | `accept`, `drop`, `reject`. |
| `enabled` | boolean | Si la regla está activa. |
| `priority` | integer | Orden de ejecución (menor a mayor). |
| `comment` | string | Comentario opcional. |
