"""
Modelos de dispositivos IoT
"""
from datetime import datetime
from typing import Optional
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Float, JSON, Enum as SQLEnum
from sqlalchemy.orm import relationship
import enum

from ..core.database import Base


class DeviceType(str, enum.Enum):
    """Tipos de dispositivos IoT"""
    CAMERA = "camera"
    THERMOSTAT = "thermostat"
    LIGHT = "light"
    LOCK = "lock"
    SENSOR = "sensor"
    SPEAKER = "speaker"
    TV = "tv"
    APPLIANCE = "appliance"
    HUB = "hub"
    SWITCH = "switch"
    PLUG = "plug"
    VACUUM = "vacuum"
    DOORBELL = "doorbell"
    GARAGE = "garage"
    UNKNOWN = "unknown"


class DeviceStatus(str, enum.Enum):
    """Estados del dispositivo"""
    ONLINE = "online"
    OFFLINE = "offline"
    BLOCKED = "blocked"
    QUARANTINE = "quarantine"
    UNKNOWN = "unknown"


class SecurityProfile(str, enum.Enum):
    """Perfiles de seguridad predefinidos"""
    STRICT = "strict"  # Solo comunicación local
    MODERATE = "moderate"  # Comunicación limitada a Internet
    PERMISSIVE = "permissive"  # Comunicación completa
    CUSTOM = "custom"  # Reglas personalizadas


class Device(Base):
    """Modelo de dispositivo IoT"""
    __tablename__ = "devices"
    
    # Identificación
    id = Column(Integer, primary_key=True, index=True)
    mac_address = Column(String(17), unique=True, index=True, nullable=False)
    ip_address = Column(String(15), nullable=True)
    hostname = Column(String(255), nullable=True)
    
    # Clasificación
    name = Column(String(255), nullable=False)
    device_type = Column(SQLEnum(DeviceType), default=DeviceType.UNKNOWN)
    manufacturer = Column(String(255), nullable=True)
    model = Column(String(255), nullable=True)
    firmware_version = Column(String(100), nullable=True)
    
    # Estado
    status = Column(SQLEnum(DeviceStatus), default=DeviceStatus.UNKNOWN)
    is_trusted = Column(Boolean, default=False)
    security_profile = Column(SQLEnum(SecurityProfile), default=SecurityProfile.MODERATE)
    
    # Conectividad
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)
    last_ip_change = Column(DateTime, nullable=True)
    connection_count = Column(Integer, default=0)
    
    # Estadísticas de tráfico
    bytes_sent = Column(Integer, default=0)
    bytes_received = Column(Integer, default=0)
    packets_sent = Column(Integer, default=0)
    packets_received = Column(Integer, default=0)
    
    # Machine Learning
    ml_confidence = Column(Float, nullable=True)  # Confianza en clasificación
    ml_features = Column(JSON, nullable=True)  # Features extraídas
    anomaly_score = Column(Float, default=0.0)  # Score de anomalía
    
    # Metadatos
    notes = Column(String(1000), nullable=True)
    tags = Column(JSON, default=list)  # Lista de tags
    custom_data = Column(JSON, default=dict)  # Datos personalizados
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relaciones
    # rules = relationship("FirewallRule", back_populates="device")
    # events = relationship("SecurityEvent", back_populates="device")
    # metrics = relationship("DeviceMetric", back_populates="device")
    
    def __repr__(self):
        return f"<Device {self.name} ({self.mac_address})>"
    
    def to_dict(self):
        """Convierte el modelo a diccionario"""
        return {
            "id": self.id,
            "mac_address": self.mac_address,
            "ip_address": self.ip_address,
            "hostname": self.hostname,
            "name": self.name,
            "device_type": self.device_type.value if self.device_type else None,
            "manufacturer": self.manufacturer,
            "model": self.model,
            "firmware_version": self.firmware_version,
            "status": self.status.value if self.status else None,
            "is_trusted": self.is_trusted,
            "security_profile": self.security_profile.value if self.security_profile else None,
            "first_seen": self.first_seen.isoformat() if self.first_seen else None,
            "last_seen": self.last_seen.isoformat() if self.last_seen else None,
            "connection_count": self.connection_count,
            "bytes_sent": self.bytes_sent,
            "bytes_received": self.bytes_received,
            "ml_confidence": self.ml_confidence,
            "anomaly_score": self.anomaly_score,
            "notes": self.notes,
            "tags": self.tags,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
    
    @property
    def is_online(self) -> bool:
        """Verifica si el dispositivo está online"""
        if not self.last_seen:
            return False
        delta = datetime.utcnow() - self.last_seen
        return delta.total_seconds() < 300  # 5 minutos
    
    @property
    def total_traffic(self) -> int:
        """Tráfico total en bytes"""
        return self.bytes_sent + self.bytes_received
    
    @property
    def is_suspicious(self) -> bool:
        """Verifica si el dispositivo es sospechoso"""
        return self.anomaly_score > 0.7 or self.status == DeviceStatus.QUARANTINE
