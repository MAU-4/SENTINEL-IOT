#!/bin/bash
#
# SENTINEL IoT v2.0 - Script de Instalación Corregido
# 
# Este script instala y configura SENTINEL IoT en Raspberry Pi
#

set -e  # Salir si hay error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables
INSTALL_DIR="/opt/sentinel-iot"
DATA_DIR="/var/lib/sentinel-iot"
LOG_DIR="/var/log/sentinel-iot"
BACKUP_DIR="$DATA_DIR/backups"
IOT_INTERFACE="wlan1"
MAIN_INTERFACE="eth0"
IOT_NETWORK="192.168.100.0/24"
IOT_GATEWAY="192.168.100.1"

# Funciones de utilidad
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then
    log_error "Este script debe ejecutarse como root (sudo)"
    exit 1
fi

# Banner
echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║       SENTINEL IoT v2.0 - Instalación (Corregida)        ║"
echo "║                                                           ║"
echo "║     Plataforma Integral de Seguridad IoT con ML          ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Paso 1: Verificar requisitos
log_info "Verificando requisitos del sistema..."

# Verificar interfaces de red
if ! ip link show $MAIN_INTERFACE > /dev/null 2>&1; then
    log_error "Interfaz principal $MAIN_INTERFACE no encontrada"
    exit 1
fi

if ! ip link show $IOT_INTERFACE > /dev/null 2>&1; then
    log_warning "Interfaz IoT $IOT_INTERFACE no encontrada"
    log_warning "Continuando de todos modos (puede ser un entorno de prueba)"
fi

log_success "Requisitos verificados"

# Paso 2: Actualizar sistema
log_info "Actualizando sistema (esto puede tomar varios minutos)..."
apt-get update -qq
log_success "Sistema actualizado"

# Paso 3: Instalar dependencias
log_info "Instalando dependencias..."

# Herramientas de red (solo si no están instaladas)
apt-get install -y -qq \
    hostapd \
    dnsmasq \
    nftables \
    net-tools

# Python y librerías
apt-get install -y -qq \
    python3 \
    python3-pip \
    python3-venv

log_success "Dependencias instaladas"

# Paso 4: Crear estructura de directorios
log_info "Creando estructura de directorios..."

mkdir -p $INSTALL_DIR
mkdir -p $DATA_DIR/{logs,backups,models,reports}
mkdir -p $LOG_DIR
mkdir -p /etc/sentinel-iot

# Cambiar permisos
chmod 755 $INSTALL_DIR
chmod 755 $DATA_DIR
chmod 755 $LOG_DIR

log_success "Directorios creados"

# Paso 5: Copiar archivos de la aplicación
log_info "Copiando archivos de la aplicación..."

# Obtener el directorio donde está el script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

if [ -d "$PROJECT_DIR/backend" ]; then
    cp -r "$PROJECT_DIR/backend/"* $INSTALL_DIR/
    log_success "Archivos del backend copiados desde $PROJECT_DIR"
else
    log_error "No se encontró el directorio backend en $PROJECT_DIR"
    log_info "Creando estructura básica..."
    
    mkdir -p $INSTALL_DIR/app/{core,models,services,ml,api}
    touch $INSTALL_DIR/app/__init__.py
    touch $INSTALL_DIR/app/core/__init__.py
    touch $INSTALL_DIR/app/models/__init__.py
    touch $INSTALL_DIR/app/services/__init__.py
    touch $INSTALL_DIR/app/ml/__init__.py
    touch $INSTALL_DIR/app/api/__init__.py
fi

# Copiar interfaz web
if [ -d "$PROJECT_DIR/frontend/public" ]; then
    log_info "Copiando interfaz web..."
    mkdir -p $INSTALL_DIR/frontend/public
    cp -r "$PROJECT_DIR/frontend/public/"* $INSTALL_DIR/frontend/public/
    chmod -R 755 $INSTALL_DIR/frontend
    log_success "Interfaz web copiada"
else
    log_warning "No se encontró el directorio frontend/public"
    log_warning "La interfaz web no estará disponible, pero la API funcionará"
fi

# Paso 6: Crear entorno virtual e instalar dependencias Python
log_info "Configurando entorno Python..."

cd $INSTALL_DIR
python3 -m venv venv

# Activar entorno y instalar dependencias
source venv/bin/activate

# Instalar dependencias básicas
pip install --upgrade pip -q
pip install fastapi uvicorn[standard] sqlalchemy pydantic pydantic-settings -q

log_success "Entorno Python configurado"

# Paso 7: Crear archivo de configuración
log_info "Creando archivo de configuración..."

cat > /etc/sentinel-iot/config.env << EOF
# SENTINEL IoT Configuration
PROJECT_NAME="SENTINEL IoT v2.0"
DEBUG=false
LOG_LEVEL=INFO
DATABASE_URL=sqlite:///$DATA_DIR/sentinel.db
IOT_INTERFACE=$IOT_INTERFACE
IOT_GATEWAY=$IOT_GATEWAY
EOF

log_success "Configuración creada"

# Paso 8: Configurar interfaces de red (solo si existe wlan1)
if ip link show $IOT_INTERFACE > /dev/null 2>&1; then
    log_info "Configurando interfaces de red..."
    
    cat > /etc/network/interfaces.d/wlan1 << EOF
auto $IOT_INTERFACE
iface $IOT_INTERFACE inet static
    address $IOT_GATEWAY
    netmask 255.255.255.0
EOF
    
    # Configurar wlan1 inmediatamente
    ip addr flush dev $IOT_INTERFACE 2>/dev/null || true
    ip addr add $IOT_GATEWAY/24 dev $IOT_INTERFACE 2>/dev/null || true
    ip link set $IOT_INTERFACE up 2>/dev/null || true
    
    log_success "Interfaces configuradas"
else
    log_warning "Saltando configuración de red (interfaz $IOT_INTERFACE no disponible)"
fi

# Paso 9: Configurar hostapd (solo si existe wlan1)
if ip link show $IOT_INTERFACE > /dev/null 2>&1; then
    log_info "Configurando punto de acceso Wi-Fi..."
    
    WIFI_PASSWORD=$(openssl rand -base64 16 | tr -d "=+/" | cut -c1-16)
    
    cat > /etc/hostapd/hostapd.conf << EOF
interface=$IOT_INTERFACE
driver=nl80211
ssid=SENTINEL_IoT
hw_mode=g
channel=6
country_code=US
wpa=2
wpa_passphrase=$WIFI_PASSWORD
wpa_key_mgmt=WPA-PSK
wpa_pairwise=CCMP
rsn_pairwise=CCMP
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wmm_enabled=1
EOF
    
    systemctl unmask hostapd 2>/dev/null || true
    systemctl enable hostapd 2>/dev/null || true
    
    log_success "Punto de acceso configurado"
    log_warning "Contraseña Wi-Fi: $WIFI_PASSWORD"
else
    log_warning "Saltando configuración de hostapd"
fi

# Paso 10: Configurar dnsmasq (solo si existe wlan1)
if ip link show $IOT_INTERFACE > /dev/null 2>&1; then
    log_info "Configurando DHCP y DNS..."
    
    if [ -f /etc/dnsmasq.conf ]; then
        mv /etc/dnsmasq.conf /etc/dnsmasq.conf.backup 2>/dev/null || true
    fi
    
    cat > /etc/dnsmasq.conf << EOF
interface=$IOT_INTERFACE
bind-interfaces
dhcp-range=192.168.100.10,192.168.100.250,255.255.255.0,24h
dhcp-option=3,$IOT_GATEWAY
dhcp-option=6,$IOT_GATEWAY
domain=sentinel.local
local=/sentinel.local/
log-facility=$LOG_DIR/dnsmasq.log
EOF
    
    systemctl enable dnsmasq 2>/dev/null || true
    
    log_success "DHCP y DNS configurados"
else
    log_warning "Saltando configuración de dnsmasq"
fi

# Paso 11: Configurar nftables
log_info "Configurando firewall..."

cat > /etc/nftables.conf << 'EOF'
#!/usr/sbin/nft -f

flush ruleset

table inet sentinel {
    chain input {
        type filter hook input priority 0; policy drop;
        
        iif lo accept
        ct state established,related accept
        tcp dport 22 accept
        tcp dport 8000 accept
    }
    
    chain forward {
        type filter hook forward priority 0; policy drop;
        ct state established,related accept
    }
    
    chain output {
        type filter hook output priority 0; policy accept;
    }
}
EOF

nft -f /etc/nftables.conf 2>/dev/null || log_warning "No se pudo aplicar configuración de nftables"
systemctl enable nftables 2>/dev/null || true

log_success "Firewall configurado"

# Paso 12: Habilitar IP forwarding
log_info "Habilitando IP forwarding..."

if ! grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
fi
sysctl -p > /dev/null 2>&1 || true

log_success "IP forwarding habilitado"

# Paso 13: Crear servicio systemd
log_info "Creando servicio systemd..."

cat > /etc/systemd/system/sentinel-iot.service << EOF
[Unit]
Description=SENTINEL IoT v2.0 API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
EnvironmentFile=/etc/sentinel-iot/config.env
ExecStart=$INSTALL_DIR/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable sentinel-iot

log_success "Servicio creado"

# Paso 14: Iniciar servicios
log_info "Iniciando servicios..."

# Reiniciar servicios de red si existen
if systemctl list-unit-files | grep -q hostapd; then
    systemctl restart hostapd 2>/dev/null || log_warning "No se pudo iniciar hostapd"
fi

if systemctl list-unit-files | grep -q dnsmasq; then
    systemctl restart dnsmasq 2>/dev/null || log_warning "No se pudo iniciar dnsmasq"
fi

systemctl restart nftables 2>/dev/null || log_warning "No se pudo iniciar nftables"

# Iniciar servicio de SENTINEL
systemctl start sentinel-iot

# Esperar un momento para que el servicio inicie
sleep 3

log_success "Servicios iniciados"

# Paso 15: Verificar instalación
log_info "Verificando instalación..."

echo ""
if systemctl is-active --quiet hostapd; then
    log_success "hostapd: activo"
elif systemctl list-unit-files | grep -q hostapd; then
    log_warning "hostapd: inactivo"
else
    log_info "hostapd: no instalado (normal en entorno de prueba)"
fi

if systemctl is-active --quiet dnsmasq; then
    log_success "dnsmasq: activo"
elif systemctl list-unit-files | grep -q dnsmasq; then
    log_warning "dnsmasq: inactivo"
else
    log_info "dnsmasq: no instalado (normal en entorno de prueba)"
fi

if systemctl is-active --quiet sentinel-iot; then
    log_success "sentinel-iot: activo ✓"
else
    log_error "sentinel-iot: inactivo ✗"
    log_info "Mostrando logs del servicio:"
    journalctl -u sentinel-iot -n 20 --no-pager
    echo ""
    log_info "Para ver logs en tiempo real: journalctl -u sentinel-iot -f"
fi

# Paso 16: Mostrar información de acceso
echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}║          Instalación completada                           ║${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Información de acceso:${NC}"
echo ""

if [ -n "$WIFI_PASSWORD" ]; then
    echo -e "  ${YELLOW}Red Wi-Fi IoT:${NC}"
    echo -e "    SSID: ${GREEN}SENTINEL_IoT${NC}"
    echo -e "    Contraseña: ${GREEN}$WIFI_PASSWORD${NC}"
    echo ""
fi

echo -e "  ${YELLOW}Interfaz Web:${NC}"
echo -e "    URL: ${GREEN}http://$(hostname -I | awk '{print $1}'):8000${NC}"
echo -e "    Dashboard: ${GREEN}http://$(hostname -I | awk '{print $1}'):8000${NC}"
echo ""
echo -e "  ${YELLOW}API:${NC}"
echo -e "    Documentación: ${GREEN}http://$(hostname -I | awk '{print $1}'):8000/api/docs${NC}"
echo -e "    Health check: ${GREEN}http://$(hostname -I | awk '{print $1}'):8000/api/v1/health${NC}"
echo ""

echo -e "${YELLOW}Comandos útiles:${NC}"
echo -e "  Ver logs: ${GREEN}journalctl -u sentinel-iot -f${NC}"
echo -e "  Reiniciar: ${GREEN}systemctl restart sentinel-iot${NC}"
echo -e "  Estado: ${GREEN}systemctl status sentinel-iot${NC}"
echo -e "  Detener: ${GREEN}systemctl stop sentinel-iot${NC}"
echo ""

# Guardar información en archivo
cat > /root/sentinel-info.txt << EOF
SENTINEL IoT v2.0 - Información de Instalación
================================================

Fecha de instalación: $(date)

API:
  URL: http://$(hostname -I | awk '{print $1}'):8000
  Documentación: http://$(hostname -I | awk '{print $1}'):8000/api/docs

Directorios:
  Instalación: $INSTALL_DIR
  Datos: $DATA_DIR
  Logs: $LOG_DIR

Comandos útiles:
  - Ver logs: journalctl -u sentinel-iot -f
  - Reiniciar: systemctl restart sentinel-iot
  - Estado: systemctl status sentinel-iot
EOF

if [ -n "$WIFI_PASSWORD" ]; then
    cat >> /root/sentinel-info.txt << EOF

Red Wi-Fi IoT:
  SSID: SENTINEL_IoT
  Contraseña: $WIFI_PASSWORD
  Gateway: $IOT_GATEWAY
EOF
fi

log_success "Información guardada en /root/sentinel-info.txt"

echo ""
log_info "Prueba la API con: curl http://localhost:8000/api/v1/health"
echo ""

exit 0
