# Guía de Instalación Profesional de Wi-Fi AP

## 🎯 Objetivo

Este documento explica el uso del nuevo script `install_hostapd_dnsmasq_proper.sh`, que instala y configura un punto de acceso Wi-Fi en tu Raspberry Pi siguiendo las mejores prácticas de la industria.

## ✅ Mejoras Clave

Este script es superior a las versiones anteriores porque:

1.  **Sigue el Orden Correcto:** Configura la red, luego los servicios, evitando conflictos.
2.  **Es Idempotente:** Puedes ejecutarlo varias veces sin causar problemas. El script limpia y reconfigura todo correctamente.
3.  **Hace Backups Automáticos:** Guarda tus configuraciones antiguas con timestamp antes de modificarlas.
4.  **Desactiva Servicios Conflictivos:** Se encarga de `wpa_supplicant` y `NetworkManager` para evitar que interfieran con `hostapd`.
5.  **Configuración Limpia:** Crea archivos de configuración desde cero, eliminando errores de sintaxis previos.
6.  **Verificación Constante:** Comprueba el estado de los servicios en cada paso y se detiene si hay un error, mostrando logs relevantes.
7.  **Persistencia Automática:** Guarda las reglas de NAT y las restaura automáticamente al reiniciar.
8.  **Es Interactivo:** Te pregunta si quieres continuar antes de hacer cambios.

## 🚀 Cómo Usar

### Paso 1: Transferir el Script

Copia el script `install_hostapd_dnsmasq_proper.sh` a tu Raspberry Pi.

### Paso 2: Ejecutar

```bash
# Dar permisos de ejecución
chmod +x install_hostapd_dnsmasq_proper.sh

# Ejecutar con sudo
sudo bash install_hostapd_dnsmasq_proper.sh
```

### Paso 3: Seguir Instrucciones

El script te mostrará la configuración que va a aplicar y te pedirá confirmación.

```
Configuración del Punto de Acceso:
  • SSID: SENTINEL_IoT
  • Contraseña: Sentinel2024!
  • Canal: 6
  • IP Gateway: 192.168.50.1
  • Rango DHCP: 192.168.50.10 - 192.168.50.250
  • Interfaz: wlan1

¿Deseas continuar con esta configuración? (s/n):
```

Presiona `s` y `Enter` para continuar.

### Paso 4: Verificación

Al final, el script mostrará un resumen completo:

```
╔════════════════════════════════════════════════════════════════╗
║              INSTALACIÓN COMPLETADA EXITOSAMENTE               ║
╚════════════════════════════════════════════════════════════════╝

Configuración del Punto de Acceso:
  • SSID: SENTINEL_IoT
  • Contraseña: Sentinel2024!
  • IP Gateway: 192.168.50.1
  • Rango DHCP: 192.168.50.10 - 192.168.50.250
  • Interfaz: wlan1
  • Interfaz Internet: eth0

Estado de Servicios:
  ✓ hostapd: ACTIVO
  ✓ dnsmasq: ACTIVO

Configuración de Red:
  • IP Forwarding: 1
  • Reglas NAT: 1 configuradas

Contraseña guardada en: /root/sentinel-wifi-password.txt
```

## 🔧 Solución de Problemas

Si el script falla, mostrará un error claro y los logs relevantes. Por ejemplo:

```
   ✗ Error al iniciar hostapd

Logs de hostapd:
-- Journal begins at ... --
nov 07 13:30:00 raspberrypi hostapd[1234]: wlan1: Could not connect to kernel driver
nov 07 13:30:00 raspberrypi hostapd[1234]: Interface initialization failed
```

**Causas comunes:**

*   **Adaptador Wi-Fi no compatible:** Asegúrate de que tu adaptador USB soporta modo AP.
*   **Conflicto de drivers:** El script intenta desactivar servicios conflictivos, pero algunos sistemas pueden requerir pasos adicionales.
*   **Problemas de hardware:** El adaptador no está bien conectado.

**Comandos útiles:**

```bash
# Ver logs de hostapd
sudo journalctl -u hostapd -f

# Ver logs de dnsmasq
sudo journalctl -u dnsmasq -f

# Ver dispositivos conectados
cat /var/lib/misc/dnsmasq.leases

# Reiniciar servicios
sudo systemctl restart hostapd dnsmasq
```

## 📚 Referencias

Este script fue creado basándose en las mejores prácticas de los siguientes recursos:

*   **SparkFun Tutorial:** [Setting up a Raspberry Pi 3 as an Access Point](https://learn.sparkfun.com/tutorials/setting-up-a-raspberry-pi-3-as-an-access-point/all)
*   **Raspberry Pi Documentation:** [Wireless access point](https://www.raspberrypi.com/documentation/computers/configuration.html#setting-up-a-routed-wireless-access-point)
*   **FinchSec Blog:** [Set up an access point on Linux using hostapd and dnsmasq](https://finchsec-1672417305892.hashnode.dev/linux-ap-hostapd-dnsmasq-dhcp)

## 🔄 Diferencias con Scripts Anteriores

| Característica | Script Anterior (`fix_wifi_complete.sh`) | Script Nuevo (`install_hostapd_dnsmasq_proper.sh`) |
| :--- | :--- | :--- |
| **Método** | Imperativo (ejecuta comandos) | Declarativo y robusto (configura archivos) |
| **Backups** | No | Sí, automáticos con timestamp |
| **Idempotencia** | Parcial | Sí, puedes ejecutarlo varias veces |
| **Manejo de Errores** | Básico | Avanzado, con logs y salida de error |
| **Conflictos** | Intenta detener servicios | Desactiva `wpa_supplicant` y `NetworkManager` |
| **Persistencia** | Parcial (iptables con `nft`) | Completa (iptables con `rc.local`) |
| **Interactivo** | No | Sí, pide confirmación |
| **Limpieza** | No | Sí, limpia configuraciones antiguas |
| **Basado en** | Soluciones puntuales | Mejores prácticas de la industria |

En resumen, este nuevo script es una solución **definitiva y profesional** para configurar el punto de acceso, diseñada para funcionar correctamente desde el primer intento y ser fácil de mantener.
