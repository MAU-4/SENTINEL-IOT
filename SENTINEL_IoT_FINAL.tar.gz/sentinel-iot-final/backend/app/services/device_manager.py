"""
Gestor de dispositivos IoT
"""
import logging
import subprocess
import re
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
import json

logger = logging.getLogger(__name__)


@dataclass
class DeviceInfo:
    """Información de dispositivo detectado"""
    mac_address: str
    ip_address: str
    hostname: Optional[str] = None
    manufacturer: Optional[str] = None
    first_seen: datetime = None
    last_seen: datetime = None
    is_new: bool = True
    
    def __post_init__(self):
        if self.first_seen is None:
            self.first_seen = datetime.utcnow()
        if self.last_seen is None:
            self.last_seen = datetime.utcnow()


class DeviceManager:
    """Gestor de dispositivos IoT"""
    
    # Base de datos de fabricantes (OUI - Organizationally Unique Identifier)
    OUI_DATABASE = {
        "00:50:F2": "Microsoft",
        "00:1B:63": "Apple",
        "B8:27:EB": "Raspberry Pi Foundation",
        "DC:A6:32": "Raspberry Pi Trading",
        "E4:5F:01": "Raspberry Pi Trading",
        "28:CD:C1": "Raspberry Pi Trading",
        "00:04:20": "Cisco",
        "00:1A:2B": "Samsung",
        "00:26:B0": "Google",
        "18:B4:30": "Nest Labs",
        "F4:F5:D8": "Google",
        "AC:63:BE": "Amazon Technologies",
        "00:FC:8B": "Amazon Technologies",
        "74:C2:46": "Amazon Technologies",
        "50:DC:E7": "Amazon Technologies",
        "00:17:88": "Philips",
        "EC:1A:59": "TP-Link",
        "50:C7:BF": "TP-Link",
        "A4:2B:B0": "Xiaomi",
        "34:CE:00": "Xiaomi",
        "28:6C:07": "Xiaomi",
    }
    
    # Patrones de clasificación por hostname
    HOSTNAME_PATTERNS = {
        "camera": ["cam", "camera", "ipcam", "webcam"],
        "thermostat": ["thermo", "nest", "ecobee"],
        "light": ["light", "bulb", "hue", "lifx"],
        "lock": ["lock", "august", "yale"],
        "sensor": ["sensor", "motion", "door", "window"],
        "speaker": ["speaker", "echo", "alexa", "homepod", "sonos"],
        "tv": ["tv", "roku", "firetv", "chromecast"],
        "plug": ["plug", "outlet", "switch"],
        "vacuum": ["vacuum", "roomba", "roborock"],
    }
    
    def __init__(self, interface: str = "wlan1"):
        self.interface = interface
        self.devices_cache: Dict[str, DeviceInfo] = {}
        self.dhcp_leases_file = "/var/lib/misc/dnsmasq.leases"
    
    def scan_network(self) -> List[DeviceInfo]:
        """Escanea la red en busca de dispositivos"""
        try:
            devices = []
            
            # Método 1: Leer leases de DHCP
            dhcp_devices = self._read_dhcp_leases()
            devices.extend(dhcp_devices)
            
            # Método 2: Escanear ARP table
            arp_devices = self._scan_arp_table()
            devices.extend(arp_devices)
            
            # Método 3: Escanear con nmap (si está disponible)
            nmap_devices = self._scan_with_nmap()
            devices.extend(nmap_devices)
            
            # Eliminar duplicados y actualizar caché
            unique_devices = self._deduplicate_devices(devices)
            self._update_cache(unique_devices)
            
            logger.info(f"Escaneados {len(unique_devices)} dispositivos")
            return unique_devices
            
        except Exception as e:
            logger.error(f"Error al escanear red: {e}")
            return []
    
    def _read_dhcp_leases(self) -> List[DeviceInfo]:
        """Lee los leases de DHCP"""
        devices = []
        
        try:
            with open(self.dhcp_leases_file, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        # Formato: timestamp mac ip hostname client-id
                        timestamp = int(parts[0])
                        mac = parts[1]
                        ip = parts[2]
                        hostname = parts[3] if parts[3] != "*" else None
                        
                        device = DeviceInfo(
                            mac_address=mac,
                            ip_address=ip,
                            hostname=hostname,
                            last_seen=datetime.fromtimestamp(timestamp)
                        )
                        
                        # Identificar fabricante
                        device.manufacturer = self._identify_manufacturer(mac)
                        
                        devices.append(device)
        
        except FileNotFoundError:
            logger.warning(f"Archivo de leases no encontrado: {self.dhcp_leases_file}")
        except Exception as e:
            logger.error(f"Error al leer leases: {e}")
        
        return devices
    
    def _scan_arp_table(self) -> List[DeviceInfo]:
        """Escanea la tabla ARP"""
        devices = []
        
        try:
            result = subprocess.run(
                ["ip", "neigh", "show", "dev", self.interface],
                capture_output=True,
                text=True,
                check=True
            )
            
            # Parsear salida
            # Formato: 192.168.100.10 lladdr aa:bb:cc:dd:ee:ff REACHABLE
            for line in result.stdout.split('\n'):
                if not line.strip():
                    continue
                
                parts = line.split()
                if len(parts) >= 4:
                    ip = parts[0]
                    mac = parts[3] if parts[2] == "lladdr" else None
                    
                    if mac:
                        device = DeviceInfo(
                            mac_address=mac,
                            ip_address=ip
                        )
                        device.manufacturer = self._identify_manufacturer(mac)
                        devices.append(device)
        
        except subprocess.CalledProcessError as e:
            logger.error(f"Error al escanear ARP: {e}")
        except Exception as e:
            logger.error(f"Error inesperado: {e}")
        
        return devices
    
    def _scan_with_nmap(self) -> List[DeviceInfo]:
        """Escanea con nmap si está disponible"""
        devices = []
        
        try:
            # Verificar si nmap está instalado
            result = subprocess.run(
                ["which", "nmap"],
                capture_output=True,
                check=False
            )
            
            if result.returncode != 0:
                return devices
            
            # Escanear red IoT
            result = subprocess.run(
                ["nmap", "-sn", "192.168.100.0/24", "-oG", "-"],
                capture_output=True,
                text=True,
                check=True,
                timeout=30
            )
            
            # Parsear salida
            for line in result.stdout.split('\n'):
                if "Host:" in line:
                    # Extraer IP y MAC
                    ip_match = re.search(r'Host: (\d+\.\d+\.\d+\.\d+)', line)
                    mac_match = re.search(r'MAC Address: ([0-9A-F:]{17})', line)
                    
                    if ip_match:
                        ip = ip_match.group(1)
                        mac = mac_match.group(1) if mac_match else None
                        
                        if mac:
                            device = DeviceInfo(
                                mac_address=mac,
                                ip_address=ip
                            )
                            device.manufacturer = self._identify_manufacturer(mac)
                            devices.append(device)
        
        except subprocess.TimeoutExpired:
            logger.warning("Timeout al escanear con nmap")
        except Exception as e:
            logger.error(f"Error al escanear con nmap: {e}")
        
        return devices
    
    def _identify_manufacturer(self, mac_address: str) -> Optional[str]:
        """Identifica el fabricante por MAC address"""
        # Extraer OUI (primeros 3 octetos)
        oui = mac_address.upper()[:8]
        return self.OUI_DATABASE.get(oui)
    
    def classify_device(self, device: DeviceInfo) -> str:
        """Clasifica el tipo de dispositivo"""
        # Clasificar por hostname
        if device.hostname:
            hostname_lower = device.hostname.lower()
            
            for device_type, patterns in self.HOSTNAME_PATTERNS.items():
                for pattern in patterns:
                    if pattern in hostname_lower:
                        return device_type
        
        # Clasificar por fabricante
        if device.manufacturer:
            manufacturer_lower = device.manufacturer.lower()
            
            if "nest" in manufacturer_lower or "ecobee" in manufacturer_lower:
                return "thermostat"
            elif "philips" in manufacturer_lower:
                return "light"
            elif "amazon" in manufacturer_lower:
                return "speaker"
            elif "google" in manufacturer_lower:
                return "speaker"
        
        return "unknown"
    
    def get_device_fingerprint(self, device: DeviceInfo) -> Dict:
        """Obtiene el fingerprint del dispositivo para ML"""
        # Capturar tráfico del dispositivo
        try:
            result = subprocess.run(
                [
                    "tcpdump",
                    "-i", self.interface,
                    "-c", "100",  # Capturar 100 paquetes
                    "-nn",
                    f"host {device.ip_address}",
                    "-w", "-"
                ],
                capture_output=True,
                timeout=10,
                check=False
            )
            
            # Analizar paquetes (simplificado)
            fingerprint = {
                "packet_count": 100,
                "protocols": [],
                "ports": [],
                "packet_sizes": [],
                "intervals": []
            }
            
            return fingerprint
            
        except subprocess.TimeoutExpired:
            logger.warning(f"Timeout al capturar tráfico de {device.ip_address}")
            return {}
        except Exception as e:
            logger.error(f"Error al obtener fingerprint: {e}")
            return {}
    
    def _deduplicate_devices(self, devices: List[DeviceInfo]) -> List[DeviceInfo]:
        """Elimina dispositivos duplicados"""
        seen_macs = set()
        unique_devices = []
        
        for device in devices:
            if device.mac_address not in seen_macs:
                seen_macs.add(device.mac_address)
                unique_devices.append(device)
        
        return unique_devices
    
    def _update_cache(self, devices: List[DeviceInfo]):
        """Actualiza el caché de dispositivos"""
        for device in devices:
            if device.mac_address in self.devices_cache:
                # Actualizar dispositivo existente
                cached = self.devices_cache[device.mac_address]
                cached.last_seen = device.last_seen
                cached.ip_address = device.ip_address
                cached.is_new = False
                
                if device.hostname:
                    cached.hostname = device.hostname
            else:
                # Nuevo dispositivo
                device.is_new = True
                self.devices_cache[device.mac_address] = device
    
    def get_device(self, mac_address: str) -> Optional[DeviceInfo]:
        """Obtiene un dispositivo por MAC"""
        return self.devices_cache.get(mac_address)
    
    def get_all_devices(self) -> List[DeviceInfo]:
        """Obtiene todos los dispositivos"""
        return list(self.devices_cache.values())
    
    def get_online_devices(self) -> List[DeviceInfo]:
        """Obtiene dispositivos online (vistos en últimos 5 minutos)"""
        threshold = datetime.utcnow() - timedelta(minutes=5)
        return [
            device for device in self.devices_cache.values()
            if device.last_seen >= threshold
        ]
    
    def get_new_devices(self) -> List[DeviceInfo]:
        """Obtiene dispositivos nuevos"""
        return [
            device for device in self.devices_cache.values()
            if device.is_new
        ]
    
    def mark_as_seen(self, mac_address: str):
        """Marca un dispositivo como visto"""
        if mac_address in self.devices_cache:
            self.devices_cache[mac_address].is_new = False
    
    def get_statistics(self) -> Dict:
        """Obtiene estadísticas de dispositivos"""
        all_devices = self.get_all_devices()
        online_devices = self.get_online_devices()
        new_devices = self.get_new_devices()
        
        # Contar por tipo
        device_types = {}
        for device in all_devices:
            device_type = self.classify_device(device)
            device_types[device_type] = device_types.get(device_type, 0) + 1
        
        # Contar por fabricante
        manufacturers = {}
        for device in all_devices:
            if device.manufacturer:
                manufacturers[device.manufacturer] = manufacturers.get(device.manufacturer, 0) + 1
        
        return {
            "total_devices": len(all_devices),
            "online_devices": len(online_devices),
            "new_devices": len(new_devices),
            "device_types": device_types,
            "manufacturers": manufacturers
        }


# Instancia global
device_manager = DeviceManager()
