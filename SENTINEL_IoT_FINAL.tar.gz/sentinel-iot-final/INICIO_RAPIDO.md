# 🚀 Inicio Rápido - SENTINEL IoT

## ⏱️ 5 Minutos para Tener tu Red IoT Funcionando

Esta guía te llevará de cero a tener un punto de acceso Wi-Fi seguro para tus dispositivos IoT en menos de 5 minutos.

---

## 📋 Requisitos Previos

Antes de empezar, asegúrate de tener:

- ✅ Raspberry Pi 3/4/5 o Zero W
- ✅ Adaptador Wi-Fi USB (si tu Pi no tiene Wi-Fi integrado o necesitas dos interfaces)
- ✅ Conexión a Internet (Ethernet o Wi-Fi)
- ✅ Acceso SSH o teclado/monitor conectado

---

## 🎯 Paso 1: Transferir el Proyecto

### Opción A: Usando SCP (desde tu computadora)

```bash
# Copiar el archivo a la Raspberry Pi
scp SENTINEL_IoT_FINAL.tar.gz pi@<IP_RASPBERRY>:~

# Conectar por SSH
ssh pi@<IP_RASPBERRY>

# Extraer
tar -xzf SENTINEL_IoT_FINAL.tar.gz
cd sentinel-iot-final
```

### Opción B: Descarga Directa (en la Raspberry Pi)

```bash
# Si tienes el archivo en un servidor web
wget http://tu-servidor.com/SENTINEL_IoT_FINAL.tar.gz

# O usa curl
curl -O http://tu-servidor.com/SENTINEL_IoT_FINAL.tar.gz

# Extraer
tar -xzf SENTINEL_IoT_FINAL.tar.gz
cd sentinel-iot-final
```

### Opción C: USB

1. Copia `SENTINEL_IoT_FINAL.tar.gz` a una memoria USB
2. Conecta la USB a la Raspberry Pi
3. Monta y copia:

```bash
# Montar USB (ajusta /dev/sda1 según tu USB)
sudo mount /dev/sda1 /mnt

# Copiar a home
cp /mnt/SENTINEL_IoT_FINAL.tar.gz ~/

# Desmontar
sudo umount /mnt

# Extraer
cd ~
tar -xzf SENTINEL_IoT_FINAL.tar.gz
cd sentinel-iot-final
```

---

## 🚀 Paso 2: Ejecutar Instalación

### Instalación Básica (Solo Wi-Fi AP)

```bash
cd scripts/installation
sudo bash install_hostapd_dnsmasq_proper.sh
```

**El script te preguntará:**

```
Configuración del Punto de Acceso:
  • SSID: SENTINEL_IoT
  • Contraseña: Sentinel2024!
  • Canal: 6
  • IP Gateway: 192.168.50.1
  • Rango DHCP: 192.168.50.10 - 192.168.50.250
  • Interfaz: wlan1

¿Deseas continuar con esta configuración? (s/n):
```

**Presiona `s` y `Enter`**

**Tiempo:** ~2 minutos

### Instalación Completa (Wi-Fi + Backend + Dashboard)

Si quieres el sistema completo con dashboard web:

```bash
cd scripts/installation
sudo bash install_fixed.sh
```

**Tiempo:** ~5-10 minutos

---

## ✅ Paso 3: Verificar Instalación

### Verificar Servicios

```bash
cd scripts/troubleshooting
sudo bash diagnose.sh
```

**Deberías ver:**

```
Estado de Servicios:
  ✓ hostapd: ACTIVO
  ✓ dnsmasq: ACTIVO

Configuración de Red:
  • IP Forwarding: 1
  • Reglas NAT: 1 configuradas
```

### Verificar Red Wi-Fi

Desde tu smartphone o laptop:

1. **Buscar redes Wi-Fi**
2. **Deberías ver:** `SENTINEL_IoT`
3. **Conectar** usando contraseña: `Sentinel2024!`
4. **Deberías obtener** una IP en el rango `192.168.50.10 - 192.168.50.250`

---

## 🧪 Paso 4: Probar Conectividad

### Desde tu Dispositivo Conectado

Abre una terminal (o app de terminal en smartphone) y ejecuta:

```bash
# 1. Probar gateway
ping 192.168.50.1

# 2. Probar Internet
ping 8.8.8.8

# 3. Probar DNS
ping google.com
```

**Todos deberían responder correctamente.**

### Desde un Navegador

Abre tu navegador y visita:

```
http://google.com
```

**Debería cargar normalmente.**

---

## 📊 Paso 5: Acceder al Dashboard (Opcional)

Si instalaste el sistema completo, accede al dashboard:

```
http://192.168.50.1:8000
```

**Deberías ver:**
- Estadísticas del sistema
- Lista de dispositivos conectados
- Opciones de configuración

---

## 🎉 ¡Listo!

Tu red IoT está funcionando. Ahora puedes:

1. **Conectar tus dispositivos IoT** a la red `SENTINEL_IoT`
2. **Ver dispositivos conectados** en el dashboard
3. **Configurar reglas de firewall** según tus necesidades
4. **Monitorear el tráfico** de red

---

## 🔧 Personalización Rápida

### Cambiar Nombre de Red (SSID)

Edita el script antes de ejecutarlo:

```bash
nano scripts/installation/install_hostapd_dnsmasq_proper.sh
```

Busca y cambia:

```bash
SSID="SENTINEL_IoT"              # Cambia esto
PASSWORD="Sentinel2024!"         # Y esto
```

### Cambiar Rango de IP

Si `192.168.50.x` está en uso en tu red:

```bash
IOT_IP="192.168.200.1"          # Cambia a otro rango
DHCP_START="192.168.200.10"
DHCP_END="192.168.200.250"
```

Consulta `docs/RANGOS_IP_ALTERNATIVOS.md` para más opciones.

---

## 🆘 Solución de Problemas Rápida

### Problema: Red Wi-Fi no aparece

```bash
cd scripts/troubleshooting
sudo bash fix_wifi_complete.sh
```

### Problema: Dispositivos no obtienen IP

```bash
cd scripts/troubleshooting
sudo bash fix_wifi_dhcp.sh
```

### Problema: No hay Internet

```bash
cd scripts/troubleshooting
sudo bash enable_internet.sh
```

### Problema: No sé qué falla

```bash
cd scripts/troubleshooting
sudo bash diagnose.sh
```

---

## 📚 Siguiente Paso

Una vez que todo funcione, consulta:

- **`README.md`** - Información completa del proyecto
- **`scripts/INDEX.md`** - Guía de todos los scripts
- **`docs/`** - Documentación detallada

---

## 💡 Comandos Útiles

```bash
# Ver dispositivos conectados
cat /var/lib/misc/dnsmasq.leases

# Ver logs de hostapd
sudo journalctl -u hostapd -f

# Ver logs de dnsmasq
sudo journalctl -u dnsmasq -f

# Reiniciar servicios
sudo systemctl restart hostapd dnsmasq

# Ver estado de servicios
sudo systemctl status hostapd dnsmasq

# Ver contraseña Wi-Fi
sudo cat /root/sentinel-wifi-password.txt
```

---

## 🎯 Resumen del Flujo

```
1. Transferir proyecto → tar -xzf SENTINEL_IoT_FINAL.tar.gz
                         ↓
2. Ejecutar instalación → sudo bash install_hostapd_dnsmasq_proper.sh
                         ↓
3. Verificar → sudo bash diagnose.sh
                         ↓
4. Conectar dispositivos → Buscar "SENTINEL_IoT"
                         ↓
5. Probar → ping 8.8.8.8
                         ↓
6. Acceder dashboard → http://192.168.50.1:8000
                         ↓
7. ¡Disfrutar! 🎉
```

---

## ⏱️ Tiempo Total

- **Transferir proyecto:** 1 minuto
- **Ejecutar instalación:** 2-10 minutos (según opción)
- **Verificar:** 1 minuto
- **Probar:** 1 minuto

**Total:** ~5-15 minutos

---

## ✅ Checklist

- [ ] Raspberry Pi con Raspbian instalado
- [ ] Conexión a Internet (Ethernet o Wi-Fi)
- [ ] Adaptador Wi-Fi USB (si es necesario)
- [ ] Proyecto transferido y extraído
- [ ] Script de instalación ejecutado
- [ ] Servicios verificados (diagnose.sh)
- [ ] Red Wi-Fi visible
- [ ] Dispositivo conectado exitosamente
- [ ] Internet funcionando
- [ ] Dashboard accesible (si instalaste completo)

---

## 🎊 ¡Felicidades!

Has configurado exitosamente tu red IoT segura con SENTINEL. Ahora tus dispositivos IoT están aislados de tu red principal y puedes monitorearlos y controlarlos fácilmente.

Para aprender más sobre las capacidades avanzadas, consulta la documentación completa en `docs/`.

---

**¿Problemas?** Consulta `docs/SOLUCION_WIFI_DHCP.md` o ejecuta `scripts/troubleshooting/diagnose.sh`
