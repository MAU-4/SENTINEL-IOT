# Gu	aa de Desarrollo - SENTINEL IoT v2.0

Esta gu	aa est	 destinada a desarrolladores que deseen contribuir al proyecto SENTINEL IoT, configurar un entorno de desarrollo local y entender el flujo de trabajo del c	digo.

## 1. Configuraci	n del Entorno Local

### Requisitos Previos

*   Git
*   Python 3.11 o superior
*   Node.js 18 o superior y pnpm
*   Docker y Docker Compose (recomendado para la base de datos y otros servicios)

### Backend

1.  **Clonar el repositorio:**
    ```bash
    git clone https://github.com/sentinel-iot/sentinel-v2.git
    cd sentinel-v2/backend
    ```

2.  **Crear y activar un entorno virtual:**
    ```bash
    python3 -m venv venv
    source venv/bin/activate
    ```

3.  **Instalar dependencias:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Configurar variables de entorno:**
    Crea un archivo `.env` en el directorio `backend` a partir del ejemplo:
    ```bash
    cp .env.example .env
    ```
    Ajusta las variables seg	n sea necesario. Para desarrollo, la base de datos SQLite por defecto es suficiente.

5.  **Inicializar la base de datos:**
    ```bash
    # (Desde el directorio backend)
    alembic upgrade head
    ```

6.  **Ejecutar el servidor de desarrollo:**
    ```bash
    uvicorn app.main:app --reload --port 8000
    ```
    El servidor estar	 disponible en `http://localhost:8000` y se recargar	 autom	 ticamente con cada cambio en el c	digo.

### Frontend

1.  **Navegar al directorio del frontend:**
    ```bash
    cd ../frontend
    ```

2.  **Instalar dependencias:**
    ```bash
    pnpm install
    ```

3.  **Configurar el proxy de desarrollo:**
    El archivo `vite.config.ts` ya est	 configurado para redirigir las peticiones de `/api/v1` al backend en `http://localhost:8000`.

4.  **Ejecutar el servidor de desarrollo:**
    ```bash
    pnpm dev
    ```
    La aplicaci	n web estar	 disponible en `http://localhost:5173`.

## 2. Estructura del C	digo

### Backend (`/backend`)

```
app/
	├── api/          # Endpoints de la API, organizados por recurso
	├── core/         # Configuraci	n central, base de datos, seguridad
	├── models/       # Modelos de datos de SQLAlchemy
	├── schemas/      # Esquemas de Pydantic para validaci	n
	├── services/     # L	gica de negocio (ej. FirewallManager, DeviceManager)
	├── ml/           # M	dulos de Machine Learning
	└── main.py       # Punto de entrada de la aplicaci	n FastAPI
tests/
	├── ...           # Pruebas unitarias y de integraci	n
```

### Frontend (`/frontend`)

```
src/
	├── components/   # Componentes reutilizables de React
	├── pages/        # Componentes que representan p	ginas completas
	├── services/     # L	gica para interactuar con la API (ej. axios)
	├── hooks/        # Hooks personalizados de React
	├── contexts/     # Contextos de React para estado global
	├── types/        # Definiciones de tipos de TypeScript
	└── App.tsx       # Componente ra	z y enrutador
```

## 3. Flujo de Trabajo de Contribuci	n

1.  **Crea un Fork:** Haz un fork del repositorio principal a tu propia cuenta de GitHub.
2.  **Crea una Rama:** Crea una rama descriptiva para tu nueva funcionalidad o correcci	n de error.
    ```bash
    git checkout -b feature/nombre-de-la-funcionalidad
    ```
3.  **Desarrolla:** Realiza tus cambios en el c	digo, siguiendo las gu	aas de estilo.
4.  **Escribe Pruebas:** A	ade pruebas unitarias o de integraci	n para tu c	digo en el directorio `tests/`.
5.  **Verifica el C	digo:** Aseg	rate de que tu c	digo pasa los linters y las pruebas.
    ```bash
    # Backend
    pytest
    black .
    
    # Frontend
    pnpm lint
    ```
6.  **Confirma tus Cambios:** Usa mensajes de commit claros y descriptivos.
7.  **Env	a un Pull Request (PR):** Env	a un PR desde tu rama al repositorio principal. Describe tus cambios detalladamente en el PR.

## 4. Gu	aas de Estilo

*   **Python:** Seguimos el est	ndar **PEP 8**. Usamos `black` para el formateo autom	 tico y `isort` para ordenar los imports.
*   **TypeScript/React:** Seguimos las gu	aas de estilo de Airbnb con algunas modificaciones. Usamos `ESLint` y `Prettier` para el formateo y la calidad del c	digo.
*   **Nombres:** Usa `snake_case` para variables y funciones en Python, y `camelCase` en TypeScript. Los componentes de React deben usar `PascalCase`.

## 5. Base de Datos y Migraciones

Usamos **Alembic** para gestionar las migraciones de la base de datos.

*   **Para crear una nueva migraci	n** (despu	s de modificar un modelo en `app/models/`):
    ```bash
    alembic revision --autogenerate -m "A	ade tabla de alertas"
    ```
*   **Para aplicar las migraciones:**
    ```bash
    alembic upgrade head
    ```

## 6. Consideraciones Clave

*   **Seguridad:** Todo c	digo nuevo debe ser escrito con la seguridad en mente. Valida todas las entradas del usuario, evita consultas SQL crudas y sigue las mejores pr	cticas de seguridad web.
*   **Rendimiento:** Considera el impacto en el rendimiento de tu c	digo, especialmente en un entorno con recursos limitados como un Raspberry Pi.
*   **Documentaci	n:** Documenta las funciones complejas, los endpoints de la API y las decisiones de arquitectura importantes.
