# Arquitectura Técnica - SENTINEL IoT v2.0

Este documento describe la arquitectura técnica de la plataforma SENTINEL IoT v2.0, detallando sus componentes, capas, flujos de trabajo y principios de diseño.

## Tabla de Contenidos

1.  [Principios de Diseño](#1-principios-de-diseño)
2.  [Arquitectura de Capas](#2-arquitectura-de-capas)
3.  [Componentes Principales](#3-componentes-principales)
    *   [3.1. Sentinel Core](#31-sentinel-core)
    *   [3.2. Sentinel Intelligence](#32-sentinel-intelligence)
    *   [3.3. Sentinel API](#33-sentinel-api)
    *   [3.4. Sentinel Web UI](#34-sentinel-web-ui)
4.  [Stack Tecnológico](#4-stack-tecnológico)
5.  [Flujos de Datos](#5-flujos-de-datos)
    *   [5.1. Conexión de un Nuevo Dispositivo](#51-conexión-de-un-nuevo-dispositivo)
    *   [5.2. Detección de Amenazas](#52-detección-de-amenazas)
6.  [Diseño de Seguridad](#6-diseño-de-seguridad)
7.  [Escalabilidad y Rendimiento](#7-escalabilidad-y-rendimiento)

---

## 1. Principios de Diseño

La arquitectura de SENTINEL IoT v2.0 se fundamenta en cuatro pilares clave:

*   **Modularidad:** Los componentes del sistema están diseñados para ser independientes y desacoplados. Esto permite que cada parte (backend, frontend, motor de ML) pueda ser desarrollada, actualizada y escalada de forma autónoma.
*   **Automatización:** Se busca minimizar la intervención manual. Tareas como la configuración de red, el descubrimiento de dispositivos y la aplicación de políticas de seguridad básicas se realizan de forma automática.
*   **Inteligencia:** El sistema va más allá de las reglas estáticas, incorporando Machine Learning para analizar el comportamiento de la red, detectar anomalías y clasificar dispositivos de forma proactiva.
*   **Usabilidad:** A pesar de su complejidad interna, la plataforma está diseñada para ser gestionada a través de una interfaz web intuitiva, haciendo la seguridad IoT accesible para usuarios no expertos.

## 2. Arquitectura de Capas

El sistema se estructura en un modelo de capas lógicas, donde cada capa se construye sobre la anterior, proporcionando una clara separación de responsabilidades.

| Capa | Componentes | Responsabilidades |
| :--- | :--- | :--- |
| **Capa 5: Frontend** | React, Material-UI, Recharts | Interfaz de usuario, visualización de datos, interacción con el usuario. |
| **Capa 4: Backend (API)** | FastAPI, SQLAlchemy, Pydantic | Lógica de negocio, gestión de estado, endpoints RESTful, autenticación. |
| **Capa 3: Servicios** | Python (Gestores de Firewall, Dispositivos, ML) | Orquestación de servicios de red, análisis de datos, ejecución de modelos de ML. |
| **Capa 2: Red** | hostapd, dnsmasq, nftables | Creación del punto de acceso, asignación de IPs, filtrado de paquetes (firewall). |
| **Capa 1: Hardware y SO** | Raspberry Pi, Raspberry Pi OS, Drivers | Ejecución física, gestión de interfaces de red, sistema de archivos. |

![Diagrama de Arquitectura de Capas](https://i.imgur.com/example.png)  <!-- Placeholder for a real diagram -->

## 3. Componentes Principales

### 3.1. Sentinel Core

Es el núcleo funcional que opera a bajo nivel.

*   **Gestor de Red:** Automatiza la configuración de las interfaces `wlan1` (red IoT) y `eth0` (red principal). Utiliza `systemd-networkd` y scripts de inicialización para garantizar una configuración persistente y correcta al arranque.
*   **Gestor de Firewall (`FirewallManager`):** Una clase de Python que actúa como una abstracción sobre `nftables`. Proporciona métodos para añadir, eliminar y listar reglas de forma programática, validando la sintaxis y aplicando cambios de manera atómica para evitar estados inconsistentes. Mantiene una caché de reglas en memoria para un acceso rápido.
*   **Monitor de Red:** Utiliza `tcpdump` y `scapy` para capturar y analizar paquetes en tiempo real. Es la principal fuente de datos para el motor de Machine Learning, extrayendo características del tráfico de cada dispositivo.

### 3.2. Sentinel Intelligence

Este componente alberga los modelos de Machine Learning.

*   **Detector de Anomalías (`AnomalyDetector`):** Implementa un modelo de `Isolation Forest` de `scikit-learn`. Se entrena con el tráfico de red normal para crear una línea base de comportamiento. Luego, puntúa el tráfico nuevo; si el "score de anomalía" supera un umbral, se genera una alerta. El modelo se reentrena periódicamente para adaptarse a los cambios en la red.
*   **Clasificador de Dispositivos (`DeviceClassifier`):** Utiliza una combinación de técnicas para identificar el tipo de dispositivo (cámara, sensor, etc.):
    1.  **OUI Lookup:** Mapea los primeros 3 bytes de la dirección MAC a un fabricante conocido.
    2.  **Análisis de Hostname:** Busca palabras clave (ej. "cam", "nest") en el hostname que el dispositivo proporciona durante la solicitud DHCP.
    3.  **Fingerprinting de Tráfico (ML):** Analiza patrones de comunicación (protocolos, puertos, tamaño de paquetes) para inferir el tipo de dispositivo. Es el método más avanzado y se utiliza cuando los otros fallan.

### 3.3. Sentinel API

La API RESTful, construida con **FastAPI**, es el cerebro que conecta todos los componentes.

*   **Endpoints:** Expone funcionalidades para ser consumidas por el frontend o por sistemas externos. Los endpoints están agrupados por recurso: `/devices`, `/firewall`, `/stats`, `/alerts`.
*   **Validación de Datos:** Utiliza **Pydantic** para validar automáticamente todos los datos de entrada y serializar los datos de salida, garantizando la integridad y consistencia de los datos.
*   **Gestión de Estado:** Se conecta a una base de datos (a través de **SQLAlchemy**) para persistir el estado de los dispositivos, las reglas de firewall personalizadas, los logs de eventos y las configuraciones.
*   **Autenticación:** Protege los endpoints mediante tokens **JWT (JSON Web Tokens)**, con un flujo de `access token` y `refresh token`.

### 3.4. Sentinel Web UI

La interfaz de usuario, construida como una **Single-Page Application (SPA)** con **React**.

*   **Componentes:** Utiliza la librería **Material-UI** para un diseño consistente y responsivo.
*   **Visualización de Datos:** Emplea **Recharts** para crear los gráficos interactivos del dashboard.
*   **Gestión de Estado del Cliente:** Usa **React Query** para gestionar la obtención, el cacheo y la actualización de los datos del servidor, mejorando la experiencia de usuario y reduciendo las recargas innecesarias.
*   **Comunicación en Tiempo Real:** Implementa **Socket.IO** para recibir actualizaciones instantáneas del backend (ej. nuevas alertas, cambios de estado de dispositivos) sin necesidad de recargar la página.

## 4. Stack Tecnológico

| Componente | Tecnología | Justificación |
| :--- | :--- | :--- |
| **Backend** | Python 3.11+, FastAPI | Alto rendimiento, sintaxis moderna, ecosistema maduro para ML y redes. |
| **Frontend** | React 18, TypeScript, Vite | Desarrollo rápido, componentización, seguridad de tipos, excelente rendimiento. |
| **Base de Datos** | SQLAlchemy, PostgreSQL / SQLite | Abstracción de BBDD, potente ORM. SQLite para simplicidad, PostgreSQL para escalabilidad. |
| **Firewall** | nftables | Sintaxis mejorada y mayor rendimiento (~40%) en comparación con `iptables`. |
| **Punto de Acceso** | hostapd | Solución estándar y robusta para crear puntos de acceso en Linux. |
| **DHCP/DNS** | dnsmasq | Ligero y fácil de configurar, ideal para dispositivos embebidos. |
| **Cache** | Redis | Almacenamiento en memoria rápido para caché de sesiones y colas de tareas. |
| **Tareas Asíncronas** | Celery | Ejecución de tareas en segundo plano (ej. reentrenamiento de modelos, generación de reportes). |

## 5. Flujos de Datos

### 5.1. Conexión de un Nuevo Dispositivo

1.  El dispositivo IoT se conecta a la red Wi-Fi `SENTINEL_IoT`.
2.  `dnsmasq` le asigna una dirección IP y registra el evento (MAC, IP, hostname) en su archivo de leases.
3.  El `DeviceManager` detecta el nuevo lease, crea una entrada para el nuevo dispositivo y lo marca como "Nuevo".
4.  La API notifica al frontend (vía Socket.IO) sobre el nuevo dispositivo.
5.  El usuario ve la notificación en el dashboard, clasifica el dispositivo y le asigna un perfil de seguridad.
6.  La API traduce el perfil de seguridad en reglas de firewall concretas y las aplica usando el `FirewallManager`.

### 5.2. Detección de Amenazas

1.  El `NetworkMonitor` captura continuamente muestras de tráfico de los dispositivos.
2.  Las muestras se convierten en vectores de características y se envían al `AnomalyDetector`.
3.  El modelo de `Isolation Forest` predice un score de anomalía para cada muestra.
4.  Si el score supera el umbral, se crea un evento de `Alerta Crítica` en la base de datos.
5.  La API envía la alerta al frontend en tiempo real.
6.  El sistema puede tomar acciones automáticas, como poner el dispositivo en cuarentena, mientras el administrador es notificado.

## 6. Diseño de Seguridad

La seguridad es un principio fundamental en todas las capas:

*   **Hardening del SO:** El sistema operativo base se minimiza, se actualiza regularmente y se protege con un firewall local (`ufw`). El acceso SSH se restringe a claves públicas.
*   **Aislamiento de Red:** La principal defensa es el aislamiento físico proporcionado por la red Wi-Fi separada.
*   **Política de Mínimo Privilegio:** El firewall opera con una política de `denegar por defecto`. Todo el tráfico está bloqueado a menos que sea explícitamente permitido por una regla.
*   **Seguridad de la API:** Se utiliza HTTPS (TLS 1.3), autenticación JWT y protección contra ataques comunes (CSRF, XSS) a través de las mejores prácticas de FastAPI y React.
*   **Cifrado:** Las contraseñas se hashean con `bcrypt`. Los datos sensibles en la base de datos pueden ser cifrados en reposo.

## 7. Escalabilidad y Rendimiento

Aunque una sola Raspberry Pi puede gestionar una red doméstica o de pequeña oficina (~500 dispositivos), la arquitectura está diseñada para escalar:

*   **Optimización de Rendimiento:**
    *   `nftables` utiliza estructuras de datos eficientes (sets y maps) para búsquedas de reglas en tiempo O(1).
    *   El backend asíncrono de FastAPI maneja un gran número de conexiones concurrentes.
    *   El análisis de ML y otras tareas pesadas se descargan a procesos `Celery` para no bloquear la API.
*   **Escalabilidad Horizontal (Futuro):** El diseño modular permite un futuro modelo de despliegue multi-instancia, con un controlador central que gestiona múltiples nodos SENTINEL para cubrir redes más grandes, proporcionando balanceo de carga y alta disponibilidad.
