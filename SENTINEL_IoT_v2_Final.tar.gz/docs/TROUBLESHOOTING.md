# Guía de Solución de Problemas - SENTINEL IoT v2.0

Esta guía te ayudará a diagnosticar y resolver los problemas más comunes al instalar y ejecutar SENTINEL IoT.

## Problema: El servicio sentinel-iot está inactivo

Este es el problema más común después de la instalación. Hay varias causas posibles.

### Diagnóstico

Primero, verifica el estado del servicio y los logs:

```bash
# Ver estado del servicio
sudo systemctl status sentinel-iot

# Ver logs recientes
sudo journalctl -u sentinel-iot -n 50

# Ver logs en tiempo real
sudo journalctl -u sentinel-iot -f
```

### Causa 1: Falta el archivo main.py o tiene errores

**Síntoma:** Los logs muestran `ModuleNotFoundError` o `ImportError`.

**Solución:**

```bash
# Verificar que existe el archivo
ls -la /opt/sentinel-iot/app/main.py

# Si no existe, hay que copiar los archivos del proyecto
cd /ruta/donde/descargaste/sentinel-iot-v2
sudo cp -r backend/* /opt/sentinel-iot/

# Asegurarse de que existen los archivos __init__.py
sudo touch /opt/sentinel-iot/app/__init__.py
sudo touch /opt/sentinel-iot/app/core/__init__.py
sudo touch /opt/sentinel-iot/app/models/__init__.py
sudo touch /opt/sentinel-iot/app/services/__init__.py
sudo touch /opt/sentinel-iot/app/ml/__init__.py

# Reintentar
sudo systemctl restart sentinel-iot
```

### Causa 2: Faltan dependencias de Python

**Síntoma:** Los logs muestran `ModuleNotFoundError: No module named 'fastapi'` o similar.

**Solución:**

```bash
# Activar el entorno virtual e instalar dependencias
cd /opt/sentinel-iot
source venv/bin/activate

# Instalar dependencias básicas
pip install fastapi uvicorn[standard] sqlalchemy pydantic pydantic-settings

# Si tienes el archivo requirements.txt
pip install -r requirements.txt

# Desactivar entorno
deactivate

# Reiniciar servicio
sudo systemctl restart sentinel-iot
```

### Causa 3: Problemas de permisos

**Síntoma:** Los logs muestran `PermissionError` o `Access denied`.

**Solución:**

```bash
# Dar permisos correctos
sudo chown -R root:root /opt/sentinel-iot
sudo chmod -R 755 /opt/sentinel-iot
sudo chmod -R 755 /var/lib/sentinel-iot
sudo chmod -R 755 /var/log/sentinel-iot

# Reiniciar servicio
sudo systemctl restart sentinel-iot
```

### Causa 4: Puerto 8000 ya está en uso

**Síntoma:** Los logs muestran `Address already in use` o `OSError: [Errno 98]`.

**Solución:**

```bash
# Ver qué está usando el puerto 8000
sudo lsof -i :8000

# Si hay otro proceso, detenerlo o cambiar el puerto de SENTINEL
# Para cambiar el puerto, editar el servicio:
sudo nano /etc/systemd/system/sentinel-iot.service

# Cambiar la línea ExecStart para usar otro puerto (ej. 8080):
# ExecStart=/opt/sentinel-iot/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8080

# Recargar configuración y reiniciar
sudo systemctl daemon-reload
sudo systemctl restart sentinel-iot
```

### Causa 5: Error en la configuración de la base de datos

**Síntoma:** Los logs muestran errores de SQLAlchemy o base de datos.

**Solución:**

```bash
# Crear el directorio de datos si no existe
sudo mkdir -p /var/lib/sentinel-iot
sudo chmod 755 /var/lib/sentinel-iot

# Verificar que el archivo de configuración existe
cat /etc/sentinel-iot/config.env

# Si no existe, crearlo:
sudo mkdir -p /etc/sentinel-iot
sudo bash -c 'cat > /etc/sentinel-iot/config.env << EOF
PROJECT_NAME="SENTINEL IoT v2.0"
DEBUG=false
LOG_LEVEL=INFO
DATABASE_URL=sqlite:////var/lib/sentinel-iot/sentinel.db
IOT_INTERFACE=wlan1
IOT_GATEWAY=192.168.100.1
EOF'

# Reiniciar servicio
sudo systemctl restart sentinel-iot
```

## Problema: hostapd no inicia

**Síntoma:** El punto de acceso Wi-Fi no aparece.

### Solución:

```bash
# Ver logs de hostapd
sudo journalctl -u hostapd -n 50

# Verificar que la interfaz wlan1 existe
ip link show wlan1

# Si no existe, conecta el adaptador Wi-Fi USB

# Verificar configuración
sudo cat /etc/hostapd/hostapd.conf

# Reiniciar servicio
sudo systemctl restart hostapd
```

## Problema: dnsmasq no inicia

**Síntoma:** Los dispositivos no obtienen IP al conectarse.

### Solución:

```bash
# Ver logs
sudo journalctl -u dnsmasq -n 50

# Verificar configuración
sudo cat /etc/dnsmasq.conf

# Verificar que wlan1 tiene IP
ip addr show wlan1

# Si no tiene IP, asignarla:
sudo ip addr add 192.168.100.1/24 dev wlan1
sudo ip link set wlan1 up

# Reiniciar servicio
sudo systemctl restart dnsmasq
```

## Problema: No se puede acceder a la API

**Síntoma:** Al intentar acceder a `http://<IP>:8000` no responde.

### Solución:

```bash
# Verificar que el servicio está activo
sudo systemctl status sentinel-iot

# Verificar que está escuchando en el puerto
sudo netstat -tlnp | grep 8000

# Verificar firewall
sudo nft list ruleset

# Asegurarse de que el puerto 8000 está permitido
sudo nft add rule inet sentinel input tcp dport 8000 accept

# Probar localmente
curl http://localhost:8000/api/v1/health

# Si funciona localmente pero no remotamente, verificar firewall del sistema
sudo ufw status
sudo ufw allow 8000/tcp
```

## Problema: Errores de importación en Python

**Síntoma:** `ModuleNotFoundError` o `ImportError` en los logs.

### Solución:

```bash
# Verificar que el entorno virtual está correctamente configurado
ls -la /opt/sentinel-iot/venv

# Si no existe, crearlo:
cd /opt/sentinel-iot
python3 -m venv venv

# Activar e instalar dependencias
source venv/bin/activate
pip install --upgrade pip
pip install fastapi uvicorn[standard] sqlalchemy pydantic pydantic-settings
deactivate

# Verificar que el servicio usa el entorno correcto
sudo cat /etc/systemd/system/sentinel-iot.service

# Debe contener:
# ExecStart=/opt/sentinel-iot/venv/bin/uvicorn app.main:app ...

# Reiniciar
sudo systemctl restart sentinel-iot
```

## Usar el script de instalación corregido

Si sigues teniendo problemas, usa el script de instalación corregido:

```bash
cd /ruta/donde/descargaste/sentinel-iot-v2/scripts
sudo bash install_fixed.sh
```

Este script incluye:
- ✅ Mejor manejo de errores
- ✅ Verificación de dependencias
- ✅ Creación automática de archivos __init__.py
- ✅ Configuración robusta del servicio
- ✅ Diagnóstico automático al finalizar

## Comandos útiles para diagnóstico

```bash
# Ver todos los servicios de SENTINEL
sudo systemctl status sentinel-iot hostapd dnsmasq nftables

# Ver logs de todos los servicios
sudo journalctl -u sentinel-iot -u hostapd -u dnsmasq -n 100

# Verificar interfaces de red
ip addr show

# Verificar procesos Python
ps aux | grep python

# Verificar puertos en uso
sudo netstat -tlnp

# Probar la API manualmente
curl http://localhost:8000/api/v1/health
curl http://localhost:8000/api/v1/stats

# Ver estructura de archivos
tree /opt/sentinel-iot -L 3
```

## Reinstalación limpia

Si nada funciona, puedes hacer una reinstalación limpia:

```bash
# Detener servicios
sudo systemctl stop sentinel-iot hostapd dnsmasq

# Eliminar instalación anterior
sudo rm -rf /opt/sentinel-iot
sudo rm -rf /var/lib/sentinel-iot
sudo rm -rf /var/log/sentinel-iot
sudo rm /etc/systemd/system/sentinel-iot.service

# Recargar systemd
sudo systemctl daemon-reload

# Ejecutar script de instalación corregido
cd /ruta/sentinel-iot-v2/scripts
sudo bash install_fixed.sh
```

## Obtener ayuda

Si después de seguir esta guía sigues teniendo problemas:

1. Recopila información del sistema:
```bash
sudo journalctl -u sentinel-iot -n 100 > sentinel-logs.txt
sudo systemctl status sentinel-iot > sentinel-status.txt
ip addr show > network-info.txt
```

2. Abre un issue en GitHub con:
   - Descripción del problema
   - Logs recopilados
   - Sistema operativo y versión
   - Modelo de Raspberry Pi

3. Únete a la comunidad en Discord para ayuda en tiempo real.
