/**
 * SENTINEL IoT v2.0 - Dashboard Principal
 */
import React, { useState, useEffect } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  CircularProgress,
  Alert,
  Chip,
} from '@mui/material';
import {
  Devices as DevicesIcon,
  Security as SecurityIcon,
  Warning as WarningIcon,
  NetworkCheck as NetworkIcon,
} from '@mui/icons-material';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

// Tipos
interface SystemStats {
  firewall: {
    total_rules: number;
    chains: string[];
  };
  devices: {
    total_devices: number;
    online_devices: number;
    new_devices: number;
    device_types: Record<string, number>;
  };
}

interface Device {
  mac_address: string;
  ip_address: string;
  hostname: string;
  device_type: string;
  manufacturer: string;
  last_seen: string;
  is_new: boolean;
}

// Colores
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

// Componente de tarjeta de estadística
const StatCard: React.FC<{
  title: string;
  value: number | string;
  icon: React.ReactNode;
  color: string;
  subtitle?: string;
}> = ({ title, value, icon, color, subtitle }) => (
  <Card sx={{ height: '100%' }}>
    <CardContent>
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Box>
          <Typography color="textSecondary" gutterBottom variant="body2">
            {title}
          </Typography>
          <Typography variant="h4" component="div" sx={{ color }}>
            {value}
          </Typography>
          {subtitle && (
            <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
              {subtitle}
            </Typography>
          )}
        </Box>
        <Box
          sx={{
            backgroundColor: `${color}20`,
            borderRadius: 2,
            p: 2,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {React.cloneElement(icon as React.ReactElement, {
            sx: { fontSize: 40, color },
          })}
        </Box>
      </Box>
    </CardContent>
  </Card>
);

// Componente principal del Dashboard
const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [devices, setDevices] = useState<Device[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Cargar datos
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Obtener estadísticas
        const statsResponse = await fetch('/api/v1/stats');
        const statsData = await statsResponse.json();
        setStats(statsData);

        // Obtener dispositivos
        const devicesResponse = await fetch('/api/v1/devices');
        const devicesData = await devicesResponse.json();
        setDevices(devicesData.devices);

        setLoading(false);
      } catch (err) {
        setError('Error al cargar datos del sistema');
        setLoading(false);
      }
    };

    fetchData();

    // Actualizar cada 5 segundos
    const interval = setInterval(fetchData, 5000);

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="400px"
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Alert severity="error" sx={{ m: 2 }}>
        {error}
      </Alert>
    );
  }

  if (!stats) {
    return null;
  }

  // Preparar datos para gráficos
  const deviceTypeData = Object.entries(stats.devices.device_types).map(
    ([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value,
    })
  );

  // Datos de ejemplo para tráfico (en producción vendría de la API)
  const trafficData = [
    { time: '00:00', sent: 400, received: 240 },
    { time: '04:00', sent: 300, received: 139 },
    { time: '08:00', sent: 200, received: 980 },
    { time: '12:00', sent: 278, received: 390 },
    { time: '16:00', sent: 189, received: 480 },
    { time: '20:00', sent: 239, received: 380 },
  ];

  return (
    <Box sx={{ p: 3 }}>
      {/* Título */}
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>
      <Typography variant="body1" color="textSecondary" paragraph>
        Monitoreo en tiempo real de la red IoT
      </Typography>

      {/* Tarjetas de estadísticas */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Dispositivos Totales"
            value={stats.devices.total_devices}
            icon={<DevicesIcon />}
            color="#0088FE"
            subtitle={`${stats.devices.online_devices} en línea`}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Dispositivos Nuevos"
            value={stats.devices.new_devices}
            icon={<WarningIcon />}
            color="#FFBB28"
            subtitle="Requieren clasificación"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Reglas de Firewall"
            value={stats.firewall.total_rules}
            icon={<SecurityIcon />}
            color="#00C49F"
            subtitle={`${stats.firewall.chains.length} chains activas`}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Estado del Sistema"
            value="Activo"
            icon={<NetworkIcon />}
            color="#8884D8"
            subtitle="Todos los servicios operativos"
          />
        </Grid>
      </Grid>

      {/* Gráficos */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        {/* Gráfico de tráfico */}
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Tráfico de Red
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={trafficData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="sent"
                    stackId="1"
                    stroke="#0088FE"
                    fill="#0088FE"
                    name="Enviado (KB)"
                  />
                  <Area
                    type="monotone"
                    dataKey="received"
                    stackId="1"
                    stroke="#00C49F"
                    fill="#00C49F"
                    name="Recibido (KB)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        {/* Gráfico de tipos de dispositivos */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Dispositivos por Tipo
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={deviceTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) =>
                      `${name} ${(percent * 100).toFixed(0)}%`
                    }
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {deviceTypeData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Lista de dispositivos recientes */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Dispositivos Conectados Recientemente
          </Typography>
          <Grid container spacing={2}>
            {devices.slice(0, 6).map((device) => (
              <Grid item xs={12} sm={6} md={4} key={device.mac_address}>
                <Card variant="outlined">
                  <CardContent>
                    <Box
                      display="flex"
                      justifyContent="space-between"
                      alignItems="center"
                      mb={1}
                    >
                      <Typography variant="subtitle1">
                        {device.hostname || 'Dispositivo sin nombre'}
                      </Typography>
                      {device.is_new && (
                        <Chip label="Nuevo" color="warning" size="small" />
                      )}
                    </Box>
                    <Typography variant="body2" color="textSecondary">
                      IP: {device.ip_address}
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      MAC: {device.mac_address}
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Tipo: {device.device_type}
                    </Typography>
                    {device.manufacturer && (
                      <Typography variant="body2" color="textSecondary">
                        Fabricante: {device.manufacturer}
                      </Typography>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Dashboard;
