# Firewall IoT Basado en Raspberry Pi

Este proyecto proporciona una solución de firewall para proteger dispositivos IoT utilizando una Raspberry Pi. Implementa reglas de `nftables` para filtrar el tráfico de red, asegurando que solo el tráfico autorizado pueda comunicarse con y desde sus dispositivos IoT.

## Contenido

1.  [Introducción](#1-introducción)
2.  [Arquitectura del Sistema](#2-arquitectura-del-sistema)
3.  [Instalación](#3-instalación)
4.  [Uso y Gestión](#4-uso-y-gestión)
5.  [Consideraciones de Seguridad](#5-consideraciones-de-seguridad)

## 1. Introducción

Con el creciente número de dispositivos IoT en nuestros hogares y empresas, la seguridad de la red se ha vuelto más crítica que nunca. Muchos dispositivos IoT carecen de mecanismos de seguridad robustos, lo que los convierte en objetivos fáciles para ataques cibernéticos. Este firewall actúa como una capa de protección adicional, aislando sus dispositivos IoT de amenazas externas y controlando su comunicación con el mundo exterior.

El sistema está diseñado para ser flexible y fácil de gestionar, permitiendo a los usuarios definir qué dispositivos IoT pueden comunicarse y con qué servicios, siguiendo una política de seguridad de "denegación por defecto" (lo que no está explícitamente permitido, está prohibido).




## 2. Arquitectura del Sistema

El firewall IoT se basa en una Raspberry Pi que actúa como una puerta de enlace segura para una red segmentada de dispositivos IoT. La arquitectura se compone de los siguientes elementos clave:

### 2.1 Componentes Clave

*   **Hardware:** Raspberry Pi (se recomienda un modelo con al menos dos interfaces de red, o el uso de un adaptador USB a Ethernet para la segmentación).
*   **Sistema Operativo:** Raspberry Pi OS Lite, una distribución ligera de Linux optimizada para la Raspberry Pi.
*   **Software de Firewall:** `nftables` es la tecnología principal utilizada para la gestión de reglas de firewall, ofreciendo flexibilidad y rendimiento.
*   **Módulos de Gestión de Reglas:** Scripts en Python (`firewall_manager.py` y `main.py`) que permiten la definición, adición, modificación y eliminación de reglas de firewall de manera programática.
*   **Mecanismo de Persistencia:** Un servicio Systemd asegura que las reglas del firewall se carguen automáticamente al inicio del sistema.

### 2.2 Flujo de Datos

El Raspberry Pi se interpone entre los dispositivos IoT y la red principal. Todo el tráfico de red pasa a través del firewall, donde es inspeccionado y filtrado según las reglas configuradas. Se aplica una política de "denegación por defecto", lo que significa que solo el tráfico explícitamente permitido puede pasar.

*   **Dispositivos IoT a Internet/LAN:** El tráfico es inspeccionado y reenviado solo si cumple con las reglas permitidas.
*   **Internet/LAN a Dispositivos IoT:** Solo se permite el tráfico entrante que esté explícitamente autorizado.
*   **Tráfico Interno del Firewall:** El propio Raspberry Pi tiene reglas específicas para su acceso a la red, asegurando su operatividad sin comprometer la seguridad de la red IoT.

### 2.3 Estructura de Reglas (nftables)

Las reglas de `nftables` se organizan en una tabla principal (`iot_firewall`) con cadenas para el tráfico de entrada (`input`), reenvío (`forward`) y salida (`output`). Se utilizan conjuntos (`sets`) para agrupar direcciones IP y puertos, facilitando la gestión dinámica de listas blancas y negras. La política por defecto para la cadena `forward` es `drop`, garantizando la máxima seguridad.

Para más detalles sobre la arquitectura y el diseño, consulte el archivo `architecture_design.md` en el directorio del proyecto.




## 3. Instalación

Siga estos pasos para instalar y configurar el firewall IoT en su Raspberry Pi:

### 3.1 Requisitos Previos

*   Una Raspberry Pi con Raspberry Pi OS Lite instalado.
*   Acceso SSH a la Raspberry Pi.
*   Conexión a internet en la Raspberry Pi para descargar paquetes.
*   **Configuración de Red:** Asegúrese de que su Raspberry Pi tenga al menos dos interfaces de red configuradas. Por ejemplo, `eth0` para la conexión a Internet/LAN y `eth1` (o un adaptador USB a Ethernet) para la red IoT segmentada. Deberá configurar la interfaz de la red IoT con una dirección IP estática (ej. `192.168.2.1/24`).

### 3.2 Pasos de Instalación

1.  **Clonar el Repositorio (o copiar los archivos):**
    Copie el contenido de este proyecto a su Raspberry Pi. Puede usar `git clone` si el proyecto está en un repositorio, o `scp` para copiar los archivos manualmente.

    ```bash
    # Ejemplo usando scp desde su máquina local
    scp -r /ruta/a/iot_firewall_project pi@<IP_RASPBERRY_PI>:/home/pi/
    ```

2.  **Ejecutar el Script de Instalación:**
    Acceda a su Raspberry Pi vía SSH y ejecute el script `install.sh` con privilegios de superusuario. Este script se encargará de instalar las dependencias, configurar `nftables`, crear el entorno virtual de Python y configurar el servicio Systemd para que el firewall se inicie automáticamente.

    ```bash
    ssh pi@<IP_RASPBERRY_PI>
    cd /home/pi/iot_firewall_project
    sudo ./install.sh
    ```

    El script realizará las siguientes acciones:
    *   Actualizará la lista de paquetes e instalará `nftables` y `python3-venv`.
    *   Copiará los archivos del proyecto a `/opt/iot_firewall`.
    *   Creará un entorno virtual de Python e instalará las dependencias.
    *   Configurará `nftables` para cargar las reglas al inicio.
    *   Creará un servicio Systemd (`iot-firewall.service`) para aplicar las reglas al arrancar.
    *   Habilitará el reenvío de IP (`ip_forwarding`).

3.  **Reiniciar la Raspberry Pi:**
    Para que todos los cambios surtan efecto, especialmente la configuración de red y el reenvío de IP, es recomendable reiniciar la Raspberry Pi.

    ```bash
    sudo reboot
    ```

Una vez reiniciado, el firewall estará activo y protegiendo su red IoT. Puede verificar el estado del servicio con `systemctl status iot-firewall.service`.




## 4. Uso y Gestión

El firewall se gestiona a través del script `main.py` ubicado en `/opt/iot_firewall/`. Este script permite añadir, eliminar y listar dispositivos IoT, servidores WAN permitidos, dispositivos LAN permitidos y puertos TCP/UDP. Cada vez que se realiza un cambio en la configuración, es necesario aplicar las reglas para que surtan efecto.

### 4.1 Comandos de Gestión

Todos los comandos deben ejecutarse con `sudo` y desde el directorio del proyecto. Se recomienda usar el entorno virtual de Python.

```bash
cd /opt/iot_firewall
sudo ./venv/bin/python3 main.py <comando> [argumentos]
```

**Comandos disponibles:**

*   **`apply_rules`**: Aplica las reglas de `nftables` definidas en la configuración actual. **Debe ejecutarse después de cualquier cambio en la configuración.**
    ```bash
    sudo ./venv/bin/python3 main.py apply_rules
    ```

*   **`add_iot_device <ip_address>`**: Añade una dirección IP de dispositivo IoT a la lista permitida. Los dispositivos en esta lista podrán comunicarse según las reglas definidas.
    ```bash
    sudo ./venv/bin/python3 main.py add_iot_device 192.168.2.100
    ```

*   **`remove_iot_device <ip_address>`**: Elimina una dirección IP de dispositivo IoT de la lista permitida.
    ```bash
    sudo ./venv/bin/python3 main.py remove_iot_device 192.168.2.100
    ```

*   **`add_wan_server <ip_address>`**: Añade una dirección IP de servidor WAN (internet) a la lista de destinos permitidos para los dispositivos IoT.
    ```bash
    sudo ./venv/bin/python3 main.py add_wan_server 8.8.8.8
    ```

*   **`remove_wan_server <ip_address>`**: Elimina una dirección IP de servidor WAN de la lista de permitidos.
    ```bash
    sudo ./venv/bin/python3 main.py remove_wan_server 8.8.8.8
    ```

*   **`add_lan_device <ip_address>`**: Añade una dirección IP de dispositivo en la LAN (red principal) que tiene permitido iniciar comunicación con los dispositivos IoT.
    ```bash
    sudo ./venv/bin/python3 main.py add_lan_device 192.168.1.50
    ```

*   **`remove_lan_device <ip_address>`**: Elimina una dirección IP de dispositivo LAN de la lista de permitidos.
    ```bash
    sudo ./venv/bin/python3 main.py remove_lan_device 192.168.1.50
    ```

*   **`add_tcp_port <port_number>`**: Añade un puerto TCP a la lista de puertos permitidos para la comunicación saliente de los dispositivos IoT.
    ```bash
    sudo ./venv/bin/python3 main.py add_tcp_port 80
    ```

*   **`remove_tcp_port <port_number>`**: Elimina un puerto TCP de la lista de permitidos.
    ```bash
    sudo ./venv/bin/python3 main.py remove_tcp_port 80
    ```

*   **`add_udp_port <port_number>`**: Añade un puerto UDP a la lista de puertos permitidos para la comunicación saliente de los dispositivos IoT.
    ```bash
    sudo ./venv/bin/python3 main.py add_udp_port 53
    ```

*   **`remove_udp_port <port_number>`**: Elimina un puerto UDP de la lista de permitidos.
    ```bash
    sudo ./venv/bin/python3 main.py remove_udp_port 53
    ```

*   **`show_config`**: Muestra la configuración actual del firewall (dispositivos, servidores, puertos permitidos).
    ```bash
    sudo ./venv/bin/python3 main.py show_config
    ```

*   **`help`**: Muestra la ayuda y los comandos disponibles.
    ```bash
    sudo ./venv/bin/python3 main.py help
    ```

### 4.2 Persistencia de la Configuración

Los cambios realizados con los comandos `add_` y `remove_` se guardan automáticamente en el archivo `config.json`. Cuando el sistema se reinicia, el servicio `iot-firewall.service` carga las reglas de `nftables` basándose en esta configuración guardada, asegurando que las políticas de firewall persistan.




## 5. Consideraciones de Seguridad

Implementar un firewall es un paso crucial para la seguridad de sus dispositivos IoT, pero es importante considerar otras prácticas para una protección integral:

*   **Actualizaciones Regulares:** Mantenga el sistema operativo de su Raspberry Pi (`sudo apt update && sudo apt upgrade`) y el software del firewall actualizados para protegerse contra vulnerabilidades conocidas.

*   **Hardening del Sistema:**
    *   Cambie la contraseña por defecto del usuario `pi`.
    *   Deshabilite servicios innecesarios en la Raspberry Pi.
    *   Asegure el acceso SSH utilizando claves SSH en lugar de contraseñas.

*   **Segmentación de Red:** La arquitectura propuesta ya segmenta la red IoT, lo cual es fundamental. Asegúrese de que los dispositivos IoT solo puedan comunicarse con el firewall y no directamente con la red principal o internet sin pasar por él.

*   **Contraseñas Fuertes en Dispositivos IoT:** Asegúrese de que todos sus dispositivos IoT utilicen contraseñas únicas y fuertes, y cambie las contraseñas por defecto.

*   **Monitoreo:** Considere implementar herramientas de monitoreo de red para detectar actividades sospechosas o intentos de intrusión en su red IoT.

*   **Auditoría de Reglas:** Revise periódicamente las reglas de su firewall para asegurarse de que sigan siendo relevantes y efectivas. Elimine las reglas que ya no sean necesarias.

*   **Copia de Seguridad:** Realice copias de seguridad regulares de la configuración de su firewall (`config.json`) y de las reglas de `nftables`.





## 6. Resolución de Problemas Comunes

Aquí se presentan algunos problemas comunes que pueden surgir y sus posibles soluciones:

*   **El firewall no se inicia al reiniciar:**
    *   Verifique el estado del servicio Systemd: `systemctl status iot-firewall.service`.
    *   Revise los logs del servicio: `journalctl -u iot-firewall.service`.
    *   Asegúrese de que el script `install.sh` se ejecutó correctamente y que el servicio está habilitado (`sudo systemctl enable iot-firewall.service`).

*   **Los dispositivos IoT no tienen acceso a la red:**
    *   Asegúrese de que las interfaces de red estén correctamente configuradas y que el reenvío de IP esté habilitado (`cat /proc/sys/net/ipv4/ip_forward` debe mostrar `1`).
    *   Verifique que las direcciones IP de los dispositivos IoT estén correctamente añadidas a la configuración (`sudo ./venv/bin/python3 main.py show_config`).
    *   Asegúrese de que los puertos y servidores a los que intentan acceder los dispositivos IoT estén permitidos en la configuración del firewall.
    *   Revise los logs de `nftables` para ver si hay paquetes siendo bloqueados (`sudo journalctl -k | grep "IoT_FW_DROP"`).

*   **Error al aplicar las reglas de `nftables`:**
    *   Asegúrese de que `nftables` esté instalado y funcionando correctamente (`sudo nft list ruleset`).
    *   Verifique la sintaxis de las reglas generadas por el script Python. Puede intentar generar las reglas sin aplicarlas y revisarlas: `sudo ./venv/bin/python3 main.py generate_rules > /tmp/test_rules.nft` y luego `sudo nft -c -f /tmp/test_rules.nft` para comprobar la sintaxis.

*   **No se guardan los cambios en la configuración:**
    *   Asegúrese de que el archivo `config.json` tenga los permisos de escritura adecuados para el usuario que ejecuta el script (`sudo chown <usuario>:<grupo> /opt/iot_firewall/config.json`).

Si los problemas persisten, consulte la documentación oficial de `nftables` y la comunidad de Raspberry Pi para obtener más ayuda.


