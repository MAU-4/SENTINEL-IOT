
import subprocess
import json

class FirewallManager:
    def __init__(self, config_file='config.json'):
        self.config_file = config_file
        self.config = self._load_config()

    def _load_config(self):
        try:
            with open(self.config_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {
                "iot_interface": "eth1",
                "wan_interface": "eth0",
                "iot_network": "192.168.2.0/24",
                "iot_devices": [],
                "allowed_wan_servers": [],
                "allowed_lan_devices": [],
                "allowed_tcp_ports": [],
                "allowed_udp_ports": []
            }

    def _save_config(self):
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=4)

    def _run_nft_command(self, command):
        try:
            result = subprocess.run(['nft', '-j', command], capture_output=True, text=True, check=True)
            print(f"Comando ejecutado: nft {command}")
            print(f"Salida: {result.stdout}")
            return result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Error al ejecutar nft {command}: {e}")
            print(f"Stderr: {e.stderr}")
            return None

    def generate_nftables_rules(self):
        rules = [
            "flush ruleset",
            "table ip iot_firewall {",
            "    chain input {",
            "        type filter hook input priority 0; policy accept;",
            "        # Permitir tráfico de loopback",
            "        iif \"lo\" accept",
            "        # Permitir tráfico relacionado con conexiones ya establecidas",
            "        ct state {established, related} accept",
            "        # Bloquear tráfico inválido",
            "        ct state invalid drop",
            "        # Permitir SSH desde la WAN (ajustar según necesidad)",
            "        # ip saddr { 192.168.1.0/24 } tcp dport 22 accept",
            "        # Permitir ICMP (ping)",
            "        icmp type echo-request accept",
            "        # Denegar todo lo demás",
            "        drop",
            "    }",
            "",
            "    chain forward {",
            "        type filter hook forward priority 0; policy drop;",
            "        # Permitir tráfico relacionado con conexiones ya establecidas",
            "        ct state {established, related} accept",
            "        # Bloquear tráfico inválido",
            "        ct state invalid drop",
            "",
            "        # Permitir tráfico desde la interfaz IoT a la WAN",
            f"        iifname \"{self.config['iot_interface']}\" oifname \"{self.config['wan_interface']}\" accept",
            "",
            "        # Permitir tráfico desde la WAN a la interfaz IoT (solo si es necesario y explícitamente permitido)",
            "        # oifname \"{self.config['iot_interface']}\" iifname \"{self.config['wan_interface']}\" ct state new drop # Bloquear nuevas conexiones entrantes por defecto",
            "",
            "        # Reglas específicas para dispositivos IoT y servicios permitidos",
            "        # Ejemplo: Permitir DNS desde dispositivos IoT a servidores DNS específicos",
            "        # ip saddr { 192.168.2.10, 192.168.2.11 } udp dport 53 ip daddr { 8.8.8.8, 8.8.4.4 } accept",
            "",
            "        # Ejemplo: Permitir HTTP/HTTPS desde dispositivos IoT a servidores web específicos",
            "        # ip saddr { 192.168.2.10 } tcp dport { 80, 443 } ip daddr { 203.0.113.0/24 } accept",
            "",
            "        # Ejemplo: Permitir tráfico de gestión desde LAN a IoT (ej. MQTT, CoAP)",
            "        # ip saddr { 192.168.1.100 } ip daddr { 192.168.2.10 } tcp dport { 1883, 5683 } accept",
            "",
            "        # Denegar todo lo demás (ya cubierto por la política por defecto, pero para logging)",
            "        # log prefix \"IoT_FW_DROP: \" drop",
            "    }",
            "",
            "    chain output {",
            "        type filter hook output priority 0; policy accept;",
            "        # Permitir tráfico de loopback",
            "        oif \"lo\" accept",
            "        # Permitir tráfico relacionado con conexiones ya establecidas",
            "        ct state {established, related} accept",
            "        # Bloquear tráfico inválido",
            "        ct state invalid drop",
            "        # Denegar todo lo demás",
            "        drop",
            "    }",
            "}"
        ]

        # Add dynamic rules based on config
        if self.config['iot_devices']:
            rules.insert(5, f"    set iot_devices {{ type ipv4_addr; elements {{ {', '.join(self.config['iot_devices'])} }}; }}")
        if self.config['allowed_wan_servers']:
            rules.insert(6, f"    set allowed_wan_servers {{ type ipv4_addr; elements {{ {', '.join(self.config['allowed_wan_servers'])} }}; }}")
        if self.config['allowed_lan_devices']:
            rules.insert(7, f"    set allowed_lan_devices {{ type ipv4_addr; elements {{ {', '.join(self.config['allowed_lan_devices'])} }}; }}")
        if self.config['allowed_tcp_ports']:
            rules.insert(8, f"    set allowed_tcp_ports {{ type inet_service; elements {{ {', '.join(map(str, self.config['allowed_tcp_ports']))} }}; }}")
        if self.config['allowed_udp_ports']:
            rules.insert(9, f"    set allowed_udp_ports {{ type inet_service; elements {{ {', '.join(map(str, self.config['allowed_udp_ports']))} }}; }}")

        return "\n".join(rules)

    def apply_rules(self):
        nft_rules = self.generate_nftables_rules()
        print("Aplicando las siguientes reglas de nftables:\n" + nft_rules)
        process = subprocess.run(['sudo', 'nft', '-f', '-'], input=nft_rules, text=True, capture_output=True)
        if process.returncode == 0:
            print("Reglas de nftables aplicadas con éxito.")
            return True
        else:
            print("Error al aplicar las reglas de nftables.")
            print(f"Stderr: {process.stderr}")
            return False

    def add_iot_device(self, ip_address):
        if ip_address not in self.config['iot_devices']:
            self.config['iot_devices'].append(ip_address)
            self._save_config()
            print(f"Dispositivo IoT {ip_address} añadido.")
            return True
        print(f"Dispositivo IoT {ip_address} ya existe.")
        return False

    def remove_iot_device(self, ip_address):
        if ip_address in self.config['iot_devices']:
            self.config['iot_devices'].remove(ip_address)
            self._save_config()
            print(f"Dispositivo IoT {ip_address} eliminado.")
            return True
        print(f"Dispositivo IoT {ip_address} no encontrado.")
        return False

    def add_allowed_wan_server(self, ip_address):
        if ip_address not in self.config['allowed_wan_servers']:
            self.config['allowed_wan_servers'].append(ip_address)
            self._save_config()
            print(f"Servidor WAN {ip_address} añadido a la lista de permitidos.")
            return True
        print(f"Servidor WAN {ip_address} ya existe en la lista de permitidos.")
        return False

    def remove_allowed_wan_server(self, ip_address):
        if ip_address in self.config['allowed_wan_servers']:
            self.config['allowed_wan_servers'].remove(ip_address)
            self._save_config()
            print(f"Servidor WAN {ip_address} eliminado de la lista de permitidos.")
            return True
        print(f"Servidor WAN {ip_address} no encontrado en la lista de permitidos.")
        return False

    def add_allowed_lan_device(self, ip_address):
        if ip_address not in self.config['allowed_lan_devices']:
            self.config['allowed_lan_devices'].append(ip_address)
            self._save_config()
            print(f"Dispositivo LAN {ip_address} añadido a la lista de permitidos.")
            return True
        print(f"Dispositivo LAN {ip_address} ya existe en la lista de permitidos.")
        return False

    def remove_allowed_lan_device(self, ip_address):
        if ip_address in self.config['allowed_lan_devices']:
            self.config['allowed_lan_devices'].remove(ip_address)
            self._save_config()
            print(f"Dispositivo LAN {ip_address} eliminado de la lista de permitidos.")
            return True
        print(f"Dispositivo LAN {ip_address} no encontrado en la lista de permitidos.")
        return False

    def add_allowed_tcp_port(self, port):
        if port not in self.config['allowed_tcp_ports']:
            self.config['allowed_tcp_ports'].append(port)
            self._save_config()
            print(f"Puerto TCP {port} añadido a la lista de permitidos.")
            return True
        print(f"Puerto TCP {port} ya existe en la lista de permitidos.")
        return False

    def remove_allowed_tcp_port(self, port):
        if port in self.config['allowed_tcp_ports']:
            self.config['allowed_tcp_ports'].remove(port)
            self._save_config()
            print(f"Puerto TCP {port} eliminado de la lista de permitidos.")
            return True
        print(f"Puerto TCP {port} no encontrado en la lista de permitidos.")
        return False

    def add_allowed_udp_port(self, port):
        if port not in self.config['allowed_udp_ports']:
            self.config['allowed_udp_ports'].append(port)
            self._save_config()
            print(f"Puerto UDP {port} añadido a la lista de permitidos.")
            return True
        print(f"Puerto UDP {port} ya existe en la lista de permitidos.")
        return False

    def remove_allowed_udp_port(self, port):
        if port in self.config['allowed_udp_ports']:
            self.config['allowed_udp_ports'].remove(port)
            self._save_config()
            print(f"Puerto UDP {port} eliminado de la lista de permitidos.")
            return True
        print(f"Puerto UDP {port} no encontrado en la lista de permitidos.")
        return False

    def get_current_config(self):
        return self.config

if __name__ == "__main__":
    manager = FirewallManager()
    # Ejemplo de uso:
    # manager.add_iot_device("192.168.2.10")
    # manager.add_allowed_wan_server("8.8.8.8")
    # manager.add_allowed_tcp_port(80)
    # manager.apply_rules()

    # Para ver la configuración actual
    # print(manager.get_current_config())

    # Para aplicar las reglas iniciales (sin modificar la configuración)
    # manager.apply_rules()


