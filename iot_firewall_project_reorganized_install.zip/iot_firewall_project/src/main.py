
from firewall_manager import FirewallManager
import sys

def print_help():
    print("\nUso: python3 main.py [comando] [argumentos]")
    print("Comandos disponibles:")
    print("  apply_rules                       - Aplica las reglas de nftables definidas en la configuración.")
    print("  add_iot_device <ip_address>       - Añade una dirección IP de dispositivo IoT a la lista permitida.")
    print("  remove_iot_device <ip_address>    - Elimina una dirección IP de dispositivo IoT de la lista permitida.")
    print("  add_wan_server <ip_address>       - Añade una dirección IP de servidor WAN a la lista permitida.")
    print("  remove_wan_server <ip_address>    - Elimina una dirección IP de servidor WAN de la lista permitida.")
    print("  add_lan_device <ip_address>       - Añade una dirección IP de dispositivo LAN a la lista permitida.")
    print("  remove_lan_device <ip_address>    - Elimina una dirección IP de dispositivo LAN de la lista permitida.")
    print("  add_tcp_port <port_number>        - Añade un puerto TCP a la lista permitida.")
    print("  remove_tcp_port <port_number>     - Elimina un puerto TCP de la lista permitida.")
    print("  add_udp_port <port_number>        - Añade un puerto UDP a la lista permitida.")
    print("  remove_udp_port <port_number>     - Elimina un puerto UDP de la lista permitida.")
    print("  show_config                       - Muestra la configuración actual del firewall.")
    print("  help                              - Muestra esta ayuda.")


if __name__ == "__main__":
    manager = FirewallManager("config.json")

    if len(sys.argv) < 2:
        print_help()
        sys.exit(1)

    command = sys.argv[1]

    if command == "apply_rules":
        manager.apply_rules()
    elif command == "add_iot_device":
        if len(sys.argv) == 3:
            manager.add_iot_device(sys.argv[2])
        else:
            print("Uso: add_iot_device <ip_address>")
    elif command == "remove_iot_device":
        if len(sys.argv) == 3:
            manager.remove_iot_device(sys.argv[2])
        else:
            print("Uso: remove_iot_device <ip_address>")
    elif command == "add_wan_server":
        if len(sys.argv) == 3:
            manager.add_allowed_wan_server(sys.argv[2])
        else:
            print("Uso: add_wan_server <ip_address>")
    elif command == "remove_wan_server":
        if len(sys.argv) == 3:
            manager.remove_allowed_wan_server(sys.argv[2])
        else:
            print("Uso: remove_wan_server <ip_address>")
    elif command == "add_lan_device":
        if len(sys.argv) == 3:
            manager.add_allowed_lan_device(sys.argv[2])
        else:
            print("Uso: add_lan_device <ip_address>")
    elif command == "remove_lan_device":
        if len(sys.argv) == 3:
            manager.remove_allowed_lan_device(sys.argv[2])
        else:
            print("Uso: remove_lan_device <ip_address>")
    elif command == "add_tcp_port":
        if len(sys.argv) == 3:
            try:
                port = int(sys.argv[2])
                manager.add_allowed_tcp_port(port)
            except ValueError:
                print("El puerto debe ser un número entero.")
        else:
            print("Uso: add_tcp_port <port_number>")
    elif command == "remove_tcp_port":
        if len(sys.argv) == 3:
            try:
                port = int(sys.argv[2])
                manager.remove_allowed_tcp_port(port)
            except ValueError:
                print("El puerto debe ser un número entero.")
        else:
            print("Uso: remove_tcp_port <port_number>")
    elif command == "add_udp_port":
        if len(sys.argv) == 3:
            try:
                port = int(sys.argv[2])
                manager.add_allowed_udp_port(port)
            except ValueError:
                print("El puerto debe ser un número entero.")
        else:
            print("Uso: add_udp_port <port_number>")
    elif command == "remove_udp_port":
        if len(sys.argv) == 3:
            try:
                port = int(sys.argv[2])
                manager.remove_allowed_udp_port(port)
            except ValueError:
                print("El puerto debe ser un número entero.")
        else:
            print("Uso: remove_udp_port <port_number>")
    elif command == "show_config":
        import json
        print(json.dumps(manager.get_current_config(), indent=4))
    elif command == "help":
        print_help()
    else:
        print(f"Comando desconocido: {command}")
        print_help()
    


