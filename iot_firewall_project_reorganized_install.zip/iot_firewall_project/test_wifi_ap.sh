#!/bin/bash

# Script para probar la funcionalidad del AP Wi-Fi (hostapd y dnsmasq)

log_info() {
    echo "[INFO] $1"
}

log_error() {
    echo "[ERROR] $1" >&2
}

log_success() {
    echo "[SUCCESS] $1"
}

# --- 1. Verificar estado de hostapd ---
log_info "Verificando estado del servicio hostapd..."
systemctl is-active --quiet hostapd
if [ $? -eq 0 ]; then
    log_success "hostapd está corriendo."
else
    log_error "hostapd NO está corriendo. Por favor, revise la configuración y el servicio."
    exit 1
fi

# --- 2. Verificar estado de dnsmasq ---
log_info "Verificando estado del servicio dnsmasq..."
systemctl is-active --quiet dnsmasq
if [ $? -eq 0 ]; then
    log_success "dnsmasq está corriendo."
else
    log_error "dnsmasq NO está corriendo. Por favor, revise la configuración y el servicio."
    exit 1
fi

# --- 3. Verificar configuración de la interfaz wlan1 ---
log_info "Verificando configuración de la interfaz wlan1..."
ifconfig wlan1 | grep "inet 10.0.0.1"
if [ $? -eq 0 ]; then
    log_success "wlan1 está configurada con la IP 10.0.0.1."
else
    log_error "wlan1 NO está configurada con la IP 10.0.0.1. Por favor, revise /etc/network/interfaces.d/wlan1."
    exit 1
fi

# --- 4. Verificar si wlan1 está en modo AP (requiere herramientas inalámbricas) ---
log_info "Verificando si wlan1 está en modo Access Point..."
# Este paso puede requerir 'iw' o 'iwconfig'. Asumimos 'iw' está disponible.
# Si no, se puede omitir o instalar 'iw'.
if command -v iw &> /dev/null
then
    iw dev wlan1 info | grep "type AP"
    if [ $? -eq 0 ]; then
        log_success "wlan1 está en modo Access Point."
    else
        log_error "wlan1 NO está en modo Access Point. Revise la configuración de hostapd."
        exit 1
    fi
else
    log_info "'iw' no encontrado. No se puede verificar el modo AP de wlan1 directamente."
fi

log_success "Pruebas de funcionalidad del AP Wi-Fi completadas. hostapd y dnsmasq están activos y wlan1 configurada."
log_info "Para una prueba completa, intente conectar un dispositivo a la red 'IoT_Network' y verifique la asignación de IP y el acceso a Internet."


