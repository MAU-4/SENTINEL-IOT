# Índice de Scripts - SENTINEL IoT

## 📋 Organización

Los scripts están organizados en tres categorías:

1. **installation/** - Scripts para instalación inicial
2. **troubleshooting/** - Scripts para solucionar problemas
3. **utilities/** - Scripts auxiliares (futuro)

---

## 📁 installation/ - Scripts de Instalación

### 1. `install_hostapd_dnsmasq_proper.sh` ⭐ RECOMENDADO

**Descripción:** Instalación profesional de punto de acceso Wi-Fi siguiendo mejores prácticas.

**Qué hace:**
- Instala y configura hostapd y dnsmasq correctamente
- Configura IP estática en wlan1
- Habilita NAT para compartir Internet
- Desactiva servicios conflictivos
- Hace backups automáticos
- Verificación completa en cada paso

**Cuándo usar:**
- Primera instalación del sistema
- Reinstalación limpia después de problemas
- Cuando quieres la configuración más robusta

**Tiempo:** ~2 minutos

**Comando:**
```bash
sudo bash install_hostapd_dnsmasq_proper.sh
```

**Resultado esperado:**
- Red Wi-Fi "SENTINEL_IoT" funcionando
- Dispositivos obtienen IP automáticamente
- Acceso a Internet desde dispositivos IoT
- Servicios hostapd y dnsmasq activos

---

### 2. `install_fixed.sh`

**Descripción:** Instalación completa del sistema SENTINEL IoT (Wi-Fi + Backend + Frontend).

**Qué hace:**
- Todo lo de `install_hostapd_dnsmasq_proper.sh`
- Instala backend de Python (FastAPI)
- Instala frontend (Dashboard web)
- Configura servicio systemd para SENTINEL
- Crea base de datos SQLite

**Cuándo usar:**
- Quieres instalar el sistema completo
- Necesitas el dashboard web y la API
- Primera instalación con todas las funcionalidades

**Tiempo:** ~5-10 minutos

**Comando:**
```bash
sudo bash install_fixed.sh
```

**Resultado esperado:**
- Todo lo de `install_hostapd_dnsmasq_proper.sh`
- Servicio sentinel-iot activo
- Dashboard accesible en http://192.168.50.1:8000
- API REST funcionando

---

### 3. `deploy_frontend.sh`

**Descripción:** Despliega solo la interfaz web (frontend) del dashboard.

**Qué hace:**
- Copia archivos HTML/CSS/JS a /opt/sentinel-iot/
- Actualiza código del backend para servir frontend
- Reinicia servicio sentinel-iot

**Cuándo usar:**
- Ya tienes el backend instalado
- Solo quieres actualizar la interfaz web
- Hiciste cambios en el frontend

**Tiempo:** ~30 segundos

**Comando:**
```bash
sudo bash deploy_frontend.sh
```

**Resultado esperado:**
- Dashboard actualizado
- Servicio reiniciado correctamente

---

## 📁 troubleshooting/ - Scripts de Solución de Problemas

### 1. `diagnose.sh` 🔍

**Descripción:** Diagnóstico completo del estado del sistema.

**Qué hace:**
- Verifica estado de servicios (hostapd, dnsmasq, sentinel-iot)
- Verifica configuración de red
- Verifica archivos de configuración
- Verifica dependencias de Python
- Verifica puertos en uso
- Muestra dispositivos conectados

**Cuándo usar:**
- No sabes qué está fallando
- Quieres verificar el estado general
- Antes de reportar un problema

**Tiempo:** ~10 segundos

**Comando:**
```bash
sudo bash diagnose.sh
```

**Resultado esperado:**
- Reporte completo del estado del sistema
- Identificación de problemas
- Sugerencias de solución

---

### 2. `fix_detection_and_internet.sh` ⭐ SOLUCIÓN COMPLETA

**Descripción:** Solución todo-en-uno para problemas de detección de dispositivos e Internet.

**Qué hace:**
- Configura NAT para acceso a Internet
- Habilita IP forwarding
- Detecta dispositivos con IP estática (ARP)
- Detecta dispositivos con DHCP
- Muestra todos los dispositivos conectados

**Cuándo usar:**
- Dispositivos no obtienen Internet
- Dashboard no muestra dispositivos
- Dispositivos con IP estática no aparecen

**Tiempo:** ~30 segundos

**Comando:**
```bash
sudo bash fix_detection_and_internet.sh
```

**Resultado esperado:**
- Internet funcionando en red IoT
- Lista de todos los dispositivos detectados
- Configuración persistente

---

### 3. `enable_internet.sh`

**Descripción:** Configura solo acceso a Internet (NAT) sin tocar detección.

**Qué hace:**
- Habilita IP forwarding
- Configura NAT con nftables
- Hace configuración persistente

**Cuándo usar:**
- Solo tienes problema de Internet
- La detección funciona correctamente
- Quieres una solución rápida y específica

**Tiempo:** ~15 segundos

**Comando:**
```bash
sudo bash enable_internet.sh
```

**Resultado esperado:**
- Dispositivos IoT pueden acceder a Internet
- Configuración sobrevive reinicios

---

### 4. `detect_static_devices.sh`

**Descripción:** Detecta y muestra dispositivos con IP estática.

**Qué hace:**
- Escanea tabla ARP
- Escanea leases de DHCP
- Muestra todos los dispositivos
- Exporta a JSON
- Sugiere soluciones

**Cuándo usar:**
- Quieres ver qué dispositivos están conectados
- Dispositivos con IP estática no aparecen en dashboard
- Debugging de problemas de detección

**Tiempo:** ~5 segundos

**Comando:**
```bash
sudo bash detect_static_devices.sh
```

**Resultado esperado:**
- Tabla con todos los dispositivos detectados
- Diferenciación entre DHCP y ARP
- Archivo JSON con datos

---

### 5. `fix_wifi_complete.sh`

**Descripción:** Solución completa para problemas de Wi-Fi.

**Qué hace:**
- Limpia configuraciones antiguas
- Detiene servicios conflictivos
- Reconfigura wlan1
- Crea archivos de configuración limpios
- Reinicia servicios en orden correcto

**Cuándo usar:**
- Red Wi-Fi no aparece
- hostapd no inicia
- Problemas generales de Wi-Fi
- Después de cambios manuales que rompieron algo

**Tiempo:** ~1 minuto

**Comando:**
```bash
sudo bash fix_wifi_complete.sh
```

**Resultado esperado:**
- Red Wi-Fi funcionando
- hostapd y dnsmasq activos
- Configuración limpia

---

### 6. `fix_wifi_dhcp.sh`

**Descripción:** Solución específica para problemas de DHCP.

**Qué hace:**
- Diagnostica problemas de dnsmasq
- Corrige configuración de dnsmasq
- Crea archivo de leases
- Reinicia dnsmasq

**Cuándo usar:**
- Red Wi-Fi aparece pero dispositivos no obtienen IP
- Se queda en "Obteniendo dirección IP..."
- dnsmasq tiene errores

**Tiempo:** ~30 segundos

**Comando:**
```bash
sudo bash fix_wifi_dhcp.sh
```

**Resultado esperado:**
- Dispositivos obtienen IP correctamente
- dnsmasq funcionando sin errores

---

## 🎯 Guía de Decisión Rápida

### ¿Qué script debo usar?

```
┌─ Primera instalación
│  └─ ¿Solo Wi-Fi?
│     ├─ Sí → install_hostapd_dnsmasq_proper.sh
│     └─ No (sistema completo) → install_fixed.sh
│
├─ Problemas de Wi-Fi
│  └─ ¿Qué falla?
│     ├─ Red no aparece → fix_wifi_complete.sh
│     ├─ No da IP → fix_wifi_dhcp.sh
│     └─ No sé → diagnose.sh primero
│
├─ Problemas de Internet
│  └─ enable_internet.sh
│
├─ Problemas de detección
│  └─ ¿Qué necesitas?
│     ├─ Ver dispositivos → detect_static_devices.sh
│     └─ Arreglar detección → fix_detection_and_internet.sh
│
├─ Actualizar frontend
│  └─ deploy_frontend.sh
│
└─ No sé qué falla
   └─ diagnose.sh
```

---

## 📊 Tabla Comparativa

| Script | Instalación | Solución | Tiempo | Complejidad |
|--------|-------------|----------|--------|-------------|
| `install_hostapd_dnsmasq_proper.sh` | ✅ | ❌ | 2 min | Baja |
| `install_fixed.sh` | ✅ | ❌ | 10 min | Media |
| `deploy_frontend.sh` | ⚠️ | ⚠️ | 30 seg | Baja |
| `diagnose.sh` | ❌ | 🔍 | 10 seg | Baja |
| `fix_detection_and_internet.sh` | ❌ | ✅ | 30 seg | Media |
| `enable_internet.sh` | ❌ | ✅ | 15 seg | Baja |
| `detect_static_devices.sh` | ❌ | 🔍 | 5 seg | Baja |
| `fix_wifi_complete.sh` | ❌ | ✅ | 1 min | Media |
| `fix_wifi_dhcp.sh` | ❌ | ✅ | 30 seg | Baja |

**Leyenda:**
- ✅ = Sí
- ❌ = No
- ⚠️ = Parcial
- 🔍 = Diagnóstico

---

## 🆘 Flujo de Solución de Problemas

```
1. Ejecutar diagnóstico
   sudo bash troubleshooting/diagnose.sh

2. Identificar problema según salida

3. Aplicar script correspondiente:
   
   • "hostapd: inactive" → fix_wifi_complete.sh
   • "dnsmasq: inactive" → fix_wifi_dhcp.sh
   • "No Internet" → enable_internet.sh
   • "No devices detected" → detect_static_devices.sh
   • Múltiples problemas → fix_detection_and_internet.sh

4. Verificar solución
   sudo bash troubleshooting/diagnose.sh

5. Si persiste, consultar logs:
   sudo journalctl -u hostapd -n 50
   sudo journalctl -u dnsmasq -n 50
```

---

## 💡 Consejos

1. **Siempre ejecuta con sudo:** Todos los scripts requieren permisos de root.

2. **Lee la salida:** Los scripts muestran mensajes claros sobre qué están haciendo.

3. **Usa diagnose.sh primero:** Te ahorra tiempo identificando el problema exacto.

4. **Los scripts son idempotentes:** Puedes ejecutarlos varias veces sin problemas.

5. **Hacen backups:** No tengas miedo de ejecutarlos, tus configuraciones se respaldan.

6. **Consulta la documentación:** Cada script tiene su guía detallada en `docs/`.

---

## 📝 Notas Importantes

- **Scripts de instalación** modifican archivos del sistema y deben ejecutarse con cuidado.
- **Scripts de troubleshooting** son seguros y pueden ejecutarse en cualquier momento.
- **Todos los scripts** hacen backups antes de modificar archivos.
- **Los logs** se pueden ver con `journalctl` para debugging avanzado.

---

## 🔄 Orden de Ejecución Recomendado

### Primera Instalación

```bash
# 1. Instalar Wi-Fi AP
sudo bash installation/install_hostapd_dnsmasq_proper.sh

# 2. Verificar
sudo bash troubleshooting/diagnose.sh

# 3. Si todo OK, instalar backend (opcional)
sudo bash installation/install_fixed.sh
```

### Solución de Problemas

```bash
# 1. Diagnosticar
sudo bash troubleshooting/diagnose.sh

# 2. Aplicar solución específica
sudo bash troubleshooting/[script_correspondiente].sh

# 3. Verificar
sudo bash troubleshooting/diagnose.sh
```

---

Para más información, consulta la documentación completa en `../docs/`.
