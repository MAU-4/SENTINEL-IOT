#!/bin/bash

################################################################################
# SENTINEL IoT - Instalador para Kali Linux (Máquina Virtual)
# Versión: 2.1-VM
# Descripción: Instala SENTINEL IoT en Kali Linux con detección automática
#              de interfaces de red para entornos virtualizados
################################################################################

set -e  # Salir si hay algún error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables globales
INSTALL_DIR="/opt/sentinel-iot"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd ../.. && pwd)"
VENV_DIR="$INSTALL_DIR/venv"
LOG_FILE="/var/log/sentinel-install.log"

# Función para imprimir mensajes
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1" | tee -a "$LOG_FILE"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1" | tee -a "$LOG_FILE"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1" | tee -a "$LOG_FILE"
}

# Verificar que se ejecuta como root
if [[ $EUID -ne 0 ]]; then
   print_error "Este script debe ejecutarse como root (sudo)"
   exit 1
fi

print_info "=========================================="
print_info "SENTINEL IoT - Instalación para Kali VM"
print_info "=========================================="

# Detectar interfaces de red disponibles
print_info "Detectando interfaces de red..."
MAIN_INTERFACE=$(ip route | grep default | awk '{print $5}' | head -1)
ALL_INTERFACES=$(ip -o link show | awk -F': ' '{print $2}' | grep -v lo)

print_info "Interfaz principal detectada: $MAIN_INTERFACE"
print_info "Interfaces disponibles:"
echo "$ALL_INTERFACES" | while read iface; do
    echo "  - $iface"
done

# Preguntar al usuario qué interfaz usar para IoT
print_warning "¿Qué interfaz quieres usar para la red IoT?"
print_info "Opciones:"
echo "$ALL_INTERFACES" | nl
read -p "Ingresa el número de la interfaz IoT (o Enter para usar $MAIN_INTERFACE): " IOT_INTERFACE_NUM

if [ -z "$IOT_INTERFACE_NUM" ]; then
    IOT_INTERFACE="$MAIN_INTERFACE"
else
    IOT_INTERFACE=$(echo "$ALL_INTERFACES" | sed -n "${IOT_INTERFACE_NUM}p")
fi

print_success "Interfaz IoT seleccionada: $IOT_INTERFACE"

# Configurar red IoT
IOT_NETWORK="192.168.50.0/24"
IOT_GATEWAY="192.168.50.1"
IOT_DHCP_START="192.168.50.100"
IOT_DHCP_END="192.168.50.200"

print_info "Configuración de red IoT:"
print_info "  Red: $IOT_NETWORK"
print_info "  Gateway: $IOT_GATEWAY"
print_info "  Rango DHCP: $IOT_DHCP_START - $IOT_DHCP_END"

# Actualizar sistema
print_info "Actualizando sistema..."
apt-get update -qq >> "$LOG_FILE" 2>&1
print_success "Sistema actualizado"

# Instalar dependencias
print_info "Instalando dependencias..."
apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    nftables \
    dnsmasq \
    net-tools \
    iptables \
    iproute2 \
    >> "$LOG_FILE" 2>&1

print_success "Dependencias instaladas"

# Crear directorio de instalación
print_info "Creando directorio de instalación..."
mkdir -p "$INSTALL_DIR"
print_success "Directorio creado: $INSTALL_DIR"

# Copiar archivos del proyecto
print_info "Copiando archivos del proyecto..."
if [ -d "$PROJECT_DIR/backend" ]; then
    cp -r "$PROJECT_DIR/backend" "$INSTALL_DIR/"
    print_success "Backend copiado"
else
    print_error "No se encontró el directorio backend en $PROJECT_DIR"
    exit 1
fi

if [ -d "$PROJECT_DIR/frontend" ]; then
    cp -r "$PROJECT_DIR/frontend" "$INSTALL_DIR/"
    print_success "Frontend copiado"
else
    print_error "No se encontró el directorio frontend en $PROJECT_DIR"
    exit 1
fi

# Crear entorno virtual de Python
print_info "Creando entorno virtual de Python..."
python3 -m venv "$VENV_DIR" >> "$LOG_FILE" 2>&1
print_success "Entorno virtual creado"

# Instalar dependencias de Python
print_info "Instalando dependencias de Python..."
"$VENV_DIR/bin/pip" install --upgrade pip >> "$LOG_FILE" 2>&1
"$VENV_DIR/bin/pip" install \
    fastapi \
    uvicorn \
    scapy \
    python-multipart \
    >> "$LOG_FILE" 2>&1
print_success "Dependencias de Python instaladas"

# Configurar interfaz IoT con IP estática
print_info "Configurando interfaz $IOT_INTERFACE..."
ip addr flush dev "$IOT_INTERFACE" 2>/dev/null || true
ip addr add "$IOT_GATEWAY/24" dev "$IOT_INTERFACE" 2>/dev/null || true
ip link set "$IOT_INTERFACE" up
print_success "Interfaz $IOT_INTERFACE configurada"

# Configurar dnsmasq
print_info "Configurando dnsmasq..."
cat > /etc/dnsmasq.d/sentinel-iot.conf << EOF
# SENTINEL IoT - Configuración DHCP y DNS
interface=$IOT_INTERFACE
bind-interfaces
dhcp-range=$IOT_DHCP_START,$IOT_DHCP_END,255.255.255.0,24h
dhcp-option=3,$IOT_GATEWAY
dhcp-option=6,$IOT_GATEWAY
domain=sentinel.local
local=/sentinel.local/
log-dhcp
log-queries
EOF

# Deshabilitar systemd-resolved si está activo
if systemctl is-active --quiet systemd-resolved; then
    print_info "Deshabilitando systemd-resolved..."
    systemctl stop systemd-resolved
    systemctl disable systemd-resolved
    rm -f /etc/resolv.conf
    echo "nameserver 8.8.8.8" > /etc/resolv.conf
    print_success "systemd-resolved deshabilitado"
fi

systemctl enable dnsmasq >> "$LOG_FILE" 2>&1
systemctl restart dnsmasq >> "$LOG_FILE" 2>&1
print_success "dnsmasq configurado y activo"

# Habilitar IP forwarding
print_info "Habilitando IP forwarding..."
echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-sentinel-iot.conf
sysctl -p /etc/sysctl.d/99-sentinel-iot.conf >> "$LOG_FILE" 2>&1
print_success "IP forwarding habilitado"

# Configurar NAT con nftables
print_info "Configurando NAT con nftables..."
nft add table ip nat 2>/dev/null || true
nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; } 2>/dev/null || true
nft add rule ip nat postrouting oifname "$MAIN_INTERFACE" masquerade 2>/dev/null || nft flush chain ip nat postrouting && nft add rule ip nat postrouting oifname "$MAIN_INTERFACE" masquerade

# Configurar filtrado básico
nft add table inet filter 2>/dev/null || true
nft add chain inet filter forward { type filter hook forward priority 0 \; policy accept \; } 2>/dev/null || true

# Guardar reglas de nftables
nft list ruleset > /etc/nftables.conf
systemctl enable nftables >> "$LOG_FILE" 2>&1
print_success "NAT y firewall configurados"

# Crear servicio systemd para el backend
print_info "Creando servicio systemd..."
cat > /etc/systemd/system/sentinel-backend.service << EOF
[Unit]
Description=SENTINEL IoT Backend Service
After=network.target nftables.service dnsmasq.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR/backend
Environment="PATH=$VENV_DIR/bin"
ExecStart=$VENV_DIR/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable sentinel-backend >> "$LOG_FILE" 2>&1
systemctl start sentinel-backend >> "$LOG_FILE" 2>&1
print_success "Servicio sentinel-backend creado y activo"

# Verificar estado de servicios
print_info "Verificando servicios..."
sleep 3

if systemctl is-active --quiet dnsmasq; then
    print_success "dnsmasq está activo"
else
    print_warning "dnsmasq no está activo"
fi

if systemctl is-active --quiet sentinel-backend; then
    print_success "sentinel-backend está activo"
else
    print_warning "sentinel-backend no está activo"
fi

# Resumen de instalación
print_info "=========================================="
print_success "Instalación completada exitosamente"
print_info "=========================================="
echo ""
print_info "Configuración de red IoT:"
print_info "  Interfaz: $IOT_INTERFACE"
print_info "  Gateway: $IOT_GATEWAY"
print_info "  Red: $IOT_NETWORK"
print_info "  DHCP: $IOT_DHCP_START - $IOT_DHCP_END"
echo ""
print_info "Acceso al dashboard:"
print_info "  URL: http://$IOT_GATEWAY:8000"
echo ""
print_info "Comandos útiles:"
print_info "  Ver logs del backend: sudo journalctl -u sentinel-backend -f"
print_info "  Ver estado de servicios: sudo systemctl status sentinel-backend dnsmasq"
print_info "  Ver dispositivos conectados: cat /var/lib/misc/dnsmasq.leases"
echo ""
print_success "¡SENTINEL IoT está listo para usar!"
