# Solución: "Unable to Connect" en Interfaz Web

Si al intentar acceder a la interfaz web de SENTINEL IoT ves el mensaje **"Unable to connect"**, sigue esta guía para resolver el problema.

## Diagnóstico Rápido

Primero, verifica qué está funcionando:

```bash
# 1. Verificar que el servicio está activo
sudo systemctl status sentinel-iot

# 2. Verificar que el puerto 8000 está escuchando
sudo netstat -tlnp | grep 8000

# 3. Probar la API localmente
curl http://localhost:8000/api/v1/health

# 4. Probar desde el navegador local
# Si estás en la Raspberry Pi con interfaz gráfica:
# Abre: http://localhost:8000
```

## Solución Rápida (Recomendada)

### Opción 1: Usar el script de despliegue automático

```bash
cd /ruta/donde/descargaste/sentinel-iot-v2/scripts
sudo bash deploy_frontend.sh
```

Este script:
- ✅ Copia la interfaz web al directorio correcto
- ✅ Configura permisos
- ✅ Reinicia el servicio
- ✅ Verifica que todo funcione

### Opción 2: Despliegue manual

```bash
# 1. Copiar archivos de la interfaz web
cd /ruta/donde/descargaste/sentinel-iot-v2
sudo mkdir -p /opt/sentinel-iot/frontend/public
sudo cp frontend/public/index.html /opt/sentinel-iot/frontend/public/

# 2. Dar permisos
sudo chmod -R 755 /opt/sentinel-iot/frontend

# 3. Verificar que el archivo existe
ls -la /opt/sentinel-iot/frontend/public/index.html

# 4. Reiniciar servicio
sudo systemctl restart sentinel-iot

# 5. Esperar unos segundos y verificar
sleep 3
curl http://localhost:8000
```

## Causas Comunes y Soluciones

### 1. El servicio no está activo

**Síntoma:** `curl http://localhost:8000` no responde.

**Solución:**

```bash
# Ver estado
sudo systemctl status sentinel-iot

# Si está inactivo, ver logs
sudo journalctl -u sentinel-iot -n 50

# Reiniciar
sudo systemctl restart sentinel-iot
```

Si el servicio sigue inactivo, consulta `SOLUCION_SERVICIO_INACTIVO.md`.

### 2. El firewall está bloqueando el puerto 8000

**Síntoma:** `curl http://localhost:8000` funciona, pero no puedes acceder desde otro dispositivo.

**Solución:**

```bash
# Ver reglas actuales de nftables
sudo nft list ruleset

# Añadir regla para permitir puerto 8000
sudo nft add rule inet sentinel input tcp dport 8000 accept

# Si usas ufw también
sudo ufw allow 8000/tcp
sudo ufw reload

# Verificar que la regla se añadió
sudo nft list ruleset | grep 8000
```

### 3. Falta la interfaz web (archivo index.html)

**Síntoma:** La API funciona (`/api/v1/health` responde) pero la raíz (`/`) devuelve JSON en lugar de HTML.

**Solución:**

```bash
# Verificar si existe el archivo
ls -la /opt/sentinel-iot/frontend/public/index.html

# Si no existe, copiarlo
cd /ruta/sentinel-iot-v2
sudo mkdir -p /opt/sentinel-iot/frontend/public
sudo cp frontend/public/index.html /opt/sentinel-iot/frontend/public/

# Reiniciar servicio
sudo systemctl restart sentinel-iot
```

### 4. El backend no puede servir archivos estáticos

**Síntoma:** Error 500 o logs muestran problemas con `FileResponse`.

**Solución:**

```bash
# Verificar que el código de main.py está actualizado
sudo cat /opt/sentinel-iot/app/main.py | grep FileResponse

# Si no aparece, copiar el archivo actualizado
cd /ruta/sentinel-iot-v2
sudo cp backend/app/main.py /opt/sentinel-iot/app/

# Reiniciar servicio
sudo systemctl restart sentinel-iot
```

### 5. Problema de red o DNS

**Síntoma:** No puedes acceder desde otro dispositivo en la misma red.

**Solución:**

```bash
# Obtener la IP de la Raspberry Pi
hostname -I

# Probar desde otro dispositivo
# Abre en el navegador: http://<IP_RASPBERRY>:8000

# Si no funciona, verificar conectividad
ping <IP_RASPBERRY>

# Verificar que el servicio escucha en todas las interfaces (0.0.0.0)
sudo netstat -tlnp | grep 8000
# Debe mostrar: 0.0.0.0:8000 (no 127.0.0.1:8000)
```

## Verificación Completa

Una vez aplicada la solución, verifica todos los componentes:

### 1. Verificar servicio

```bash
sudo systemctl status sentinel-iot
# Debe mostrar: active (running)
```

### 2. Verificar API

```bash
# Health check
curl http://localhost:8000/api/v1/health
# Debe responder: {"status":"healthy",...}

# Estadísticas
curl http://localhost:8000/api/v1/stats
# Debe responder con datos del sistema
```

### 3. Verificar interfaz web

```bash
# Desde la Raspberry Pi
curl http://localhost:8000
# Debe responder con HTML (empieza con <!DOCTYPE html>)

# Desde otro dispositivo
# Abre en el navegador: http://<IP_RASPBERRY>:8000
# Debes ver el dashboard de SENTINEL IoT
```

### 4. Verificar firewall

```bash
# Listar reglas
sudo nft list ruleset | grep 8000

# Debe haber una regla que permita el puerto 8000
```

## Estructura de Archivos Correcta

Después de la instalación, la estructura debe ser:

```
/opt/sentinel-iot/
├── app/
│   ├── __init__.py
│   ├── main.py              # Backend con soporte para servir HTML
│   ├── core/
│   ├── models/
│   ├── services/
│   └── ml/
├── frontend/
│   └── public/
│       └── index.html       # ← Interfaz web (IMPORTANTE)
├── venv/                    # Entorno virtual de Python
└── requirements.txt
```

## Acceso a la Interfaz Web

Una vez todo funcione correctamente:

### Desde la misma Raspberry Pi

```
http://localhost:8000
```

### Desde otro dispositivo en la red

```
http://<IP_RASPBERRY>:8000
```

Para obtener la IP:
```bash
hostname -I
```

### Endpoints disponibles

| URL | Descripción |
|-----|-------------|
| `http://<IP>:8000` | Dashboard principal (interfaz web) |
| `http://<IP>:8000/api/docs` | Documentación interactiva de la API |
| `http://<IP>:8000/api/v1/health` | Health check del sistema |
| `http://<IP>:8000/api/v1/stats` | Estadísticas del sistema |
| `http://<IP>:8000/api/v1/devices` | Lista de dispositivos |

## Características de la Interfaz Web

La interfaz web incluye:

- ✅ **Dashboard en tiempo real** con estadísticas del sistema
- ✅ **Lista de dispositivos** conectados con su estado
- ✅ **Actualización automática** cada 10 segundos
- ✅ **Enlaces rápidos** a la documentación de la API
- ✅ **Diseño responsive** que funciona en móviles y tablets
- ✅ **Indicadores visuales** de estado (online, offline, nuevo)

## Solución de Problemas Avanzada

### Verificar logs en tiempo real

```bash
# Ver logs del servicio
sudo journalctl -u sentinel-iot -f

# Ver logs de acceso (si hay errores 404, 500, etc.)
```

### Probar manualmente el endpoint raíz

```bash
# Debe devolver HTML
curl -v http://localhost:8000

# Verificar el Content-Type
# Debe ser: Content-Type: text/html
```

### Reiniciar todos los servicios

```bash
sudo systemctl restart sentinel-iot
sudo systemctl restart nftables
```

### Reinstalación limpia de la interfaz web

```bash
# Eliminar interfaz anterior
sudo rm -rf /opt/sentinel-iot/frontend

# Copiar nueva interfaz
cd /ruta/sentinel-iot-v2
sudo mkdir -p /opt/sentinel-iot/frontend/public
sudo cp -r frontend/public/* /opt/sentinel-iot/frontend/public/

# Actualizar código del backend
sudo cp backend/app/main.py /opt/sentinel-iot/app/

# Reiniciar
sudo systemctl restart sentinel-iot
```

## Comandos Útiles

```bash
# Ver estado completo
sudo systemctl status sentinel-iot

# Ver logs
sudo journalctl -u sentinel-iot -n 100

# Probar API
curl http://localhost:8000/api/v1/health

# Probar interfaz web
curl http://localhost:8000 | head -20

# Ver qué está escuchando en el puerto 8000
sudo lsof -i :8000

# Ver reglas de firewall
sudo nft list ruleset

# Reiniciar servicio
sudo systemctl restart sentinel-iot
```

## Obtener Ayuda

Si después de seguir esta guía el problema persiste:

1. **Ejecuta el diagnóstico:**
   ```bash
   cd /ruta/sentinel-iot-v2/scripts
   sudo bash diagnose.sh
   ```

2. **Recopila información:**
   ```bash
   sudo journalctl -u sentinel-iot -n 100 > logs.txt
   curl -v http://localhost:8000 > test-conexion.txt 2>&1
   sudo nft list ruleset > firewall-rules.txt
   ```

3. **Consulta la documentación completa:**
   - `docs/TROUBLESHOOTING.md`
   - `SOLUCION_SERVICIO_INACTIVO.md`

---

**Nota:** El script `deploy_frontend.sh` automatiza todo este proceso y es la forma más rápida de resolver el problema.
