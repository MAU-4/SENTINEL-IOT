# Solución: No se asigna IP en la red SENTINEL_IoT

Si la red Wi-Fi **SENTINEL_IoT** aparece pero los dispositivos se quedan en "Obteniendo dirección IP..." sin conectarse, este es un problema de DHCP. Aquí está la solución completa.

## 🔍 Diagnóstico del Problema

El problema ocurre cuando:
- ✅ La red Wi-Fi aparece (hostapd funciona)
- ✅ Puedes ver la red en tu dispositivo
- ✅ Introduces la contraseña correctamente
- ❌ Se queda en "Obteniendo dirección IP..."
- ❌ No se conecta nunca

**Causa:** El servicio DHCP (dnsmasq) no está funcionando correctamente o la interfaz wlan1 no está configurada.

## 🚀 Solución Rápida (Recomendada)

### Ejecutar el script de corrección automática

```bash
cd /ruta/donde/descargaste/sentinel-iot-v2/scripts
sudo bash fix_wifi_dhcp.sh
```

Este script:
- ✅ Diagnostica el problema automáticamente
- ✅ Configura correctamente la interfaz wlan1
- ✅ Corrige la configuración de dnsmasq
- ✅ Configura NAT para acceso a Internet
- ✅ Reinicia los servicios en el orden correcto
- ✅ Verifica que todo funcione

**Tiempo estimado:** 30 segundos

---

## 🔧 Diagnóstico Manual

Si quieres entender qué está fallando antes de aplicar la solución:

### 1. Verificar estado de servicios

```bash
# Ver estado de hostapd (Wi-Fi)
sudo systemctl status hostapd

# Ver estado de dnsmasq (DHCP)
sudo systemctl status dnsmasq
```

**Esperado:**
- hostapd: `active (running)`
- dnsmasq: `active (running)`

### 2. Verificar configuración de wlan1

```bash
# Ver IP de wlan1
ip addr show wlan1

# Debe mostrar: inet 192.168.100.1/24
```

Si no tiene IP o tiene una IP diferente, ese es el problema.

### 3. Verificar que dnsmasq está escuchando

```bash
# Ver procesos de dnsmasq
ps aux | grep dnsmasq

# Ver logs de dnsmasq
sudo journalctl -u dnsmasq -n 50
```

### 4. Verificar archivo de leases

```bash
# Ver dispositivos que han intentado conectarse
cat /var/lib/misc/dnsmasq.leases
```

Si está vacío, dnsmasq no está asignando IPs.

---

## 🛠️ Solución Manual Paso a Paso

Si prefieres corregir manualmente:

### Paso 1: Detener servicios

```bash
sudo systemctl stop hostapd
sudo systemctl stop dnsmasq
```

### Paso 2: Configurar interfaz wlan1

```bash
# Bajar interfaz
sudo ip link set wlan1 down

# Limpiar configuración
sudo ip addr flush dev wlan1

# Levantar interfaz
sudo ip link set wlan1 up

# Asignar IP
sudo ip addr add 192.168.100.1/24 dev wlan1

# Verificar
ip addr show wlan1
```

### Paso 3: Verificar configuración de dnsmasq

```bash
# Editar configuración
sudo nano /etc/dnsmasq.conf
```

Debe contener al menos:

```conf
interface=wlan1
bind-interfaces
dhcp-range=192.168.100.10,192.168.100.250,255.255.255.0,24h
dhcp-option=3,192.168.100.1
dhcp-option=6,192.168.100.1
domain=sentinel.local
local=/sentinel.local/
log-dhcp
```

Guardar con `Ctrl+O`, salir con `Ctrl+X`.

### Paso 4: Crear directorio de leases

```bash
sudo mkdir -p /var/lib/misc
sudo touch /var/lib/misc/dnsmasq.leases
sudo chmod 644 /var/lib/misc/dnsmasq.leases
```

### Paso 5: Habilitar IP forwarding

```bash
# Habilitar temporalmente
sudo sysctl -w net.ipv4.ip_forward=1

# Hacer permanente
echo "net.ipv4.ip_forward=1" | sudo tee -a /etc/sysctl.conf
```

### Paso 6: Configurar NAT

```bash
# Detectar interfaz principal
MAIN_IF=$(ip route | grep default | awk '{print $5}' | head -1)

# Configurar NAT con nftables
sudo nft add table ip nat
sudo nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; }
sudo nft add rule ip nat postrouting oifname "$MAIN_IF" masquerade
```

### Paso 7: Iniciar servicios

```bash
# Iniciar dnsmasq primero
sudo systemctl start dnsmasq
sleep 2

# Verificar que inició correctamente
sudo systemctl status dnsmasq

# Iniciar hostapd
sudo systemctl start hostapd
sleep 2

# Verificar que inició correctamente
sudo systemctl status hostapd
```

### Paso 8: Verificar funcionamiento

```bash
# Ver logs de dnsmasq en tiempo real
sudo journalctl -u dnsmasq -f
```

Ahora intenta conectar un dispositivo. Deberías ver en los logs:

```
dnsmasq-dhcp[xxxx]: DHCPDISCOVER(wlan1) xx:xx:xx:xx:xx:xx
dnsmasq-dhcp[xxxx]: DHCPOFFER(wlan1) 192.168.100.10 xx:xx:xx:xx:xx:xx
dnsmasq-dhcp[xxxx]: DHCPREQUEST(wlan1) 192.168.100.10 xx:xx:xx:xx:xx:xx
dnsmasq-dhcp[xxxx]: DHCPACK(wlan1) 192.168.100.10 xx:xx:xx:xx:xx:xx
```

---

## 🔍 Problemas Comunes y Soluciones

### Problema 1: dnsmasq no inicia

**Error en logs:** `dnsmasq: failed to create listening socket for port 53: Address already in use`

**Causa:** Otro servicio está usando el puerto 53 (DNS).

**Solución:**

```bash
# Ver qué está usando el puerto 53
sudo lsof -i :53

# Si es systemd-resolved, deshabilitarlo
sudo systemctl stop systemd-resolved
sudo systemctl disable systemd-resolved

# Reiniciar dnsmasq
sudo systemctl restart dnsmasq
```

### Problema 2: wlan1 pierde la IP

**Síntoma:** wlan1 tiene IP pero después de un rato la pierde.

**Solución:** Hacer la configuración permanente:

```bash
# Crear archivo de configuración
sudo nano /etc/network/interfaces.d/wlan1
```

Añadir:

```
auto wlan1
iface wlan1 inet static
    address 192.168.100.1
    netmask 255.255.255.0
```

### Problema 3: hostapd no inicia

**Error en logs:** `nl80211: Could not configure driver mode`

**Causa:** Conflicto con NetworkManager o wpa_supplicant.

**Solución:**

```bash
# Desactivar wpa_supplicant en wlan1
sudo systemctl stop wpa_supplicant
sudo systemctl disable wpa_supplicant

# Añadir wlan1 a la lista de interfaces no gestionadas
sudo nano /etc/NetworkManager/NetworkManager.conf
```

Añadir al final:

```ini
[keyfile]
unmanaged-devices=interface-name:wlan1
```

Reiniciar NetworkManager:

```bash
sudo systemctl restart NetworkManager
sudo systemctl restart hostapd
```

### Problema 4: Los dispositivos se conectan pero no tienen Internet

**Síntoma:** Obtienen IP pero no pueden navegar.

**Solución:**

```bash
# Verificar IP forwarding
cat /proc/sys/net/ipv4/ip_forward
# Debe ser: 1

# Verificar NAT
sudo nft list ruleset | grep masquerade
# Debe haber una regla de masquerade

# Si no hay, añadirla
MAIN_IF=$(ip route | grep default | awk '{print $5}' | head -1)
sudo nft add table ip nat
sudo nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; }
sudo nft add rule ip nat postrouting oifname "$MAIN_IF" masquerade
```

---

## ✅ Verificación Final

Después de aplicar la solución, verifica:

### 1. Servicios activos

```bash
sudo systemctl status hostapd dnsmasq
# Ambos deben estar: active (running)
```

### 2. Interfaz configurada

```bash
ip addr show wlan1 | grep "inet "
# Debe mostrar: inet 192.168.100.1/24
```

### 3. DHCP funcionando

```bash
# Conectar un dispositivo y ver logs
sudo journalctl -u dnsmasq -f
# Debes ver mensajes DHCPDISCOVER, DHCPOFFER, DHCPREQUEST, DHCPACK
```

### 4. Dispositivos conectados

```bash
cat /var/lib/misc/dnsmasq.leases
# Debe mostrar los dispositivos conectados
```

### 5. Conectividad

Desde un dispositivo conectado a SENTINEL_IoT:

```bash
# Hacer ping al gateway
ping 192.168.100.1

# Acceder al dashboard
# Abrir navegador: http://192.168.100.1:8000
```

---

## 📋 Información de la Red

Una vez funcionando:

| Parámetro | Valor |
|-----------|-------|
| **SSID** | SENTINEL_IoT |
| **Contraseña** | Ver en `/root/sentinel-wifi-password.txt` |
| **Gateway** | 192.168.100.1 |
| **Rango DHCP** | 192.168.100.10 - 192.168.100.250 |
| **DNS** | 192.168.100.1 (reenvía a 8.8.8.8) |
| **Lease time** | 24 horas |

---

## 🔄 Hacer Permanente

Para que la configuración sobreviva a reinicios:

### 1. Configuración de red persistente

```bash
sudo nano /etc/network/interfaces.d/wlan1
```

Contenido:

```
auto wlan1
iface wlan1 inet static
    address 192.168.100.1
    netmask 255.255.255.0
    post-up /usr/sbin/nft add table ip nat || true
    post-up /usr/sbin/nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; } || true
    post-up /usr/sbin/nft add rule ip nat postrouting oifname eth0 masquerade || true
```

### 2. Habilitar servicios en el arranque

```bash
sudo systemctl enable hostapd
sudo systemctl enable dnsmasq
```

### 3. IP forwarding permanente

```bash
echo "net.ipv4.ip_forward=1" | sudo tee -a /etc/sysctl.conf
```

---

## 🆘 Comandos Útiles

```bash
# Ver logs en tiempo real
sudo journalctl -u dnsmasq -f
sudo journalctl -u hostapd -f

# Ver dispositivos conectados
cat /var/lib/misc/dnsmasq.leases
watch -n 2 cat /var/lib/misc/dnsmasq.leases

# Ver configuración de wlan1
ip addr show wlan1

# Reiniciar servicios
sudo systemctl restart dnsmasq hostapd

# Ver qué está usando puertos
sudo lsof -i :53   # DNS
sudo lsof -i :67   # DHCP

# Probar DHCP manualmente
sudo dhclient -v wlan1

# Ver tabla de NAT
sudo nft list ruleset | grep -A 10 nat
```

---

## 📞 Obtener Ayuda

Si el problema persiste:

1. **Ejecuta el script de corrección:**
   ```bash
   sudo bash fix_wifi_dhcp.sh
   ```

2. **Recopila información:**
   ```bash
   sudo journalctl -u dnsmasq -n 100 > dnsmasq-logs.txt
   sudo journalctl -u hostapd -n 100 > hostapd-logs.txt
   ip addr show wlan1 > wlan1-config.txt
   cat /etc/dnsmasq.conf > dnsmasq-config.txt
   ```

3. **Consulta documentación:**
   - `docs/TROUBLESHOOTING.md`
   - `docs/INSTALLATION.md`

---

**Nota:** El script `fix_wifi_dhcp.sh` automatiza todo este proceso y es la forma más rápida y confiable de resolver el problema.
