# Guía de Scripts para Solucionar Problemas

## 📦 Scripts Disponibles

He creado 3 scripts para resolver tus problemas:

### 1. `fix_detection_and_internet.sh` ⭐ RECOMENDADO
**Soluciona ambos problemas en un solo comando**
- ✅ Configura acceso a Internet (NAT)
- ✅ Detecta dispositivos con IP estática
- ✅ Muestra resumen completo
- ✅ Configuración persistente

### 2. `enable_internet.sh`
**Solo configura acceso a Internet**
- Habilita IP forwarding
- Configura NAT con nftables
- Hace la configuración persistente

### 3. `detect_static_devices.sh`
**Solo detecta dispositivos**
- Escanea tabla ARP
- Escanea leases de DHCP
- Muestra todos los dispositivos conectados
- Exporta a JSON

---

## 🚀 Uso Rápido

### Solución Todo-en-Uno (Recomendado)

```bash
# 1. Copiar el script a tu Raspberry Pi
# Usa SCP, SFTP, o copia manualmente

# 2. Ejecutar
cd ~/sentinel-iot-v2/scripts
sudo bash fix_detection_and_internet.sh
```

**Tiempo:** ~30 segundos

---

## 📋 Instrucciones Detalladas

### Paso 1: Transferir Scripts a la Raspberry Pi

#### Opción A: Usando SCP (desde tu computadora)

```bash
# Descargar el paquete
# (Ya lo tienes: SENTINEL_IoT_v2_RANGOS_IP.tar.gz)

# Copiar a Raspberry Pi
scp SENTINEL_IoT_v2_RANGOS_IP.tar.gz pi@<IP_RASPBERRY>:~

# Conectar por SSH
ssh pi@<IP_RASPBERRY>

# Extraer
tar -xzf SENTINEL_IoT_v2_RANGOS_IP.tar.gz
cd sentinel-iot-v2/scripts
```

#### Opción B: Copiar manualmente

1. Abrir el archivo `fix_detection_and_internet.sh` en tu computadora
2. Copiar todo el contenido
3. En la Raspberry Pi:
   ```bash
   nano ~/fix_detection_and_internet.sh
   # Pegar el contenido
   # Guardar: Ctrl+O, Enter, Ctrl+X
   chmod +x ~/fix_detection_and_internet.sh
   ```

### Paso 2: Ejecutar el Script

```bash
# Ejecutar con sudo
sudo bash ~/fix_detection_and_internet.sh
```

O si estás en el directorio del proyecto:

```bash
cd ~/sentinel-iot-v2/scripts
sudo bash fix_detection_and_internet.sh
```

### Paso 3: Seguir las Instrucciones en Pantalla

El script te guiará paso a paso:

1. Detectará automáticamente la interfaz con Internet
2. Si no puede detectarla, te preguntará cuál usar
3. Configurará todo automáticamente
4. Mostrará un resumen al final

---

## 📊 Salida Esperada

```
╔════════════════════════════════════════════════════════════════╗
║          SENTINEL IoT - Configuración Completa                ║
║                                                                ║
║  Este script configurará:                                     ║
║    • Acceso a Internet (NAT)                                  ║
║    • Detección de dispositivos                                ║
╚════════════════════════════════════════════════════════════════╝

════════════════════════════════════════════════════════════════
  PARTE 1: Configurar Acceso a Internet
════════════════════════════════════════════════════════════════

[1/7] Habilitando IP forwarding...
   ✓ IP forwarding habilitado

[2/7] Detectando interfaz con Internet...
   ✓ Interfaz principal: eth0

[3/7] Configurando NAT...
   ✓ NAT configurado

[4/7] Configurando firewall...
   ✓ Firewall configurado

[5/7] Guardando configuración...
   ✓ Configuración guardada

════════════════════════════════════════════════════════════════
  PARTE 2: Detectar Dispositivos Conectados
════════════════════════════════════════════════════════════════

[6/7] Escaneando dispositivos...
   ✓ Dispositivos detectados: 1

[7/7] Verificando configuración...

   ✓ IP Forwarding: HABILITADO
   ✓ NAT: CONFIGURADO

   Probando conectividad a Internet...
   ✓ Internet: FUNCIONA

════════════════════════════════════════════════════════════════
  Dispositivos Detectados en la Red
════════════════════════════════════════════════════════════════

Tipo     MAC Address        IP Address      Hostname
======== ================== =============== ====================
ARP      aa:bb:cc:dd:ee:ff  192.168.50.15   Unknown

╔════════════════════════════════════════════════════════════════╗
║                  CONFIGURACIÓN COMPLETADA                      ║
╚════════════════════════════════════════════════════════════════╝

Configuración aplicada:
  • Interfaz IoT: wlan1 (192.168.50.1)
  • Interfaz principal: eth0
  • IP Forwarding: Habilitado
  • NAT: Configurado y persistente
  • Dispositivos detectados: 1
```

---

## 🧪 Pruebas Después de Ejecutar

### Desde tu Celular

1. **Probar conexión al gateway:**
   ```
   ping 192.168.50.1
   ```
   **Esperado:** Respuestas exitosas

2. **Probar Internet:**
   ```
   ping 8.8.8.8
   ```
   **Esperado:** Respuestas exitosas

3. **Probar DNS:**
   ```
   ping google.com
   ```
   **Esperado:** Respuestas exitosas

4. **Abrir navegador:**
   ```
   http://google.com
   ```
   **Esperado:** Página carga correctamente

### Desde la Raspberry Pi

```bash
# Ver dispositivos en tiempo real
watch -n 2 'arp -n | grep 192.168.50'

# Ver logs de dnsmasq
sudo journalctl -u dnsmasq -f

# Ver reglas de NAT
sudo nft list ruleset | grep -A 5 nat
```

---

## 🔧 Solución de Problemas

### Problema: "No se detectó interfaz con Internet"

**Solución:**
```bash
# Ver interfaces disponibles
ip link show

# Ver cuál tiene ruta por defecto
ip route

# Ejecutar el script y cuando pregunte, ingresar:
# - eth0 (si usas cable ethernet)
# - wlan0 (si usas Wi-Fi)
```

### Problema: "Internet no funciona en Raspberry Pi"

**Solución:**
```bash
# Verificar conexión de la interfaz principal
ping -c 3 8.8.8.8

# Si no funciona, verificar:
ip addr show eth0  # o wlan0
ip route
```

### Problema: "No se detectan dispositivos"

**Solución:**
```bash
# Verificar que hostapd está corriendo
sudo systemctl status hostapd

# Verificar que wlan1 tiene IP
ip addr show wlan1

# Ver si hay dispositivos conectados
cat /var/lib/misc/dnsmasq.leases
arp -n | grep 192.168.50
```

---

## 📱 Para que el Dashboard Detecte tu Celular

### Opción 1: Cambiar a DHCP (Recomendado)

En tu celular:
1. Ir a: **Configuración** → **Wi-Fi** → **SENTINEL_IoT**
2. Tocar en **Configuración avanzada** o **Modificar red**
3. Cambiar **Configuración IP** de "Estática" a "DHCP"
4. Guardar y reconectar

**Resultado:** El celular aparecerá automáticamente en el dashboard

### Opción 2: Mantener IP Estática y Modificar Backend

Si necesitas mantener IP estática:

```bash
# Editar el código del backend
sudo nano /opt/sentinel-iot/app/services/device_manager.py
```

Buscar la función `scan_network_devices()` y añadir escaneo de ARP:

```python
def scan_network_devices(self):
    """Escanea dispositivos desde DHCP y ARP"""
    devices = []
    
    # 1. Escanear DHCP leases
    if os.path.exists('/var/lib/misc/dnsmasq.leases'):
        with open('/var/lib/misc/dnsmasq.leases', 'r') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 4:
                    devices.append({
                        'mac': parts[1],
                        'ip': parts[2],
                        'hostname': parts[3],
                        'source': 'DHCP'
                    })
    
    # 2. Escanear tabla ARP (NUEVO)
    result = subprocess.run(['arp', '-n'], capture_output=True, text=True)
    for line in result.stdout.split('\n')[1:]:
        if line.strip() and '192.168.50.' in line:
            parts = line.split()
            if len(parts) >= 3:
                ip = parts[0]
                mac = parts[2]
                
                # Solo añadir si no está ya en la lista
                if not any(d['mac'] == mac for d in devices):
                    devices.append({
                        'mac': mac,
                        'ip': ip,
                        'hostname': 'Unknown',
                        'source': 'ARP'
                    })
    
    return devices
```

Reiniciar servicio:

```bash
sudo systemctl restart sentinel-iot
```

---

## 📦 Contenido del Paquete

El archivo `SENTINEL_IoT_v2_RANGOS_IP.tar.gz` contiene:

```
sentinel-iot-v2/
├── scripts/
│   ├── fix_detection_and_internet.sh  ⭐ Script principal
│   ├── enable_internet.sh             Solo Internet
│   ├── detect_static_devices.sh       Solo detección
│   ├── fix_wifi_complete.sh           Configurar Wi-Fi
│   └── ...
├── backend/                           Código del backend
├── frontend/                          Código del frontend
├── docs/                              Documentación
├── RANGOS_IP_ALTERNATIVOS.md         Guía de rangos IP
└── GUIA_SCRIPTS_SOLUCION.md          Este archivo
```

---

## ✅ Checklist

- [ ] Scripts transferidos a Raspberry Pi
- [ ] Script `fix_detection_and_internet.sh` ejecutado
- [ ] Configuración completada sin errores
- [ ] Internet funciona desde Raspberry Pi
- [ ] Celular conectado a SENTINEL_IoT
- [ ] Internet funciona desde celular
- [ ] Dispositivos detectados (ejecutar `detect_static_devices.sh`)
- [ ] Dashboard accesible en `http://192.168.50.1:8000`

---

## 🆘 Ayuda Adicional

Si tienes problemas:

1. **Ejecuta el script de diagnóstico:**
   ```bash
   sudo bash scripts/diagnose.sh
   ```

2. **Ver logs:**
   ```bash
   sudo journalctl -u dnsmasq -n 50
   sudo journalctl -u hostapd -n 50
   ```

3. **Comparte la salida** del script y los logs para ayuda específica

---

## 🎯 Resumen

**Comando único para resolver todo:**

```bash
sudo bash ~/sentinel-iot-v2/scripts/fix_detection_and_internet.sh
```

Esto configurará:
- ✅ Acceso a Internet para dispositivos IoT
- ✅ Detección de dispositivos (DHCP + ARP)
- ✅ Configuración persistente (sobrevive reinicios)
- ✅ Resumen completo de la configuración

**Tiempo total:** ~30 segundos
