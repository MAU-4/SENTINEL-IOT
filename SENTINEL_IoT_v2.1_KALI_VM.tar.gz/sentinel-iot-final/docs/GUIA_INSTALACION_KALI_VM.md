# Guía de Instalación de SENTINEL IoT en Kali Linux (Máquina Virtual)

**Versión**: 2.1-VM  
**Fecha**: 2025-11-08  
**Autor**: Manus AI

## 📋 Requisitos Previos

### Hardware de la Máquina Virtual
- **RAM**: Mínimo 2 GB (recomendado 4 GB)
- **CPU**: 2 núcleos o más
- **Disco**: 20 GB de espacio libre
- **Red**: Al menos 1 interfaz de red (2 recomendadas para mejor aislamiento)

### Software
- **Kali Linux** (última versión) instalado en:
  - VirtualBox
  - VMware
  - QEMU/KVM
  - Hyper-V
- **Acceso root** (sudo)
- **Conexión a Internet** durante la instalación

---

## 🚀 Instalación Paso a Paso

### Paso 1: Preparar la Máquina Virtual

#### Opción A: VirtualBox
1. Crear una nueva VM con Kali Linux
2. **Configurar red**:
   - Adaptador 1: **NAT** o **Bridged** (para Internet)
   - Adaptador 2 (opcional): **Red Interna** o **Host-Only** (para red IoT aislada)

#### Opción B: VMware
1. Crear una nueva VM con Kali Linux
2. **Configurar red**:
   - Adaptador 1: **NAT** o **Bridged**
   - Adaptador 2 (opcional): **Custom (VMnet2)** para red IoT

### Paso 2: Descargar el Proyecto

```bash
# Opción 1: Si tienes el tarball
cd ~
tar -xzf SENTINEL_IoT_v2.1_CONTROL_INTERNET.tar.gz
cd sentinel-iot-final

# Opción 2: Si tienes el proyecto en un directorio
cd /ruta/al/proyecto/sentinel-iot-final
```

### Paso 3: Copiar el Script de Instalación

```bash
# Copiar el script al directorio del proyecto
cp /ruta/al/install_kali_vm.sh ~/sentinel-iot-final/scripts/installation/

# Dar permisos de ejecución
chmod +x ~/sentinel-iot-final/scripts/installation/install_kali_vm.sh
```

### Paso 4: Ejecutar la Instalación

```bash
cd ~/sentinel-iot-final/scripts/installation
sudo bash install_kali_vm.sh
```

El script te preguntará:
- **¿Qué interfaz usar para la red IoT?**
  - Si tienes 2 interfaces: elige la segunda (ej: `eth1`, `ens34`)
  - Si solo tienes 1: usa la principal (ej: `eth0`)

### Paso 5: Verificar la Instalación

```bash
# Ver estado de los servicios
sudo systemctl status sentinel-backend
sudo systemctl status dnsmasq

# Ver logs del backend
sudo journalctl -u sentinel-backend -f

# Ver configuración de red
ip addr show
```

---

## 🌐 Acceso al Dashboard

### Desde la Misma VM
```bash
# Abrir navegador en Kali
firefox http://192.168.50.1:8000
```

### Desde tu Máquina Host (si configuraste red Host-Only o Bridged)
```
http://192.168.50.1:8000
```

---

## 🔧 Configuración de Dispositivos IoT

### Opción 1: DHCP Automático (Recomendado)
Los dispositivos que se conecten a la interfaz IoT recibirán automáticamente:
- **IP**: Entre `192.168.50.100` y `192.168.50.200`
- **Gateway**: `192.168.50.1`
- **DNS**: `192.168.50.1`

### Opción 2: IP Estática Manual
Si prefieres configurar manualmente:
- **IP**: `192.168.50.X` (donde X es entre 2-99 o 201-254)
- **Máscara**: `255.255.255.0`
- **Gateway**: `192.168.50.1`
- **DNS**: `8.8.8.8`

---

## 🧪 Pruebas de Funcionalidad

### 1. Probar Detección de Dispositivos
```bash
# Conectar un dispositivo a la red IoT
# Luego verificar en el dashboard o con:
cat /var/lib/misc/dnsmasq.leases
```

### 2. Probar Control de Internet
1. Abrir dashboard: `http://192.168.50.1:8000`
2. Hacer clic en el botón **"Internet: ON"**
3. Verificar que cambia a **"Internet: OFF"**
4. Probar conectividad desde un dispositivo IoT

### 3. Verificar Reglas de nftables
```bash
sudo nft list ruleset
```

---

## 🐛 Solución de Problemas

### Problema 1: "No se puede acceder al dashboard"

**Solución**:
```bash
# Verificar que el backend está corriendo
sudo systemctl status sentinel-backend

# Si no está activo, reiniciarlo
sudo systemctl restart sentinel-backend

# Ver logs para errores
sudo journalctl -u sentinel-backend -n 50
```

### Problema 2: "Los dispositivos no obtienen IP"

**Solución**:
```bash
# Verificar dnsmasq
sudo systemctl status dnsmasq

# Ver logs de dnsmasq
sudo journalctl -u dnsmasq -n 50

# Reiniciar dnsmasq
sudo systemctl restart dnsmasq
```

### Problema 3: "No hay acceso a Internet desde dispositivos IoT"

**Solución**:
```bash
# Verificar IP forwarding
sysctl net.ipv4.ip_forward
# Debe devolver: net.ipv4.ip_forward = 1

# Verificar reglas de NAT
sudo nft list table ip nat

# Si no hay reglas, reconfigurar
sudo nft add table ip nat
sudo nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; }
sudo nft add rule ip nat postrouting oifname "eth0" masquerade
```

### Problema 4: "Error de dependencias de Python"

**Solución**:
```bash
# Reinstalar dependencias
cd /opt/sentinel-iot
sudo ./venv/bin/pip install --upgrade pip
sudo ./venv/bin/pip install fastapi uvicorn scapy python-multipart
```

---

## 📊 Comandos Útiles

### Ver Dispositivos Conectados
```bash
cat /var/lib/misc/dnsmasq.leases
```

### Ver Logs en Tiempo Real
```bash
# Backend
sudo journalctl -u sentinel-backend -f

# dnsmasq
sudo journalctl -u dnsmasq -f
```

### Reiniciar Servicios
```bash
sudo systemctl restart sentinel-backend
sudo systemctl restart dnsmasq
```

### Ver Reglas de Firewall
```bash
sudo nft list ruleset
```

### Habilitar/Deshabilitar Internet Manualmente
```bash
# Deshabilitar
sudo nft add rule inet filter forward drop

# Habilitar (eliminar la regla)
sudo nft delete rule inet filter forward handle <número>
```

---

## 🎯 Diferencias con la Instalación en Raspberry Pi

| Aspecto | Raspberry Pi | Kali Linux VM |
|:--------|:-------------|:--------------|
| **Interfaces de red** | `wlan0`, `wlan1` (Wi-Fi) | `eth0`, `eth1`, etc. (Ethernet virtual) |
| **Punto de acceso Wi-Fi** | Usa `hostapd` | **No usa hostapd** (red cableada virtual) |
| **Arquitectura** | ARM (32/64-bit) | x86_64 |
| **Propósito** | Producción | **Pruebas y desarrollo** |
| **Aislamiento** | Red Wi-Fi física | Red virtual (depende de configuración de VM) |

---

## ✅ Verificación Final

Si todo está correcto, deberías ver:

1. ✅ Dashboard accesible en `http://192.168.50.1:8000`
2. ✅ Botón de control de Internet funcionando
3. ✅ Sección de dispositivos conectados visible
4. ✅ Reglas de nftables mostradas en tiempo real
5. ✅ Dispositivos IoT con acceso a Internet (cuando está habilitado)

---

## 📞 Soporte

Si encuentras problemas:
1. Revisa los logs: `sudo journalctl -u sentinel-backend -n 100`
2. Verifica la configuración de red de la VM
3. Asegúrate de que las interfaces de red estén activas: `ip addr show`

---

**¡SENTINEL IoT está listo para pruebas en tu VM de Kali Linux!** 🚀
