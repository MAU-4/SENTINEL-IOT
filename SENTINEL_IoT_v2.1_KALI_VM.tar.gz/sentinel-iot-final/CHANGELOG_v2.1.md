# CHANGELOG - SENTINEL IoT v2.1

**Fecha de Lanzamiento**: 2025-11-08  
**Versión**: 2.1.0

## Nuevas Funcionalidades

### 🌐 Control de Acceso a Internet

Se ha implementado un sistema completo de control ON/OFF para el acceso a Internet de toda la red IoT.

#### Backend
- **Nuevo servicio**: `internet_controller.py`
  - Clase `InternetController` para gestionar nftables
  - Métodos: `get_status()`, `enable()`, `disable()`, `toggle()`
  - Detección automática del estado actual
  - Gestión segura de reglas de firewall

- **Nuevos endpoints API**: `internet.py`
  - `GET /api/v1/internet/status` - Obtener estado actual
  - `POST /api/v1/internet/enable` - Habilitar Internet
  - `POST /api/v1/internet/disable` - Deshabilitar Internet
  - `POST /api/v1/internet/toggle` - Cambiar estado (ON/OFF)
  - `GET /api/v1/internet/rules` - Listar reglas activas

#### Frontend
- **Nueva sección en dashboard**: "Control de Acceso a Internet"
  - Botón toggle visual con animación
  - Indicadores de estado con colores (verde=ON, rojo=OFF)
  - Mensajes claros del estado actual
  - Actualización automática cada 5 segundos

- **Nueva sección de visualización**: "Reglas de nftables"
  - Muestra las reglas activas de control de Internet
  - Actualización en tiempo real al cambiar el estado
  - Formato legible tipo terminal
  - Scroll para ver todas las reglas

### 📦 Script de Instalación Alternativo

- **Nuevo script**: `install_static_ip.sh`
  - Instalación completa sin servidor DHCP (dnsmasq)
  - Para usuarios que prefieren IPs estáticas
  - Configuración manual de dispositivos IoT
  - Misma funcionalidad que el script principal

## Mejoras

### Dashboard
- Diseño responsive mejorado
- Mejor organización de secciones
- Actualización más frecuente (5 segundos en lugar de 10)
- Nuevo enlace en "Enlaces Rápidos" para el estado de Internet

### Backend
- Integración del nuevo router en `main.py`
- Mejor manejo de errores en operaciones de nftables
- Logging mejorado para operaciones de Internet

### Documentación
- `DOCUMENTACION_CONTROL_INTERNET.md` - Documentación técnica completa
- `GUIA_CONTROL_INTERNET.md` - Guía de usuario paso a paso
- `CHANGELOG_v2.1.md` - Este archivo de cambios

## Archivos Modificados

### Backend
- `backend/app/main.py` - Registro del nuevo router
- `backend/app/services/internet_controller.py` - **NUEVO**
- `backend/app/api/internet.py` - **NUEVO**

### Frontend
- `frontend/public/index.html` - Dashboard actualizado con nuevas secciones

### Scripts
- `scripts/installation/install_static_ip.sh` - **NUEVO**

### Documentación
- `DOCUMENTACION_CONTROL_INTERNET.md` - **NUEVO**
- `GUIA_CONTROL_INTERNET.md` - **NUEVO**
- `CHANGELOG_v2.1.md` - **NUEVO**

## Compatibilidad

Esta versión es **totalmente compatible** con la versión 2.0. No se han eliminado ni modificado funcionalidades existentes, solo se han añadido nuevas características.

### Migración desde v2.0

Si ya tienes SENTINEL IoT v2.0 instalado:

1. Detén el servicio:
   ```bash
   sudo systemctl stop sentinel-iot
   ```

2. Realiza un backup de tu configuración:
   ```bash
   sudo cp -r /opt/sentinel-iot /opt/sentinel-iot.backup
   ```

3. Copia los nuevos archivos:
   ```bash
   # Backend
   sudo cp backend/app/services/internet_controller.py /opt/sentinel-iot/backend/app/services/
   sudo cp backend/app/api/internet.py /opt/sentinel-iot/backend/app/api/
   sudo cp backend/app/main.py /opt/sentinel-iot/backend/app/
   
   # Frontend
   sudo cp frontend/public/index.html /opt/sentinel-iot/frontend/public/
   ```

4. Reinicia el servicio:
   ```bash
   sudo systemctl start sentinel-iot
   ```

5. Verifica que todo funciona:
   ```bash
   sudo systemctl status sentinel-iot
   ```

## Requisitos del Sistema

Los requisitos son los mismos que en la versión 2.0:

- **Hardware**: Raspberry Pi 3 o superior
- **Sistema Operativo**: Raspberry Pi OS Bookworm (Debian 12)
- **Python**: 3.11 o superior
- **Dependencias**: hostapd, nftables, Python packages (ver requirements.txt)

## Problemas Conocidos

No se han identificado problemas en esta versión. Si encuentras algún bug, por favor repórtalo.

## Próximas Versiones

Funcionalidades planificadas para futuras versiones:

- Programación de horarios para el control de Internet
- Notificaciones por email/Telegram cuando se detectan dispositivos nuevos
- Integración con Home Assistant
- Análisis de tráfico con gráficos históricos
- Control de Internet por dispositivo individual

## Agradecimientos

Esta versión fue desarrollada en respuesta a las sugerencias y necesidades del usuario, priorizando la simplicidad y la transparencia en el control de la red IoT.

---

**Desarrollado por**: Manus AI  
**Proyecto**: SENTINEL IoT  
**Licencia**: MIT
