"""
Motor de Machine Learning para detección de anomalías
"""
import numpy as np
import logging
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
import pickle
import os

logger = logging.getLogger(__name__)


@dataclass
class TrafficSample:
    """Muestra de tráfico para análisis"""
    timestamp: datetime
    device_mac: str
    bytes_sent: int
    bytes_received: int
    packets_sent: int
    packets_received: int
    connections: int
    unique_destinations: int
    protocols: Dict[str, int]  # {"tcp": 10, "udp": 5}
    ports: List[int]
    
    def to_features(self) -> np.ndarray:
        """Convierte a vector de features"""
        features = [
            self.bytes_sent,
            self.bytes_received,
            self.packets_sent,
            self.packets_received,
            self.connections,
            self.unique_destinations,
            len(self.protocols),
            len(self.ports),
            # Ratios
            self.bytes_sent / max(self.packets_sent, 1),  # Avg packet size sent
            self.bytes_received / max(self.packets_received, 1),  # Avg packet size received
            self.packets_sent / max(self.connections, 1),  # Packets per connection
        ]
        return np.array(features)


class AnomalyDetector:
    """Detector de anomalías con Machine Learning"""
    
    def __init__(self, model_path: str = "./data/models"):
        self.model_path = model_path
        self.model = None
        self.scaler = None
        self.is_trained = False
        self.training_samples: List[TrafficSample] = []
        self.anomaly_threshold = 0.85
        
        # Crear directorio si no existe
        os.makedirs(model_path, exist_ok=True)
        
        # Intentar cargar modelo existente
        self.load_model()
    
    def add_sample(self, sample: TrafficSample):
        """Añade una muestra para entrenamiento"""
        self.training_samples.append(sample)
        logger.debug(f"Muestra añadida. Total: {len(self.training_samples)}")
    
    def train(self, min_samples: int = 1000) -> bool:
        """Entrena el modelo de detección de anomalías"""
        try:
            if len(self.training_samples) < min_samples:
                logger.warning(f"Insuficientes muestras para entrenar: {len(self.training_samples)}/{min_samples}")
                return False
            
            # Convertir muestras a matriz de features
            X = np.array([sample.to_features() for sample in self.training_samples])
            
            # Normalizar features
            from sklearn.preprocessing import StandardScaler
            self.scaler = StandardScaler()
            X_scaled = self.scaler.fit_transform(X)
            
            # Entrenar modelo (Isolation Forest)
            from sklearn.ensemble import IsolationForest
            self.model = IsolationForest(
                contamination=0.1,  # 10% de anomalías esperadas
                random_state=42,
                n_estimators=100
            )
            self.model.fit(X_scaled)
            
            self.is_trained = True
            logger.info(f"Modelo entrenado con {len(self.training_samples)} muestras")
            
            # Guardar modelo
            self.save_model()
            
            return True
            
        except Exception as e:
            logger.error(f"Error al entrenar modelo: {e}")
            return False
    
    def predict(self, sample: TrafficSample) -> Tuple[bool, float]:
        """
        Predice si una muestra es anómala
        
        Returns:
            Tuple[bool, float]: (is_anomaly, anomaly_score)
        """
        try:
            if not self.is_trained:
                logger.warning("Modelo no entrenado")
                return False, 0.0
            
            # Convertir a features
            X = sample.to_features().reshape(1, -1)
            
            # Normalizar
            X_scaled = self.scaler.transform(X)
            
            # Predecir
            prediction = self.model.predict(X_scaled)[0]
            anomaly_score = self.model.score_samples(X_scaled)[0]
            
            # Convertir score a probabilidad (0-1)
            # Score negativo más grande = más anómalo
            anomaly_prob = 1 / (1 + np.exp(anomaly_score))
            
            is_anomaly = prediction == -1 or anomaly_prob > self.anomaly_threshold
            
            logger.debug(f"Predicción: anomaly={is_anomaly}, score={anomaly_prob:.3f}")
            
            return is_anomaly, anomaly_prob
            
        except Exception as e:
            logger.error(f"Error al predecir: {e}")
            return False, 0.0
    
    def detect_anomalies_batch(self, samples: List[TrafficSample]) -> List[Tuple[TrafficSample, bool, float]]:
        """Detecta anomalías en un lote de muestras"""
        results = []
        
        for sample in samples:
            is_anomaly, score = self.predict(sample)
            results.append((sample, is_anomaly, score))
        
        return results
    
    def save_model(self) -> bool:
        """Guarda el modelo entrenado"""
        try:
            if not self.is_trained:
                logger.warning("No hay modelo para guardar")
                return False
            
            model_file = os.path.join(self.model_path, "anomaly_detector.pkl")
            scaler_file = os.path.join(self.model_path, "scaler.pkl")
            
            with open(model_file, 'wb') as f:
                pickle.dump(self.model, f)
            
            with open(scaler_file, 'wb') as f:
                pickle.dump(self.scaler, f)
            
            logger.info(f"Modelo guardado en: {model_file}")
            return True
            
        except Exception as e:
            logger.error(f"Error al guardar modelo: {e}")
            return False
    
    def load_model(self) -> bool:
        """Carga un modelo previamente entrenado"""
        try:
            model_file = os.path.join(self.model_path, "anomaly_detector.pkl")
            scaler_file = os.path.join(self.model_path, "scaler.pkl")
            
            if not os.path.exists(model_file) or not os.path.exists(scaler_file):
                logger.info("No hay modelo guardado")
                return False
            
            with open(model_file, 'rb') as f:
                self.model = pickle.load(f)
            
            with open(scaler_file, 'rb') as f:
                self.scaler = pickle.load(f)
            
            self.is_trained = True
            logger.info("Modelo cargado correctamente")
            return True
            
        except Exception as e:
            logger.error(f"Error al cargar modelo: {e}")
            return False
    
    def get_statistics(self) -> Dict:
        """Obtiene estadísticas del modelo"""
        return {
            "is_trained": self.is_trained,
            "training_samples": len(self.training_samples),
            "anomaly_threshold": self.anomaly_threshold,
            "model_type": "IsolationForest" if self.model else None
        }


class DeviceClassifier:
    """Clasificador de dispositivos IoT"""
    
    # Features típicos por tipo de dispositivo
    DEVICE_PROFILES = {
        "camera": {
            "avg_bytes_sent": 1000000,  # 1MB/s (streaming)
            "avg_bytes_received": 10000,
            "protocols": ["tcp", "udp"],
            "common_ports": [80, 443, 554, 8080]  # HTTP, HTTPS, RTSP
        },
        "thermostat": {
            "avg_bytes_sent": 1000,
            "avg_bytes_received": 1000,
            "protocols": ["tcp"],
            "common_ports": [80, 443, 8883]  # HTTP, HTTPS, MQTT
        },
        "light": {
            "avg_bytes_sent": 500,
            "avg_bytes_received": 500,
            "protocols": ["udp", "tcp"],
            "common_ports": [80, 443, 5353]  # HTTP, HTTPS, mDNS
        },
        "speaker": {
            "avg_bytes_sent": 10000,
            "avg_bytes_received": 500000,  # 500KB/s (audio streaming)
            "protocols": ["tcp", "udp"],
            "common_ports": [80, 443, 5353, 8009]
        },
        "sensor": {
            "avg_bytes_sent": 100,
            "avg_bytes_received": 100,
            "protocols": ["tcp", "udp"],
            "common_ports": [80, 443, 1883, 8883]  # HTTP, HTTPS, MQTT
        }
    }
    
    def __init__(self):
        self.model = None
        self.is_trained = False
    
    def classify(self, sample: TrafficSample) -> Tuple[str, float]:
        """
        Clasifica el tipo de dispositivo basado en tráfico
        
        Returns:
            Tuple[str, float]: (device_type, confidence)
        """
        try:
            # Calcular similitud con cada perfil
            similarities = {}
            
            for device_type, profile in self.DEVICE_PROFILES.items():
                similarity = self._calculate_similarity(sample, profile)
                similarities[device_type] = similarity
            
            # Obtener tipo con mayor similitud
            best_match = max(similarities.items(), key=lambda x: x[1])
            device_type, confidence = best_match
            
            # Si la confianza es baja, clasificar como unknown
            if confidence < 0.5:
                return "unknown", confidence
            
            return device_type, confidence
            
        except Exception as e:
            logger.error(f"Error al clasificar dispositivo: {e}")
            return "unknown", 0.0
    
    def _calculate_similarity(self, sample: TrafficSample, profile: Dict) -> float:
        """Calcula la similitud entre una muestra y un perfil"""
        scores = []
        
        # Similitud en bytes enviados
        bytes_sent_ratio = min(
            sample.bytes_sent / profile["avg_bytes_sent"],
            profile["avg_bytes_sent"] / max(sample.bytes_sent, 1)
        )
        scores.append(bytes_sent_ratio)
        
        # Similitud en bytes recibidos
        bytes_received_ratio = min(
            sample.bytes_received / profile["avg_bytes_received"],
            profile["avg_bytes_received"] / max(sample.bytes_received, 1)
        )
        scores.append(bytes_received_ratio)
        
        # Similitud en protocolos
        common_protocols = set(sample.protocols.keys()) & set(profile["protocols"])
        protocol_score = len(common_protocols) / len(profile["protocols"])
        scores.append(protocol_score)
        
        # Similitud en puertos
        common_ports = set(sample.ports) & set(profile["common_ports"])
        port_score = len(common_ports) / max(len(profile["common_ports"]), 1)
        scores.append(port_score)
        
        # Promedio de scores
        return np.mean(scores)


# Instancias globales
anomaly_detector = AnomalyDetector()
device_classifier = DeviceClassifier()
