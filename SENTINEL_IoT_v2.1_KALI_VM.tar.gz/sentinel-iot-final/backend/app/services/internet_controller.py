"""
Servicio de control de acceso a Internet
Gestiona el estado ON/OFF del acceso a Internet mediante nftables
"""

import subprocess
import logging
from typing import Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class InternetController:
    """
    Controlador para gestionar el acceso a Internet de la red IoT
    """
    
    def __init__(self, iot_network: str = "192.168.50.0/24", main_interface: str = "eth0"):
        self.iot_network = iot_network
        self.main_interface = main_interface
        self.table_name = "sentinel"
        self.chain_name = "forward"
        self.rule_handle = None
        
    def get_status(self) -> Dict[str, any]:
        """
        Obtiene el estado actual del acceso a Internet
        
        Returns:
            Dict con enabled (bool), message (str), last_modified (str)
        """
        try:
            # Verificar si existe la regla de Internet en nftables
            result = subprocess.run(
                ["nft", "list", "chain", "ip", self.table_name, self.chain_name],
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode != 0:
                # La tabla o chain no existe, Internet está deshabilitado
                return {
                    "enabled": False,
                    "message": "Acceso a Internet bloqueado",
                    "last_modified": None
                }
            
            # Buscar la regla de Internet en la salida
            output = result.stdout
            
            # La regla de Internet contiene: oifname y el nombre de la interfaz principal
            internet_rule_exists = (
                f'oifname "{self.main_interface}"' in output and
                f'ip saddr {self.iot_network}' in output
            )
            
            return {
                "enabled": internet_rule_exists,
                "message": "Acceso a Internet permitido" if internet_rule_exists else "Acceso a Internet bloqueado",
                "last_modified": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error al obtener estado de Internet: {e}")
            return {
                "enabled": False,
                "message": f"Error: {str(e)}",
                "last_modified": None
            }
    
    def enable(self) -> Dict[str, any]:
        """
        Habilita el acceso a Internet
        
        Returns:
            Dict con success (bool), message (str)
        """
        try:
            # Verificar si ya está habilitado
            status = self.get_status()
            if status["enabled"]:
                return {
                    "success": True,
                    "message": "El acceso a Internet ya estaba habilitado",
                    "enabled": True
                }
            
            # Crear tabla si no existe
            subprocess.run(
                ["nft", "add", "table", "ip", self.table_name],
                capture_output=True,
                check=False
            )
            
            # Crear chain si no existe
            subprocess.run(
                ["nft", "add", "chain", "ip", self.table_name, self.chain_name,
                 "{ type filter hook forward priority 0 \\; policy accept \\; }"],
                capture_output=True,
                check=False
            )
            
            # Agregar regla para permitir Internet (salida)
            result = subprocess.run(
                ["nft", "add", "rule", "ip", self.table_name, self.chain_name,
                 "ip", "saddr", self.iot_network,
                 "oifname", self.main_interface,
                 "accept"],
                capture_output=True,
                text=True,
                check=True
            )
            
            # Agregar regla para permitir respuestas (entrada)
            subprocess.run(
                ["nft", "add", "rule", "ip", self.table_name, self.chain_name,
                 "ip", "daddr", self.iot_network,
                 "iifname", self.main_interface,
                 "ct", "state", "related,established",
                 "accept"],
                capture_output=True,
                text=True,
                check=True
            )
            
            logger.info(f"Acceso a Internet habilitado para {self.iot_network}")
            
            return {
                "success": True,
                "message": "Acceso a Internet habilitado correctamente",
                "enabled": True
            }
            
        except subprocess.CalledProcessError as e:
            error_msg = f"Error al habilitar Internet: {e.stderr}"
            logger.error(error_msg)
            return {
                "success": False,
                "message": error_msg,
                "enabled": False
            }
        except Exception as e:
            error_msg = f"Error inesperado: {str(e)}"
            logger.error(error_msg)
            return {
                "success": False,
                "message": error_msg,
                "enabled": False
            }
    
    def disable(self) -> Dict[str, any]:
        """
        Deshabilita el acceso a Internet
        
        Returns:
            Dict con success (bool), message (str)
        """
        try:
            # Verificar si ya está deshabilitado
            status = self.get_status()
            if not status["enabled"]:
                return {
                    "success": True,
                    "message": "El acceso a Internet ya estaba bloqueado",
                    "enabled": False
                }
            
            # Flush (eliminar) todas las reglas de la chain
            # Esto es más seguro que intentar eliminar reglas específicas
            result = subprocess.run(
                ["nft", "flush", "chain", "ip", self.table_name, self.chain_name],
                capture_output=True,
                text=True,
                check=True
            )
            
            logger.info(f"Acceso a Internet deshabilitado para {self.iot_network}")
            
            return {
                "success": True,
                "message": "Acceso a Internet bloqueado correctamente",
                "enabled": False
            }
            
        except subprocess.CalledProcessError as e:
            error_msg = f"Error al deshabilitar Internet: {e.stderr}"
            logger.error(error_msg)
            return {
                "success": False,
                "message": error_msg,
                "enabled": status.get("enabled", False)
            }
        except Exception as e:
            error_msg = f"Error inesperado: {str(e)}"
            logger.error(error_msg)
            return {
                "success": False,
                "message": error_msg,
                "enabled": status.get("enabled", False)
            }
    
    def toggle(self) -> Dict[str, any]:
        """
        Cambia el estado del acceso a Internet (ON/OFF)
        
        Returns:
            Dict con success (bool), message (str), enabled (bool)
        """
        try:
            status = self.get_status()
            
            if status["enabled"]:
                # Está habilitado, deshabilitar
                return self.disable()
            else:
                # Está deshabilitado, habilitar
                return self.enable()
                
        except Exception as e:
            error_msg = f"Error al cambiar estado: {str(e)}"
            logger.error(error_msg)
            return {
                "success": False,
                "message": error_msg,
                "enabled": False
            }
    
    def get_rules(self) -> list:
        """
        Obtiene todas las reglas de nftables relacionadas con Internet
        
        Returns:
            Lista de reglas en formato legible
        """
        try:
            result = subprocess.run(
                ["nft", "list", "chain", "ip", self.table_name, self.chain_name],
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode != 0:
                return []
            
            rules = []
            lines = result.stdout.split('\n')
            
            for line in lines:
                line = line.strip()
                if line and not line.startswith('#') and not line.startswith('table') and not line.startswith('chain') and not line.startswith('{') and not line.startswith('}'):
                    rules.append(line)
            
            return rules
            
        except Exception as e:
            logger.error(f"Error al obtener reglas: {e}")
            return []


# Instancia global del controlador
internet_controller = InternetController()
