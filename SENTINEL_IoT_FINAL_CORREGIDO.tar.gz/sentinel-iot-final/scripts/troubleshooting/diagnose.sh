#!/bin/bash
#
# SENTINEL IoT v2.0 - Script de Diagnóstico
#
# Este script verifica el estado del sistema y ayuda a identificar problemas
#

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                                                           ║${NC}"
echo -e "${BLUE}║         SENTINEL IoT v2.0 - Diagnóstico                  ║${NC}"
echo -e "${BLUE}║                                                           ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Función para verificar
check_item() {
    local name=$1
    local command=$2
    
    if eval "$command" > /dev/null 2>&1; then
        echo -e "  ${GREEN}✓${NC} $name"
        return 0
    else
        echo -e "  ${RED}✗${NC} $name"
        return 1
    fi
}

# 1. Verificar archivos de instalación
echo -e "${YELLOW}1. Archivos de instalación:${NC}"
check_item "Directorio principal" "[ -d /opt/sentinel-iot ]"
check_item "Archivo main.py" "[ -f /opt/sentinel-iot/app/main.py ]"
check_item "Entorno virtual" "[ -d /opt/sentinel-iot/venv ]"
check_item "Directorio de datos" "[ -d /var/lib/sentinel-iot ]"
echo ""

# 2. Verificar servicios
echo -e "${YELLOW}2. Estado de servicios:${NC}"
check_item "sentinel-iot activo" "systemctl is-active --quiet sentinel-iot"
check_item "hostapd activo" "systemctl is-active --quiet hostapd"
check_item "dnsmasq activo" "systemctl is-active --quiet dnsmasq"
check_item "nftables activo" "systemctl is-active --quiet nftables"
echo ""

# 3. Verificar red
echo -e "${YELLOW}3. Configuración de red:${NC}"
check_item "Interfaz eth0 existe" "ip link show eth0"
check_item "Interfaz wlan1 existe" "ip link show wlan1"
check_item "wlan1 tiene IP" "ip addr show wlan1 | grep -q 192.168.100.1"
check_item "IP forwarding habilitado" "[ $(cat /proc/sys/net/ipv4/ip_forward) -eq 1 ]"
echo ""

# 4. Verificar Python
echo -e "${YELLOW}4. Entorno Python:${NC}"
if [ -f /opt/sentinel-iot/venv/bin/python ]; then
    PYTHON_VERSION=$(/opt/sentinel-iot/venv/bin/python --version 2>&1)
    echo -e "  ${GREEN}✓${NC} Python: $PYTHON_VERSION"
    
    # Verificar módulos
    /opt/sentinel-iot/venv/bin/python -c "import fastapi" 2>/dev/null && \
        echo -e "  ${GREEN}✓${NC} fastapi instalado" || \
        echo -e "  ${RED}✗${NC} fastapi NO instalado"
    
    /opt/sentinel-iot/venv/bin/python -c "import uvicorn" 2>/dev/null && \
        echo -e "  ${GREEN}✓${NC} uvicorn instalado" || \
        echo -e "  ${RED}✗${NC} uvicorn NO instalado"
    
    /opt/sentinel-iot/venv/bin/python -c "import sqlalchemy" 2>/dev/null && \
        echo -e "  ${GREEN}✓${NC} sqlalchemy instalado" || \
        echo -e "  ${RED}✗${NC} sqlalchemy NO instalado"
else
    echo -e "  ${RED}✗${NC} Entorno virtual no encontrado"
fi
echo ""

# 5. Verificar puertos
echo -e "${YELLOW}5. Puertos de red:${NC}"
if netstat -tlnp 2>/dev/null | grep -q ":8000"; then
    echo -e "  ${GREEN}✓${NC} Puerto 8000 en uso (API)"
    PROCESS=$(netstat -tlnp 2>/dev/null | grep ":8000" | awk '{print $7}')
    echo -e "    Proceso: $PROCESS"
else
    echo -e "  ${RED}✗${NC} Puerto 8000 no está en uso"
fi
echo ""

# 6. Probar API
echo -e "${YELLOW}6. Prueba de API:${NC}"
if curl -s http://localhost:8000/api/v1/health > /dev/null 2>&1; then
    echo -e "  ${GREEN}✓${NC} API responde correctamente"
    RESPONSE=$(curl -s http://localhost:8000/api/v1/health)
    echo -e "    Respuesta: $RESPONSE"
else
    echo -e "  ${RED}✗${NC} API no responde"
fi
echo ""

# 7. Logs recientes
echo -e "${YELLOW}7. Últimos logs del servicio:${NC}"
if systemctl is-active --quiet sentinel-iot; then
    echo -e "  ${GREEN}Servicio activo${NC}"
else
    echo -e "  ${RED}Servicio inactivo - Mostrando últimos 10 logs:${NC}"
    journalctl -u sentinel-iot -n 10 --no-pager | sed 's/^/    /'
fi
echo ""

# 8. Resumen y recomendaciones
echo -e "${BLUE}╔═══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                      RESUMEN                              ║${NC}"
echo -e "${BLUE}╚═══════════════════════════════════════════════════════════╝${NC}"
echo ""

if systemctl is-active --quiet sentinel-iot && curl -s http://localhost:8000/api/v1/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Sistema funcionando correctamente${NC}"
    echo ""
    echo "Accede a la API en: http://$(hostname -I | awk '{print $1}'):8000"
    echo "Documentación: http://$(hostname -I | awk '{print $1}'):8000/api/docs"
else
    echo -e "${RED}✗ Se detectaron problemas${NC}"
    echo ""
    echo "Recomendaciones:"
    echo ""
    
    if [ ! -f /opt/sentinel-iot/app/main.py ]; then
        echo "  1. Copiar archivos del proyecto:"
        echo "     cd /ruta/sentinel-iot-v2"
        echo "     sudo cp -r backend/* /opt/sentinel-iot/"
        echo ""
    fi
    
    if ! /opt/sentinel-iot/venv/bin/python -c "import fastapi" 2>/dev/null; then
        echo "  2. Instalar dependencias Python:"
        echo "     cd /opt/sentinel-iot"
        echo "     source venv/bin/activate"
        echo "     pip install fastapi uvicorn[standard] sqlalchemy pydantic pydantic-settings"
        echo "     deactivate"
        echo ""
    fi
    
    if ! systemctl is-active --quiet sentinel-iot; then
        echo "  3. Reiniciar el servicio:"
        echo "     sudo systemctl restart sentinel-iot"
        echo ""
        echo "  4. Ver logs para más detalles:"
        echo "     sudo journalctl -u sentinel-iot -f"
        echo ""
    fi
    
    echo "  5. Consultar la guía de solución de problemas:"
    echo "     docs/TROUBLESHOOTING.md"
    echo ""
fi

echo "Para más ayuda, ejecuta: sudo journalctl -u sentinel-iot -n 50"
echo ""
