#!/bin/bash
################################################################################
# SENTINEL IoT - Solución Completa
# 
# Este script resuelve:
#   1. Acceso a Internet para dispositivos IoT (NAT)
#   2. Detección de dispositivos con IP estática
################################################################################

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║          SENTINEL IoT - Configuración Completa                ║"
echo "║                                                                ║"
echo "║  Este script configurará:                                     ║"
echo "║    • Acceso a Internet (NAT)                                  ║"
echo "║    • Detección de dispositivos                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Verificar que se ejecuta como root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Error: Este script debe ejecutarse como root"
    echo "   Usa: sudo bash $0"
    exit 1
fi

# Variables
IOT_INTERFACE="wlan1"
IOT_NETWORK="192.168.50.0/24"
IOT_GATEWAY="192.168.50.1"

# ============================================================================
# PARTE 1: CONFIGURAR ACCESO A INTERNET
# ============================================================================
echo "════════════════════════════════════════════════════════════════"
echo "  PARTE 1: Configurar Acceso a Internet"
echo "════════════════════════════════════════════════════════════════"
echo ""

# 1.1 Habilitar IP forwarding
echo "[1/7] Habilitando IP forwarding..."
sysctl -w net.ipv4.ip_forward=1 > /dev/null
if ! grep -q "^net.ipv4.ip_forward=1" /etc/sysctl.conf; then
    echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
fi
echo "   ✓ IP forwarding habilitado"

# 1.2 Detectar interfaz principal
echo ""
echo "[2/7] Detectando interfaz con Internet..."
MAIN_IF=$(ip route | grep default | awk '{print $5}' | head -1)

if [ -z "$MAIN_IF" ]; then
    echo "   ⚠ No se detectó interfaz con ruta por defecto"
    echo ""
    echo "   Interfaces disponibles:"
    ip link show | grep -E "^[0-9]+" | awk '{print "   - " $2}' | sed 's/:$//'
    echo ""
    read -p "   Ingresa el nombre de la interfaz con Internet (ej: eth0, wlan0): " MAIN_IF
fi

if [ -z "$MAIN_IF" ] || ! ip link show "$MAIN_IF" > /dev/null 2>&1; then
    echo "   ❌ Error: Interfaz inválida"
    exit 1
fi
echo "   ✓ Interfaz principal: $MAIN_IF"

# 1.3 Configurar NAT
echo ""
echo "[3/7] Configurando NAT..."
nft add table ip nat 2>/dev/null || true
nft add chain ip nat postrouting { type nat hook postrouting priority 100 \; } 2>/dev/null || true
nft flush chain ip nat postrouting 2>/dev/null || true
nft add rule ip nat postrouting oifname "$MAIN_IF" masquerade
echo "   ✓ NAT configurado"

# 1.4 Configurar firewall
echo ""
echo "[4/7] Configurando firewall..."
nft add table inet filter 2>/dev/null || true
nft add chain inet filter forward { type filter hook forward priority 0 \; policy accept \; } 2>/dev/null || true
nft add rule inet filter forward iifname "$IOT_INTERFACE" oifname "$MAIN_IF" accept 2>/dev/null || true
nft add rule inet filter forward iifname "$MAIN_IF" oifname "$IOT_INTERFACE" ct state related,established accept 2>/dev/null || true
echo "   ✓ Firewall configurado"

# 1.5 Guardar configuración
echo ""
echo "[5/7] Guardando configuración..."
mkdir -p /etc/nftables
nft list ruleset > /etc/nftables/sentinel-iot.nft

cat > /etc/systemd/system/nftables-sentinel.service << 'EOF'
[Unit]
Description=SENTINEL IoT nftables rules
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/sbin/nft -f /etc/nftables/sentinel-iot.nft
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable nftables-sentinel.service 2>/dev/null
echo "   ✓ Configuración guardada"

# ============================================================================
# PARTE 2: DETECTAR DISPOSITIVOS
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  PARTE 2: Detectar Dispositivos Conectados"
echo "════════════════════════════════════════════════════════════════"
echo ""

echo "[6/7] Escaneando dispositivos..."

# Crear archivo temporal
TEMP_FILE="/tmp/sentinel_scan.txt"
> $TEMP_FILE

# Escanear ARP
ARP_COUNT=0
arp -n | grep -E "192.168.50\." | while read line; do
    IP=$(echo $line | awk '{print $1}')
    MAC=$(echo $line | awk '{print $3}')
    if [[ $MAC =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]]; then
        echo "ARP|$MAC|$IP|Unknown" >> $TEMP_FILE
    fi
done

# Escanear DHCP
DHCP_COUNT=0
if [ -f /var/lib/misc/dnsmasq.leases ]; then
    while read line; do
        MAC=$(echo $line | awk '{print $2}')
        IP=$(echo $line | awk '{print $3}')
        HOSTNAME=$(echo $line | awk '{print $4}')
        if [[ $MAC =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]]; then
            echo "DHCP|$MAC|$IP|$HOSTNAME" >> $TEMP_FILE
        fi
    done < /var/lib/misc/dnsmasq.leases
fi

TOTAL=$(wc -l < $TEMP_FILE 2>/dev/null || echo "0")
echo "   ✓ Dispositivos detectados: $TOTAL"

# ============================================================================
# VERIFICACIÓN FINAL
# ============================================================================
echo ""
echo "[7/7] Verificando configuración..."
echo ""

# Verificar IP forwarding
IP_FWD=$(cat /proc/sys/net/ipv4/ip_forward)
if [ "$IP_FWD" = "1" ]; then
    echo "   ✓ IP Forwarding: HABILITADO"
else
    echo "   ✗ IP Forwarding: DESHABILITADO"
fi

# Verificar NAT
NAT_RULES=$(nft list chain ip nat postrouting 2>/dev/null | grep -c masquerade)
if [ "$NAT_RULES" -gt 0 ]; then
    echo "   ✓ NAT: CONFIGURADO"
else
    echo "   ✗ NAT: NO CONFIGURADO"
fi

# Verificar Internet
echo ""
echo "   Probando conectividad a Internet..."
if ping -c 2 -W 3 8.8.8.8 > /dev/null 2>&1; then
    echo "   ✓ Internet: FUNCIONA"
else
    echo "   ⚠ Internet: NO DISPONIBLE"
fi

# ============================================================================
# MOSTRAR DISPOSITIVOS DETECTADOS
# ============================================================================
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  Dispositivos Detectados en la Red"
echo "════════════════════════════════════════════════════════════════"
echo ""

if [ "$TOTAL" -eq 0 ]; then
    echo "⚠ No se detectaron dispositivos conectados"
else
    printf "%-8s %-18s %-15s %-20s\n" "Tipo" "MAC Address" "IP Address" "Hostname"
    printf "%-8s %-18s %-15s %-20s\n" "========" "==================" "===============" "===================="
    
    while IFS='|' read -r type mac ip hostname; do
        printf "%-8s %-18s %-15s %-20s\n" "$type" "$mac" "$ip" "$hostname"
    done < $TEMP_FILE
fi

# ============================================================================
# RESUMEN Y SIGUIENTES PASOS
# ============================================================================
echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                  CONFIGURACIÓN COMPLETADA                      ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "Configuración aplicada:"
echo "  • Interfaz IoT: $IOT_INTERFACE ($IOT_GATEWAY)"
echo "  • Interfaz principal: $MAIN_IF"
echo "  • IP Forwarding: Habilitado"
echo "  • NAT: Configurado y persistente"
echo "  • Dispositivos detectados: $TOTAL"
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  PRUEBAS DESDE TU CELULAR"
echo "════════════════════════════════════════════════════════════════"
echo ""
echo "Conecta tu celular a la red SENTINEL_IoT y ejecuta:"
echo ""
echo "  1. Probar gateway:"
echo "     ping $IOT_GATEWAY"
echo ""
echo "  2. Probar Internet:"
echo "     ping 8.8.8.8"
echo ""
echo "  3. Probar DNS:"
echo "     ping google.com"
echo ""
echo "  4. Abrir navegador:"
echo "     http://google.com"
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  DETECCIÓN EN EL DASHBOARD"
echo "════════════════════════════════════════════════════════════════"
echo ""

# Contar dispositivos ARP vs DHCP
ARP_DEVICES=$(grep -c "^ARP" $TEMP_FILE 2>/dev/null || echo "0")
DHCP_DEVICES=$(grep -c "^DHCP" $TEMP_FILE 2>/dev/null || echo "0")

if [ "$ARP_DEVICES" -gt 0 ]; then
    echo "⚠ Dispositivos con IP estática detectados: $ARP_DEVICES"
    echo ""
    echo "  Estos dispositivos NO aparecerán en el dashboard actual."
    echo ""
    echo "  Para que aparezcan, tienes 2 opciones:"
    echo ""
    echo "  OPCIÓN 1 (Recomendada): Cambiar a DHCP"
    echo "    • En tu celular/dispositivo:"
    echo "      Configuración → Wi-Fi → SENTINEL_IoT"
    echo "      → Cambiar de 'IP estática' a 'DHCP'"
    echo "    • Reconectar"
    echo ""
    echo "  OPCIÓN 2: Modificar el backend"
    echo "    • Ejecutar: sudo bash scripts/update_device_detection.sh"
    echo "    • Esto modificará el código para detectar IPs estáticas"
    echo ""
fi

if [ "$DHCP_DEVICES" -gt 0 ]; then
    echo "✓ Dispositivos con DHCP detectados: $DHCP_DEVICES"
    echo "  Estos DEBERÍAN aparecer en el dashboard automáticamente"
    echo ""
    echo "  Accede al dashboard en:"
    echo "    http://$IOT_GATEWAY:8000"
    echo ""
fi

echo "════════════════════════════════════════════════════════════════"
echo "  COMANDOS ÚTILES"
echo "════════════════════════════════════════════════════════════════"
echo ""
echo "Ver dispositivos en tiempo real:"
echo "  watch -n 2 'arp -n | grep 192.168.50'"
echo ""
echo "Ver logs de dnsmasq:"
echo "  sudo journalctl -u dnsmasq -f"
echo ""
echo "Ver tráfico de red:"
echo "  sudo tcpdump -i $IOT_INTERFACE -n"
echo ""
echo "Ver reglas de NAT:"
echo "  sudo nft list ruleset | grep -A 5 nat"
echo ""
echo "Ejecutar detección de dispositivos:"
echo "  sudo bash scripts/detect_static_devices.sh"
echo ""

# Limpiar
rm -f $TEMP_FILE

exit 0
