# SENTINEL IoT - Versión Definitiva

## 🎯 Descripción

**SENTINEL IoT** es una plataforma integral de seguridad para dispositivos IoT que proporciona:

- **Punto de Acceso Wi-Fi Seguro** para dispositivos IoT
- **Firewall Inteligente** con reglas dinámicas basadas en perfiles
- **Detección Automática** de dispositivos conectados
- **Dashboard Web** para gestión y monitoreo
- **Machine Learning** para detección de anomalías
- **API REST** completa para integración

---

## 📦 Contenido del Proyecto

```
sentinel-iot-final/
├── scripts/
│   ├── installation/          # Scripts de instalación inicial
│   ├── troubleshooting/       # Scripts para solucionar problemas
│   └── utilities/             # Scripts auxiliares
├── backend/                   # Código del backend (Python/FastAPI)
├── frontend/                  # Código del frontend (HTML/CSS/JS)
├── docs/                      # Documentación completa
└── README.md                  # Este archivo
```

---

## 🚀 Instalación Rápida

### Opción 1: Instalación Profesional (Recomendada)

Este método instala y configura todo correctamente siguiendo mejores prácticas:

```bash
cd scripts/installation
sudo bash install_hostapd_dnsmasq_proper.sh
```

**Tiempo:** ~2 minutos  
**Resultado:** Punto de acceso Wi-Fi funcionando con Internet compartido

### Opción 2: Instalación Completa del Sistema

Si quieres instalar también el backend de SENTINEL IoT:

```bash
cd scripts/installation
sudo bash install_fixed.sh
```

**Tiempo:** ~5-10 minutos  
**Resultado:** Sistema completo funcionando (Wi-Fi + Backend + Dashboard)

---

## 📚 Estructura de Scripts

### 📁 scripts/installation/

Scripts para instalación inicial del sistema:

| Script | Descripción | Cuándo Usar |
|--------|-------------|-------------|
| `install_hostapd_dnsmasq_proper.sh` | Instala Wi-Fi AP profesionalmente | **Primera instalación** o reinstalación limpia |
| `install_fixed.sh` | Instala sistema completo SENTINEL | Instalación completa con backend |
| `deploy_frontend.sh` | Despliega solo la interfaz web | Actualizar solo el frontend |

### 📁 scripts/troubleshooting/

Scripts para solucionar problemas específicos:

| Script | Descripción | Cuándo Usar |
|--------|-------------|-------------|
| `diagnose.sh` | Diagnóstico completo del sistema | Verificar estado general |
| `fix_detection_and_internet.sh` | Corrige detección de dispositivos e Internet | Dispositivos no detectados o sin Internet |
| `enable_internet.sh` | Configura solo acceso a Internet (NAT) | Solo problema de Internet |
| `detect_static_devices.sh` | Detecta dispositivos con IP estática | Ver dispositivos no detectados por DHCP |
| `fix_wifi_complete.sh` | Solución completa de problemas Wi-Fi | Problemas generales de Wi-Fi |
| `fix_wifi_dhcp.sh` | Corrige solo problemas de DHCP | Dispositivos no obtienen IP |

---

## 🎓 Guías de Uso

### Para Empezar

1. **Lee primero:** `docs/GUIA_INSTALACION_PROFESIONAL.md`
2. **Ejecuta:** `scripts/installation/install_hostapd_dnsmasq_proper.sh`
3. **Verifica:** Conéctate a la red SENTINEL_IoT

### Si Tienes Problemas

1. **Ejecuta diagnóstico:** `scripts/troubleshooting/diagnose.sh`
2. **Consulta:** `docs/SOLUCION_WIFI_DHCP.md`
3. **Aplica solución:** Script correspondiente de `troubleshooting/`

### Documentación Completa

Toda la documentación está en la carpeta `docs/`:

**Guías de Instalación:**
- `GUIA_INSTALACION_PROFESIONAL.md` - Instalación paso a paso
- `GUIA_SCRIPTS_SOLUCION.md` - Uso de scripts de solución

**Solución de Problemas:**
- `SOLUCION_WIFI_DHCP.md` - Problemas de Wi-Fi y DHCP
- `SOLUCION_INTERFAZ_WEB.md` - Problemas de dashboard
- `COMANDOS_DIAGNOSTICO_WIFI.md` - Comandos útiles

**Configuración:**
- `RANGOS_IP_ALTERNATIVOS.md` - Cambiar rango de IPs
- `GUIA_RAPIDA_WIFI.md` - Referencia rápida

**Información Técnica:**
- `COMO_FUNCIONA_DETECCION_DISPOSITIVOS.md` - Detección de dispositivos
- `ANALISIS_RASPAP.md` - Análisis de RaspAP como alternativa
- `COMPARATIVA_V1_VS_V2.md` - Diferencias entre versiones

---

## 🔧 Configuración

### Cambiar Configuración de Wi-Fi

Edita las variables al inicio de `install_hostapd_dnsmasq_proper.sh`:

```bash
SSID="SENTINEL_IoT"              # Nombre de la red
PASSWORD="Sentinel2024!"         # Contraseña
CHANNEL="6"                      # Canal Wi-Fi
IOT_IP="192.168.50.1"           # IP del gateway
DHCP_START="192.168.50.10"      # Inicio rango DHCP
DHCP_END="192.168.50.250"       # Fin rango DHCP
```

### Cambiar Rango de IP

Si `192.168.50.x` está en uso, consulta `docs/RANGOS_IP_ALTERNATIVOS.md` para opciones.

---

## 🆘 Solución de Problemas

### Problema: Red Wi-Fi no aparece

**Solución:**
```bash
cd scripts/troubleshooting
sudo bash fix_wifi_complete.sh
```

### Problema: Dispositivos no obtienen IP

**Solución:**
```bash
cd scripts/troubleshooting
sudo bash fix_wifi_dhcp.sh
```

### Problema: No hay Internet en la red IoT

**Solución:**
```bash
cd scripts/troubleshooting
sudo bash enable_internet.sh
```

### Problema: Dashboard no detecta dispositivos

**Solución:**
```bash
cd scripts/troubleshooting
sudo bash detect_static_devices.sh
# Luego cambia dispositivos a DHCP o modifica backend
```

### Diagnóstico General

```bash
cd scripts/troubleshooting
sudo bash diagnose.sh
```

---

## 📊 Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────┐
│                    Dispositivos IoT                         │
│  (Smartphones, Sensores, Cámaras, Smart Home, etc.)       │
└────────────────────┬────────────────────────────────────────┘
                     │ Wi-Fi
                     ↓
┌─────────────────────────────────────────────────────────────┐
│              Raspberry Pi (SENTINEL IoT)                    │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────────┐ │
│  │   hostapd    │  │   dnsmasq    │  │  Firewall (nft) │ │
│  │ (Punto de    │  │   (DHCP/DNS) │  │  (Reglas        │ │
│  │  Acceso)     │  │              │  │   dinámicas)    │ │
│  └──────────────┘  └──────────────┘  └─────────────────┘ │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐ │
│  │         Backend (Python/FastAPI)                     │ │
│  │  • Device Manager                                    │ │
│  │  • Firewall Manager                                  │ │
│  │  • ML Anomaly Detector                               │ │
│  │  • API REST                                          │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐ │
│  │         Frontend (HTML/CSS/JavaScript)               │ │
│  │  • Dashboard en tiempo real                          │ │
│  │  • Gestión de dispositivos                           │ │
│  │  • Configuración de firewall                         │ │
│  └──────────────────────────────────────────────────────┘ │
└────────────────────┬────────────────────────────────────────┘
                     │ Ethernet
                     ↓
┌─────────────────────────────────────────────────────────────┐
│                      Internet                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔐 Seguridad

SENTINEL IoT implementa múltiples capas de seguridad:

1. **Aislamiento de Red:** Dispositivos IoT en red separada (192.168.50.x)
2. **Firewall Dinámico:** Reglas basadas en perfiles de dispositivo
3. **Detección de Anomalías:** Machine Learning para detectar comportamiento sospechoso
4. **Cuarentena Automática:** Dispositivos nuevos en cuarentena hasta clasificación
5. **Autenticación WPA2:** Red Wi-Fi protegida con contraseña

---

## 🌟 Características Principales

### ✅ Punto de Acceso Wi-Fi
- Configuración automática de hostapd y dnsmasq
- DHCP con rango configurable
- NAT para compartir Internet
- WPA2 para seguridad

### ✅ Detección de Dispositivos
- Detección automática vía DHCP
- Escaneo de tabla ARP para IPs estáticas
- Identificación por MAC address
- Clasificación inteligente

### ✅ Firewall Inteligente
- Reglas dinámicas con nftables
- Perfiles de seguridad (strict, moderate, permissive)
- Cuarentena automática
- Logs detallados

### ✅ Dashboard Web
- Visualización en tiempo real
- Gestión de dispositivos
- Configuración de firewall
- Estadísticas y métricas

### ✅ Machine Learning
- Detección de anomalías en tráfico
- Aprendizaje de patrones normales
- Alertas automáticas

### ✅ API REST
- 25+ endpoints documentados
- Autenticación JWT
- Integración con otros sistemas

---

## 🛠️ Requisitos

### Hardware
- Raspberry Pi 3/4/5 o Zero W
- Adaptador Wi-Fi USB (si usas Pi sin Wi-Fi integrado)
- Tarjeta microSD (16GB mínimo)
- Fuente de alimentación

### Software
- Raspbian/Raspberry Pi OS (Stretch o superior)
- Python 3.7+
- Node.js 14+ (opcional, para desarrollo frontend)

---

## 📝 Licencia

Este proyecto es de código abierto y está disponible bajo la licencia MIT.

---

## 👥 Contribuciones

Las contribuciones son bienvenidas. Por favor:

1. Haz fork del proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

## 📞 Soporte

Si tienes problemas:

1. **Consulta la documentación** en `docs/`
2. **Ejecuta el diagnóstico** con `scripts/troubleshooting/diagnose.sh`
3. **Revisa los logs** con `journalctl -u hostapd -u dnsmasq`
4. **Abre un issue** en el repositorio del proyecto

---

## 🎉 Agradecimientos

Este proyecto fue desarrollado basándose en las mejores prácticas de:

- [SparkFun Tutorial](https://learn.sparkfun.com/tutorials/setting-up-a-raspberry-pi-3-as-an-access-point/all)
- [Raspberry Pi Official Documentation](https://www.raspberrypi.com/documentation/)
- [FinchSec Blog](https://finchsec-1672417305892.hashnode.dev/linux-ap-hostapd-dnsmasq-dhcp)

---

## 📅 Versión

**Versión:** 2.0 Final  
**Fecha:** Noviembre 2024  
**Estado:** Producción

---

## 🚀 Inicio Rápido (TL;DR)

```bash
# 1. Extraer el proyecto
tar -xzf SENTINEL_IoT_FINAL.tar.gz
cd sentinel-iot-final

# 2. Instalar
cd scripts/installation
sudo bash install_hostapd_dnsmasq_proper.sh

# 3. Conectar
# Busca la red "SENTINEL_IoT"
# Contraseña: "Sentinel2024!"

# 4. Acceder al dashboard
# http://192.168.50.1:8000
```

¡Eso es todo! 🎉
